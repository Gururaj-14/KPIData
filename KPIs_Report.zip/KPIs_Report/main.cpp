#include "kpis_report.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    KPIs_Report w;
    w.show();
    return a.exec();
}
