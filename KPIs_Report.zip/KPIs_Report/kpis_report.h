#ifndef KPIS_REPORT_H
#define KPIS_REPORT_H
#include <QWidget>
#include <QTcpSocket>
#include <QJsonParseError>
#include <QMessageBox>
#include <QJsonObject>
#include <QJsonArray>
#include <unistd.h>
#include <QStandardItemModel>
#include <QDebug>
#include <QListView>
#include <QValidator>
#include <QIntValidator>
#include <QLineEdit>
#include <QComboBox>
#include <QtGui>
#include <QThread>
#include <QTimer>
#include <QSettings>
#include <QHostAddress>
#include <appversions.h>
QT_BEGIN_NAMESPACE
namespace Ui { class KPIs_Report; }
QT_END_NAMESPACE

class KPIs_Report : public QWidget
{
    Q_OBJECT

public:
    KPIs_Report(QWidget *parent = nullptr);
    ~KPIs_Report();
    QTcpSocket *socket,*socket1;
    AppVersions *m_appVersions;
    QStandardItemModel *model_Kpis;
    void clearValues();
    QStringList strList_ParameterName,strList_kpiId,strList_kpiName,strList_bitMask;
    QStringList strList_kpi,strList_Drivetime,strList_starts;
    QThread *m_pingThread;
    QTimer *m_pingTimer;
    QString Str_IPAddress,Str_port;
    // void Connection_status();
    void ReloadDefaultIps();
    void ReloadLastSelectedIPs();
    void ConnectToIp_Port(QString,QString);
    void clearWidgets();
    void clearText();

private slots:
//    void on_timeEdit_Start_timeChanged(const QTime &time);

//    void on_timeEdit_End_timeChanged(const QTime &time);

    void on_m_PshBtn_GetData_clicked();
    void CheckConnection();
    void on_radioButton_year_clicked();
    void on_radioButton_month_clicked();
    void on_radioButton_day_clicked();
    void on_radioButton_searchbyperiod_clicked();
    void on_toolButton_prv_clicked();
    void on_toolButton_nxt_clicked();

    void on_pushButton_connect_clicked();

    void on_comboBox_ConnectedIPs_currentTextChanged(const QString &arg1);

    void on_toolButton_Versions_clicked();

private:
    Ui::KPIs_Report *ui;
};
#endif // KPIS_REPORT_H
