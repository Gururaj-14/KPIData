#include "kpis_report.h"
#include "ui_kpis_report.h"
#define GROUPSAVE "IP_PORT_GROUP_SAVE"
#define GROUP "IP_PORT_GROUP"
#define KEY "IP_key"
#define DEFAULT_IP_PORT "10.96.46.55:9876"
#define DEFAULT_PORT "9876"

KPIs_Report::KPIs_Report(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::KPIs_Report)
{
    ui->setupUi(this);
    this->setWindowTitle("KPI Report");
    ui->radioButton_year->setChecked(true);
    on_radioButton_year_clicked();

    QStringList qListyears;
    qListyears << "2020" << "2021" << "2022" << "2023" << "2024" << "2025" << "2026" << "2027" << "2028";
    ui->comboBox_year_y->addItems(qListyears);
    ui->comboBox_month_y->addItems(qListyears);
    ui->comboBox_day_y->addItems(qListyears);

    //Other Combo Boxes
    QStringList qListmnth;
    qListmnth << "1" << "2" << "3" << "4" << "5" << "6" << "7" << "8" << "9" << "10" << "11" << "12" ;
    ui->comboBox_month_m->addItems(qListmnth);
    ui->comboBox_day_m->addItems(qListmnth);

    QStringList qListdays;
    qListdays << "1" << "2" << "3" << "4" << "5" << "6" << "7" << "8" << "9" << "10" << "11" << "12" << "13" << "14" << "15" << "16" << "17" << "18" << "19" << "20" << "21" << "22" << "23" << "24" << "25" << "26" << "27" << "28" << "29" << "30" ;
    ui->comboBox_day_d->addItems(qListdays);

    socket = new QTcpSocket(this);
    QDateTime CurrentStartDateTime = QDateTime::currentDateTime().addSecs(-5 * 60);
    ui->TimeStamp_StartTime->setDateTime(CurrentStartDateTime);
    QDateTime CurrentEndDateTime = QDateTime::currentDateTime();
    ui->TimeStamp_EndTime->setDateTime(CurrentEndDateTime);

    m_pingThread = new QThread();
    m_pingTimer = new QTimer();
    m_pingTimer->setInterval(10000);
    m_pingTimer->moveToThread(m_pingThread);

    connect(m_pingThread,SIGNAL(started()),m_pingTimer,SLOT(start()));
    connect(m_pingTimer,SIGNAL(timeout()),this,SLOT(CheckConnection()));

    ReloadDefaultIps();
    ReloadLastSelectedIPs();


}

KPIs_Report::~KPIs_Report()
{
    delete ui;
}
void KPIs_Report::ReloadDefaultIps()
{
    QSettings setting("Finecho_IP_Port_Save","IP_Port_Details_Save");
    setting.beginGroup(GROUPSAVE);
    foreach (const QString &key, setting.childKeys())
    {
        QString value = setting.value(key).toString();
        ui->comboBox_ConnectedIPs->addItem(value);
    }
    setting.endGroup();
}

void KPIs_Report::ReloadLastSelectedIPs()
{
    QSettings settings("Finecho_IP_Port","IP_Port_Details");
    settings.beginGroup(GROUP);
    QString value = settings.value(KEY).toString();
    ui->comboBox_ConnectedIPs->setCurrentText(value);
    QStringList strlst = value.split(':');
    int dSize = value.length();
    QString strIP,strPort;
    if(dSize > 0){
        strIP = strlst.at(0);
        strPort = strlst.at(1);
        ConnectToIp_Port(strIP,strPort);
    }
    else
    {
        strIP = "127.0.0.1";
        strPort = "6789";
        ConnectToIp_Port(strIP,strPort);
    }
    settings.endGroup();
}

void KPIs_Report::ConnectToIp_Port(QString strIP, QString strPort)
{
    socket = new QTcpSocket(this);
    socket->connectToHost(strIP, strPort.toInt());
    if(socket->waitForConnected(10000))
    {
        m_pingThread->exit();
        QSettings setting("Finecho_IP_Port_Save","IP_Port_Details_Save");
        setting.beginGroup(GROUPSAVE);
        int i=0;
        QStringList lst = setting.allKeys();
        if(lst.length() == 0)
        {
            setting.setValue(strIP, strIP+":"+strPort);
        }
        foreach (const QString &key, setting.childKeys())
        {
            int num = lst.length();
            QString value = setting.value(key).toString();
            if(value != strIP+":"+strPort )
            {
                i++;
            }
            if(num == i)
            {
                setting.setValue(strIP, strIP+":"+strPort);
            }
        }
        QStringList strlst;
        foreach (const QString &key, setting.childKeys())
        {
            QString value = setting.value(key).toString();
            strlst << value;
            ui->comboBox_ConnectedIPs->addItem(value);
        }
        strlst.removeDuplicates();

        ui->comboBox_ConnectedIPs->clear();
        ui->comboBox_ConnectedIPs->addItems(strlst);
        ui->comboBox_ConnectedIPs->setCurrentText(strIP+":"+strPort);
        setting.endGroup();

        ui->lbl_Connection->setStyleSheet("background-color:green;");
        ui->lbl_error_msg->setText("");

        // close the connection
        socket->close();
        //============================
        Str_IPAddress = strIP;
        Str_port = strPort;

        QSettings settings("Finecho_IP_Port","IP_Port_Details");
        settings.beginGroup(GROUP);
        settings.setValue(KEY, strIP+":"+strPort);
        settings.endGroup();

        socket1 = new QTcpSocket(this);
        if(socket1->state() == QAbstractSocket::UnconnectedState)
        {
            socket1->connectToHost(strIP, strPort.toInt());
        }
        m_pingThread->start();
    }
    else
    {
        m_pingThread->exit();
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_error_msg->setText("ERROR: " + socket->errorString());
        ui->lbl_Connection->setStyleSheet("background-color:red;");
    }
}
void KPIs_Report::on_pushButton_connect_clicked()
{
    QString strIPAddress, strIPPort, strIP;
    QStringList strParts;
    bool bFlag=false;

    strIP = ui->comboBox_ConnectedIPs->currentText();
    strParts = strIP.split(":");
    strIPAddress = strParts.at(0);
    if(strParts.count()<2)
        strIPPort = DEFAULT_PORT;
    else
        strIPPort = strParts.at(1);

    if(strIPAddress.split(".").count()==4)
    {
        QHostAddress address(strIPAddress);
        if(QAbstractSocket::IPv4Protocol==address.protocol())
        {
            bFlag= true;
        }
        else if(QAbstractSocket::IPv6Protocol==address.protocol())
        {
            bFlag= true;
        }
        else
        {
            QMessageBox::information(this,"Warning","Not a Valid IP Address");
            bFlag= false;
        }
    }
    else
    {
        QMessageBox::information(this,"Warning","Not a Valid IP Address");
        bFlag= false;
    }

    if(bFlag==true)
    {
        if(ui->comboBox_ConnectedIPs->findText(strIP,Qt::MatchExactly) == -1)
        {
            //Save to local disk here
        }
        ConnectToIp_Port(strIPAddress,strIPPort);
    }
}

void KPIs_Report::on_comboBox_ConnectedIPs_currentTextChanged(const QString &arg1)
{
    clearWidgets();
    m_pingThread->exit();
    ui->lbl_Connection->setStyleSheet("background-color:red;");
}
void KPIs_Report::CheckConnection()
{
    if(socket1->state() == QAbstractSocket::UnconnectedState)
    {
        socket1->connectToHost(Str_IPAddress, Str_port.toInt());
    }
    if(socket1->state() == QAbstractSocket::ConnectedState)
    {
        ui->lbl_Connection->setStyleSheet("background-color:green;");
        ui->lbl_error_msg->setText("");
    }
    else
    {
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->lbl_error_msg->setText("Connection lost");
    }
}
void KPIs_Report::clearWidgets()
{
    ui->tableWidget_year_count->setRowCount(0);
}

void KPIs_Report::on_m_PshBtn_GetData_clicked()
{
    QString year = ui->comboBox_year_y->currentText();

    QString month = ui->comboBox_month_m->currentText();
    QString month_y = ui->comboBox_month_y->currentText();

    QString day = ui->comboBox_day_d->currentText();
    QString day_m = ui->comboBox_day_m->currentText();
    QString day_y = ui->comboBox_day_y->currentText();

    QJsonObject jsonKeys;
    QJsonArray jsonArray,plot_array;

    //==============================search by period====================
    if(ui->radioButton_searchbyperiod->isChecked())
    {
        QDateTime startDateTime;
        startDateTime = ui->TimeStamp_StartTime->dateTime();
        QString sTime = startDateTime.toString("yyyy-MM-dd");

        QDateTime endDateTime;
        endDateTime = ui->TimeStamp_EndTime->dateTime();
        QString eTime = endDateTime.toString("yyyy-MM-dd");

        ui->label_text->setText("Search- "+sTime+" "+eTime);
        ui->label_Result->setText("");

        jsonKeys.insert("username","devel");
        jsonKeys.insert("passcode","123");
        jsonKeys.insert("authkey","abcd");
        jsonKeys.insert("endpoint","reportKpi");

        auto data1 = QJsonObject(
        {
                        qMakePair(QString("start_time"), QJsonValue(sTime)),
                        qMakePair(QString("end_time"), QJsonValue(eTime)),
                        qMakePair(QString("iptype"), QJsonValue("duration")),
                        qMakePair(QString("year"), QJsonValue()),
                        qMakePair(QString("month"), QJsonValue()),
                        qMakePair(QString("day"), QJsonValue())

                    });

        plot_array.push_back(QJsonValue(data1));
        jsonKeys.insert("params",QJsonValue(plot_array));
        jsonArray.append(jsonKeys);

    }
    //====================year=================
    if(ui->radioButton_year->isChecked())
    {
        ui->label_Result->setText(year);
        ui->label_text->setText("Year- "+year);

        jsonKeys.insert("username","devel");
        jsonKeys.insert("passcode","123");
        jsonKeys.insert("authkey","abcd");
        jsonKeys.insert("endpoint","reportKpi");

        auto data1 = QJsonObject(
        {
                        qMakePair(QString("start_time"), QJsonValue()),
                        qMakePair(QString("end_time"), QJsonValue()),
                        qMakePair(QString("iptype"), QJsonValue("year")),
                        qMakePair(QString("year"), QJsonValue(year)),
                        qMakePair(QString("month"), QJsonValue()),
                        qMakePair(QString("day"), QJsonValue())

                    });

        plot_array.push_back(QJsonValue(data1));
        jsonKeys.insert("params",QJsonValue(plot_array));
        jsonArray.append(jsonKeys);

    }
    //========================month=====================
    if(ui->radioButton_month->isChecked())
    {

        QString m_y = QString(month+" "+month_y);
        ui->label_Result->setText(m_y);
        ui->label_text->setText("Month- "+m_y);

        jsonKeys.insert("username","devel");
        jsonKeys.insert("passcode","123");
        jsonKeys.insert("authkey","abcd");
        jsonKeys.insert("endpoint","reportKpi");

        auto data1 = QJsonObject(
        {
                        qMakePair(QString("start_time"), QJsonValue()),
                        qMakePair(QString("end_time"), QJsonValue()),
                        qMakePair(QString("iptype"), QJsonValue("month")),
                        qMakePair(QString("year"), QJsonValue(month_y)),
                        qMakePair(QString("month"), QJsonValue(month)),
                        qMakePair(QString("day"), QJsonValue())
                    });

        plot_array.push_back(QJsonValue(data1));
        jsonKeys.insert("params",QJsonValue(plot_array));
        jsonArray.append(jsonKeys);
    }
    //=======================day=====================
    if(ui->radioButton_day->isChecked())
    {
        QString d_m_y = QString(day+"-"+day_m+"-"+day_y);
        ui->label_Result->setText(d_m_y);

        ui->label_text->setText("Day- "+d_m_y);

        jsonKeys.insert("username","devel");
        jsonKeys.insert("passcode","123");
        jsonKeys.insert("authkey","abcd");
        jsonKeys.insert("endpoint","reportKpi");

        auto data1 = QJsonObject(
        {
                        qMakePair(QString("start_time"), QJsonValue()),
                        qMakePair(QString("end_time"), QJsonValue()),
                        qMakePair(QString("iptype"), QJsonValue("day")),
                        qMakePair(QString("year"), QJsonValue(day_y)),
                        qMakePair(QString("month"), QJsonValue(day_m)),
                        qMakePair(QString("day"), QJsonValue(day))

                    });

        plot_array.push_back(QJsonValue(data1));
        jsonKeys.insert("params",QJsonValue(plot_array));
        jsonArray.append(jsonKeys);
    }
    //===============================================
    QJsonDocument jsonDoc;
    jsonDoc = QJsonDocument(jsonArray);

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(jsonDoc.toJson().constData());
        socket->waitForBytesWritten(30000);

        QJsonParseError json_error;
        QByteArray data;

        int iBytes=0;
        for(int m=0; m<500; m++){
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            if(iBytes==0)
                break;

            data += socket->readAll();
            usleep(100000);
        }
        QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
        if (json_error.error != QJsonParseError::NoError)
        {
            qDebug() << "JSON parse error: "<< json_error.errorString();
        }

        QJsonObject rootObj = loadDoc.object();
        QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();

        QJsonValue fieldSet;
        QJsonObject fieldObj;
        clearValues();
        for(int i=0; i< fieldDefJSONArray.size(); i++)
        {
            fieldSet = fieldDefJSONArray.at(i);
            fieldObj = fieldSet.toObject();

            strList_kpi << fieldObj.value("machinery").toString();
            strList_Drivetime << fieldObj.value("drivetime").toString();
            strList_starts << fieldObj.value("starts").toString();
        }
        socket->close();
    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        return;
    }
    //========================================================
    ui->tableWidget_year_count->setRowCount(0);
    int i=0;
    while(i < strList_kpi.length())
    {
        ui->tableWidget_year_count->insertRow(i);
        QTableWidgetItem *item;
        QString kpi_name = strList_kpi.at(i);
        QString jan = strList_Drivetime.at(i);
        QString feb = strList_starts.at(i);


        item = new QTableWidgetItem(kpi_name);
        item->setFlags(item->flags() & ~Qt::ItemIsEditable); // non editable
        ui->tableWidget_year_count->setItem(i,0,item);

        item = new QTableWidgetItem(jan);
        item->setFlags(item->flags() & ~Qt::ItemIsEditable); // non editable
        ui->tableWidget_year_count->setItem(i,1,item);

        item = new QTableWidgetItem(feb);
        item->setFlags(item->flags() & ~Qt::ItemIsEditable); // non editable
        ui->tableWidget_year_count->setItem(i,2,item);

        i++;
    }
    if(i == 0)
    {
        QString message = QString( "No match for given criteria in the selected time range");
        QMessageBox::information(this,"No Match Found!", message );
    }
}

void KPIs_Report::clearValues()
{
    strList_kpi.clear();
    strList_Drivetime.clear();
    strList_starts.clear();

}
void KPIs_Report::on_radioButton_year_clicked()
{
    clearText();
    ui->tableWidget_year_count->setRowCount(0);
    ui->comboBox_year_y->setEnabled(true);
    ui->comboBox_month_m->setEnabled(false);
    ui->comboBox_month_y->setEnabled(false);
    ui->comboBox_day_d->setEnabled(false);
    ui->comboBox_day_m->setEnabled(false);
    ui->comboBox_day_y->setEnabled(false);
    ui->TimeStamp_StartTime->setEnabled(false);
    ui->TimeStamp_EndTime->setEnabled(false);

}

void KPIs_Report::on_radioButton_month_clicked()
{
    clearText();
    ui->tableWidget_year_count->setRowCount(0);
    ui->comboBox_year_y->setEnabled(false);
    ui->comboBox_month_m->setEnabled(true);
    ui->comboBox_month_y->setEnabled(true);
    ui->comboBox_day_d->setEnabled(false);
    ui->comboBox_day_m->setEnabled(false);
    ui->comboBox_day_y->setEnabled(false);
    ui->TimeStamp_StartTime->setEnabled(false);
    ui->TimeStamp_EndTime->setEnabled(false);
}

void KPIs_Report::on_radioButton_day_clicked()
{
    clearText();
    ui->tableWidget_year_count->setRowCount(0);
    ui->comboBox_year_y->setEnabled(false);
    ui->comboBox_month_m->setEnabled(false);
    ui->comboBox_month_y->setEnabled(false);
    ui->comboBox_day_d->setEnabled(true);
    ui->comboBox_day_m->setEnabled(true);
    ui->comboBox_day_y->setEnabled(true);
    ui->TimeStamp_StartTime->setEnabled(false);
    ui->TimeStamp_EndTime->setEnabled(false);
}

void KPIs_Report::on_radioButton_searchbyperiod_clicked()
{
    clearText();
    ui->tableWidget_year_count->setRowCount(0);
    ui->comboBox_year_y->setEnabled(false);
    ui->comboBox_month_m->setEnabled(false);
    ui->comboBox_month_y->setEnabled(false);
    ui->comboBox_day_d->setEnabled(false);
    ui->comboBox_day_m->setEnabled(false);
    ui->comboBox_day_y->setEnabled(false);
    ui->TimeStamp_StartTime->setEnabled(true);
    ui->TimeStamp_EndTime->setEnabled(true);
}
void KPIs_Report::clearText()
{
  ui->label_text->clear();
  ui->label_Result->clear();
}

void KPIs_Report::on_toolButton_prv_clicked()
{

    if(ui->radioButton_year->isChecked())
    {
        int i_yr = ui->label_Result->text().toInt();
        QDate s = QDate(i_yr, 1, 1).addYears(-1);
        int d = s.year();
        ui->label_Result->setText(QString::number(d));
        ui->comboBox_year_y->setCurrentText(QString::number(d));
    }
    if(ui->radioButton_month->isChecked())
    {
        QString i_yr = ui->label_Result->text();
        QStringList strlst = i_yr.split(" ");
        int strM = strlst.at(0).toInt();
        int stry = strlst.at(1).toInt();
        QDate s = QDate(stry,strM, 1).addMonths(-1);
        int y = s.year();
        int m = s.month();
        ui->label_Result->setText(QString::number(m)+" "+QString::number(y));
        ui->comboBox_month_y->setCurrentText(QString::number(y));
        ui->comboBox_month_m->setCurrentText(QString::number(m));
    }
    if(ui->radioButton_day->isChecked())
    {
        QString i_yr = ui->label_Result->text();
        QStringList strlst = i_yr.split("-");
        int strD = strlst.at(0).toInt();
        int strM = strlst.at(1).toInt();
        int stry = strlst.at(2).toInt();
        QDate s = QDate(stry,strM,strD).addDays(-1);
        int D = s.day();
        int y = s.year();
        int m = s.month();
        ui->label_Result->setText(QString::number(D)+"-"+QString::number(m)+"-"+QString::number(y));
        ui->comboBox_day_y->setCurrentText(QString::number(y));
        ui->comboBox_day_m->setCurrentText(QString::number(m));
        ui->comboBox_day_d->setCurrentText(QString::number(D));
    }
    if(ui->radioButton_searchbyperiod->isChecked())
    {
        ui->label_Result->setText("");
    }

}

void KPIs_Report::on_toolButton_nxt_clicked()
{
    if(ui->radioButton_year->isChecked())
    {
        int i_yr = ui->label_Result->text().toInt();
        QDate s = QDate(i_yr, 1, 1).addYears(+1);
        int d = s.year();
        ui->label_Result->setText(QString::number(d));
        ui->comboBox_year_y->setCurrentText(QString::number(d));

    }
    if(ui->radioButton_month->isChecked())
    {
        QString i_yr = ui->label_Result->text();
        QStringList strlst = i_yr.split(" ");
        int strM = strlst.at(0).toInt();
        int stry = strlst.at(1).toInt();
        QDate s = QDate(stry,strM, 1).addMonths(+1);
        int y = s.year();
        int m = s.month();
        ui->label_Result->setText(QString::number(m)+" "+QString::number(y));
        ui->comboBox_month_y->setCurrentText(QString::number(y));
        ui->comboBox_month_m->setCurrentText(QString::number(m));
    }
    if(ui->radioButton_day->isChecked())
    {
        QString i_yr = ui->label_Result->text();
        QStringList strlst = i_yr.split("-");
        int strD = strlst.at(0).toInt();
        int strM = strlst.at(1).toInt();
        int stry = strlst.at(2).toInt();
        QDate s = QDate(stry,strM,strD).addDays(+1);
        int D = s.day();
        int y = s.year();
        int m = s.month();
        ui->label_Result->setText(QString::number(D)+"-"+QString::number(m)+"-"+QString::number(y));
        ui->comboBox_day_y->setCurrentText(QString::number(y));
        ui->comboBox_day_m->setCurrentText(QString::number(m));
        ui->comboBox_day_d->setCurrentText(QString::number(D));
    }
    if(ui->radioButton_searchbyperiod->isChecked())
    {
        ui->label_Result->setText("");
    }
}

void KPIs_Report::on_toolButton_Versions_clicked()
{
    m_appVersions = new AppVersions(Str_IPAddress,Str_port);
    m_appVersions->show();
    m_appVersions->activateWindow();
}







//void KPIs_Report::Connection_status()
//{

//    socket->connectToHost("10.96.46.55",9876);
//    if(socket->waitForConnected(10000))
//    {
//        socket->write("[{\"username\":\"sateesh\",\"passcode\":\"1234\",\"authkey\":\"abcd\",\"endpoint\":\"listKpi\"}]");
//        socket->waitForBytesWritten(30000);

//        QJsonParseError json_error;
//        QByteArray data;

//        int iBytes=0;
//        int m;
//        for(m=0; m<100; m++)
//        {
//            socket->waitForReadyRead(100);
//            iBytes = socket->bytesAvailable();
//            if (socket->state() != QAbstractSocket::ConnectedState)
//                break;

//            data += socket->readAll();
//            usleep(50000);
//        }
//        QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
//        if (json_error.error != QJsonParseError::NoError)
//        {
//            QMessageBox msgBox;
//            msgBox.setText("JSON parse error: " + json_error.errorString());
//            msgBox.exec();
//        }

//        QJsonObject rootObj = loadDoc.object();
//        QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();

//        QJsonValue fieldSet;
//        QJsonObject fieldObj;

//        for(int i=0; i< fieldDefJSONArray.size(); i++)
//        {
//            fieldSet = fieldDefJSONArray.at(i);
//            fieldObj = fieldSet.toObject();

//            strList_ParameterName << fieldObj.value("paramName").toString();
//            strList_kpiId << fieldObj.value("kpiId").toString();
//            strList_kpiName << fieldObj.value("kpiName").toString();
//            strList_bitMask << fieldObj.value("bitMask").toString();
//        }
//        // close the connection
//        socket->close();
//    }

//}





