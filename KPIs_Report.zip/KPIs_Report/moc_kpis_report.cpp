/****************************************************************************
** Meta object code from reading C++ file 'kpis_report.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "kpis_report.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'kpis_report.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_KPIs_Report_t {
    QByteArrayData data[14];
    char stringdata0[341];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_KPIs_Report_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_KPIs_Report_t qt_meta_stringdata_KPIs_Report = {
    {
QT_MOC_LITERAL(0, 0, 11), // "KPIs_Report"
QT_MOC_LITERAL(1, 12, 27), // "on_m_PshBtn_GetData_clicked"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 15), // "CheckConnection"
QT_MOC_LITERAL(4, 57, 27), // "on_radioButton_year_clicked"
QT_MOC_LITERAL(5, 85, 28), // "on_radioButton_month_clicked"
QT_MOC_LITERAL(6, 114, 26), // "on_radioButton_day_clicked"
QT_MOC_LITERAL(7, 141, 37), // "on_radioButton_searchbyperiod..."
QT_MOC_LITERAL(8, 179, 25), // "on_toolButton_prv_clicked"
QT_MOC_LITERAL(9, 205, 25), // "on_toolButton_nxt_clicked"
QT_MOC_LITERAL(10, 231, 29), // "on_pushButton_connect_clicked"
QT_MOC_LITERAL(11, 261, 43), // "on_comboBox_ConnectedIPs_curr..."
QT_MOC_LITERAL(12, 305, 4), // "arg1"
QT_MOC_LITERAL(13, 310, 30) // "on_toolButton_Versions_clicked"

    },
    "KPIs_Report\0on_m_PshBtn_GetData_clicked\0"
    "\0CheckConnection\0on_radioButton_year_clicked\0"
    "on_radioButton_month_clicked\0"
    "on_radioButton_day_clicked\0"
    "on_radioButton_searchbyperiod_clicked\0"
    "on_toolButton_prv_clicked\0"
    "on_toolButton_nxt_clicked\0"
    "on_pushButton_connect_clicked\0"
    "on_comboBox_ConnectedIPs_currentTextChanged\0"
    "arg1\0on_toolButton_Versions_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_KPIs_Report[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x08 /* Private */,
       3,    0,   70,    2, 0x08 /* Private */,
       4,    0,   71,    2, 0x08 /* Private */,
       5,    0,   72,    2, 0x08 /* Private */,
       6,    0,   73,    2, 0x08 /* Private */,
       7,    0,   74,    2, 0x08 /* Private */,
       8,    0,   75,    2, 0x08 /* Private */,
       9,    0,   76,    2, 0x08 /* Private */,
      10,    0,   77,    2, 0x08 /* Private */,
      11,    1,   78,    2, 0x08 /* Private */,
      13,    0,   81,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,

       0        // eod
};

void KPIs_Report::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<KPIs_Report *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_m_PshBtn_GetData_clicked(); break;
        case 1: _t->CheckConnection(); break;
        case 2: _t->on_radioButton_year_clicked(); break;
        case 3: _t->on_radioButton_month_clicked(); break;
        case 4: _t->on_radioButton_day_clicked(); break;
        case 5: _t->on_radioButton_searchbyperiod_clicked(); break;
        case 6: _t->on_toolButton_prv_clicked(); break;
        case 7: _t->on_toolButton_nxt_clicked(); break;
        case 8: _t->on_pushButton_connect_clicked(); break;
        case 9: _t->on_comboBox_ConnectedIPs_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_toolButton_Versions_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject KPIs_Report::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_KPIs_Report.data,
    qt_meta_data_KPIs_Report,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *KPIs_Report::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *KPIs_Report::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_KPIs_Report.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int KPIs_Report::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
