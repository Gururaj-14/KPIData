/********************************************************************************
** Form generated from reading UI file 'appversions.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPVERSIONS_H
#define UI_APPVERSIONS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AppVersions
{
public:
    QVBoxLayout *verticalLayout_3;
    QTabWidget *tabWidget;
    QWidget *About;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit;
    QWidget *Versions;
    QVBoxLayout *verticalLayout_4;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QLabel *m_csLnScoutparameters;
    QHBoxLayout *m_HLayoutDetectionDis_3;
    QLabel *m_csLnDetectionDistce_3;
    QLabel *pc_Vnum;
    QHBoxLayout *m_HLayoutSpacingFactor_3;
    QLabel *m_csLnSpacingFactor_3;
    QLabel *pc_Date;
    QHBoxLayout *m_HLayoutNoofsonobuys_3;
    QLabel *m_csLnNoofsonobuys_3;
    QTextEdit *pc_Rnote;
    QLabel *m_csLnSensorParameters;
    QHBoxLayout *m_HLayoutDetectionDis;
    QLabel *m_csLnDetectionDistce;
    QLabel *adc_Vnum;
    QHBoxLayout *m_HLayoutSpacingFactor;
    QLabel *m_csLnSpacingFactor;
    QLabel *adc_Date;
    QHBoxLayout *m_HLayoutNoofsonobuys;
    QLabel *m_csLnNoofsonobuys;
    QTextEdit *adc_Rnote;
    QLabel *m_csLnDatumParameters;
    QHBoxLayout *m_HLayoutDetectionDis_4;
    QLabel *m_csLnDetectionDistce_4;
    QLabel *s_Vnum;
    QHBoxLayout *m_HLayoutSpacingFactor_4;
    QLabel *m_csLnSpacingFactor_4;
    QLabel *s_Date;
    QHBoxLayout *m_HLayoutNoofsonobuys_4;
    QLabel *m_csLnNoofsonobuys_4;
    QTextEdit *s_Rnote;
    QLabel *m_csLnDatumParameters_2;
    QHBoxLayout *m_HLayoutDetectionDis_5;
    QLabel *m_csLnDetectionDistce_5;
    QLabel *kpi_Vnum;
    QHBoxLayout *m_HLayoutSpacingFactor_5;
    QLabel *m_csLnSpacingFactor_5;
    QLabel *kpi_Date;
    QHBoxLayout *m_HLayoutNoofsonobuys_5;
    QLabel *m_csLnNoofsonobuys_5;
    QTextEdit *kpi_Rnote;
    QLabel *m_csLnDatumParameters_3;
    QHBoxLayout *m_HLayoutDetectionDis_6;
    QLabel *m_csLnDetectionDistce_6;
    QLabel *kpicron_Vnum;
    QHBoxLayout *m_HLayoutSpacingFactor_6;
    QLabel *m_csLnSpacingFactor_6;
    QLabel *kpicron_Date;
    QHBoxLayout *m_HLayoutNoofsonobuys_6;
    QLabel *m_csLnNoofsonobuys_6;
    QTextEdit *kpicron_Rnote;
    QLabel *m_csLnDatumParameters_4;
    QHBoxLayout *m_HLayoutDetectionDis_7;
    QLabel *m_csLnDetectionDistce_7;
    QLabel *cs_Vnum;
    QHBoxLayout *m_HLayoutSpacingFactor_7;
    QLabel *m_csLnSpacingFactor_7;
    QLabel *cs_Date;
    QHBoxLayout *m_HLayoutNoofsonobuys_7;
    QLabel *m_csLnNoofsonobuys_7;
    QTextEdit *cs_Rnote;

    void setupUi(QWidget *AppVersions)
    {
        if (AppVersions->objectName().isEmpty())
            AppVersions->setObjectName(QString::fromUtf8("AppVersions"));
        AppVersions->resize(417, 644);
        verticalLayout_3 = new QVBoxLayout(AppVersions);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(3, 3, 0, 3);
        tabWidget = new QTabWidget(AppVersions);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setMinimumSize(QSize(414, 0));
        tabWidget->setStyleSheet(QString::fromUtf8("font: 11pt ;"));
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Rounded);
        About = new QWidget();
        About->setObjectName(QString::fromUtf8("About"));
        verticalLayout = new QVBoxLayout(About);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textEdit = new QTextEdit(About);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setReadOnly(true);

        verticalLayout->addWidget(textEdit);

        tabWidget->addTab(About, QString());
        Versions = new QWidget();
        Versions->setObjectName(QString::fromUtf8("Versions"));
        Versions->setStyleSheet(QString::fromUtf8("font: 11pt ;"));
        verticalLayout_4 = new QVBoxLayout(Versions);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        scrollArea = new QScrollArea(Versions);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setMinimumSize(QSize(401, 0));
        scrollArea->setMaximumSize(QSize(400, 16777215));
        scrollArea->setStyleSheet(QString::fromUtf8("/*QScrollArea{\n"
"background:transparent;\n"
"border:none;\n"
"}\n"
"*/"));
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 380, 1018));
        scrollAreaWidgetContents->setMinimumSize(QSize(380, 0));
        scrollAreaWidgetContents->setMaximumSize(QSize(380, 16777215));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setSpacing(5);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(10, 0, 0, 9);
        m_csLnScoutparameters = new QLabel(scrollAreaWidgetContents);
        m_csLnScoutparameters->setObjectName(QString::fromUtf8("m_csLnScoutparameters"));
        m_csLnScoutparameters->setMinimumSize(QSize(150, 24));
        m_csLnScoutparameters->setMaximumSize(QSize(150, 24));
        QFont font;
        font.setFamily(QString::fromUtf8("Open Sans"));
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        m_csLnScoutparameters->setFont(font);
        m_csLnScoutparameters->setStyleSheet(QString::fromUtf8("/*\n"
"color: rgb(93, 226, 255);*/\n"
"\n"
""));
        m_csLnScoutparameters->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(m_csLnScoutparameters);

        m_HLayoutDetectionDis_3 = new QHBoxLayout();
        m_HLayoutDetectionDis_3->setSpacing(20);
        m_HLayoutDetectionDis_3->setObjectName(QString::fromUtf8("m_HLayoutDetectionDis_3"));
        m_csLnDetectionDistce_3 = new QLabel(scrollAreaWidgetContents);
        m_csLnDetectionDistce_3->setObjectName(QString::fromUtf8("m_csLnDetectionDistce_3"));
        m_csLnDetectionDistce_3->setMinimumSize(QSize(140, 24));
        m_csLnDetectionDistce_3->setFont(font);
        m_csLnDetectionDistce_3->setStyleSheet(QString::fromUtf8(""));
        m_csLnDetectionDistce_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutDetectionDis_3->addWidget(m_csLnDetectionDistce_3);

        pc_Vnum = new QLabel(scrollAreaWidgetContents);
        pc_Vnum->setObjectName(QString::fromUtf8("pc_Vnum"));
        pc_Vnum->setMinimumSize(QSize(200, 24));
        pc_Vnum->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutDetectionDis_3->addWidget(pc_Vnum);


        verticalLayout_2->addLayout(m_HLayoutDetectionDis_3);

        m_HLayoutSpacingFactor_3 = new QHBoxLayout();
        m_HLayoutSpacingFactor_3->setSpacing(20);
        m_HLayoutSpacingFactor_3->setObjectName(QString::fromUtf8("m_HLayoutSpacingFactor_3"));
        m_csLnSpacingFactor_3 = new QLabel(scrollAreaWidgetContents);
        m_csLnSpacingFactor_3->setObjectName(QString::fromUtf8("m_csLnSpacingFactor_3"));
        m_csLnSpacingFactor_3->setMinimumSize(QSize(140, 24));
        m_csLnSpacingFactor_3->setFont(font);
        m_csLnSpacingFactor_3->setStyleSheet(QString::fromUtf8(""));
        m_csLnSpacingFactor_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutSpacingFactor_3->addWidget(m_csLnSpacingFactor_3);

        pc_Date = new QLabel(scrollAreaWidgetContents);
        pc_Date->setObjectName(QString::fromUtf8("pc_Date"));
        pc_Date->setMinimumSize(QSize(200, 24));
        pc_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutSpacingFactor_3->addWidget(pc_Date);


        verticalLayout_2->addLayout(m_HLayoutSpacingFactor_3);

        m_HLayoutNoofsonobuys_3 = new QHBoxLayout();
        m_HLayoutNoofsonobuys_3->setSpacing(20);
        m_HLayoutNoofsonobuys_3->setObjectName(QString::fromUtf8("m_HLayoutNoofsonobuys_3"));
        m_csLnNoofsonobuys_3 = new QLabel(scrollAreaWidgetContents);
        m_csLnNoofsonobuys_3->setObjectName(QString::fromUtf8("m_csLnNoofsonobuys_3"));
        m_csLnNoofsonobuys_3->setMinimumSize(QSize(140, 24));
        m_csLnNoofsonobuys_3->setFont(font);
        m_csLnNoofsonobuys_3->setStyleSheet(QString::fromUtf8(""));
        m_csLnNoofsonobuys_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutNoofsonobuys_3->addWidget(m_csLnNoofsonobuys_3);

        pc_Rnote = new QTextEdit(scrollAreaWidgetContents);
        pc_Rnote->setObjectName(QString::fromUtf8("pc_Rnote"));
        pc_Rnote->setMinimumSize(QSize(200, 71));
        pc_Rnote->setMaximumSize(QSize(200, 71));
        pc_Rnote->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pc_Rnote->setReadOnly(true);

        m_HLayoutNoofsonobuys_3->addWidget(pc_Rnote);


        verticalLayout_2->addLayout(m_HLayoutNoofsonobuys_3);

        m_csLnSensorParameters = new QLabel(scrollAreaWidgetContents);
        m_csLnSensorParameters->setObjectName(QString::fromUtf8("m_csLnSensorParameters"));
        m_csLnSensorParameters->setMinimumSize(QSize(170, 24));
        m_csLnSensorParameters->setMaximumSize(QSize(170, 24));
        m_csLnSensorParameters->setFont(font);
        m_csLnSensorParameters->setStyleSheet(QString::fromUtf8("/*\n"
"color: rgb(93, 226, 255);*/\n"
"\n"
""));
        m_csLnSensorParameters->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(m_csLnSensorParameters);

        m_HLayoutDetectionDis = new QHBoxLayout();
        m_HLayoutDetectionDis->setSpacing(20);
        m_HLayoutDetectionDis->setObjectName(QString::fromUtf8("m_HLayoutDetectionDis"));
        m_csLnDetectionDistce = new QLabel(scrollAreaWidgetContents);
        m_csLnDetectionDistce->setObjectName(QString::fromUtf8("m_csLnDetectionDistce"));
        m_csLnDetectionDistce->setMinimumSize(QSize(140, 24));
        m_csLnDetectionDistce->setFont(font);
        m_csLnDetectionDistce->setStyleSheet(QString::fromUtf8(""));
        m_csLnDetectionDistce->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutDetectionDis->addWidget(m_csLnDetectionDistce);

        adc_Vnum = new QLabel(scrollAreaWidgetContents);
        adc_Vnum->setObjectName(QString::fromUtf8("adc_Vnum"));
        adc_Vnum->setMinimumSize(QSize(200, 24));
        adc_Vnum->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutDetectionDis->addWidget(adc_Vnum);


        verticalLayout_2->addLayout(m_HLayoutDetectionDis);

        m_HLayoutSpacingFactor = new QHBoxLayout();
        m_HLayoutSpacingFactor->setSpacing(20);
        m_HLayoutSpacingFactor->setObjectName(QString::fromUtf8("m_HLayoutSpacingFactor"));
        m_csLnSpacingFactor = new QLabel(scrollAreaWidgetContents);
        m_csLnSpacingFactor->setObjectName(QString::fromUtf8("m_csLnSpacingFactor"));
        m_csLnSpacingFactor->setMinimumSize(QSize(140, 24));
        m_csLnSpacingFactor->setFont(font);
        m_csLnSpacingFactor->setStyleSheet(QString::fromUtf8(""));
        m_csLnSpacingFactor->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutSpacingFactor->addWidget(m_csLnSpacingFactor);

        adc_Date = new QLabel(scrollAreaWidgetContents);
        adc_Date->setObjectName(QString::fromUtf8("adc_Date"));
        adc_Date->setMinimumSize(QSize(200, 24));
        adc_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutSpacingFactor->addWidget(adc_Date);


        verticalLayout_2->addLayout(m_HLayoutSpacingFactor);

        m_HLayoutNoofsonobuys = new QHBoxLayout();
        m_HLayoutNoofsonobuys->setSpacing(20);
        m_HLayoutNoofsonobuys->setObjectName(QString::fromUtf8("m_HLayoutNoofsonobuys"));
        m_csLnNoofsonobuys = new QLabel(scrollAreaWidgetContents);
        m_csLnNoofsonobuys->setObjectName(QString::fromUtf8("m_csLnNoofsonobuys"));
        m_csLnNoofsonobuys->setMinimumSize(QSize(140, 24));
        m_csLnNoofsonobuys->setFont(font);
        m_csLnNoofsonobuys->setStyleSheet(QString::fromUtf8(""));
        m_csLnNoofsonobuys->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutNoofsonobuys->addWidget(m_csLnNoofsonobuys);

        adc_Rnote = new QTextEdit(scrollAreaWidgetContents);
        adc_Rnote->setObjectName(QString::fromUtf8("adc_Rnote"));
        adc_Rnote->setMinimumSize(QSize(200, 71));
        adc_Rnote->setMaximumSize(QSize(200, 71));
        adc_Rnote->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        adc_Rnote->setReadOnly(true);

        m_HLayoutNoofsonobuys->addWidget(adc_Rnote);


        verticalLayout_2->addLayout(m_HLayoutNoofsonobuys);

        m_csLnDatumParameters = new QLabel(scrollAreaWidgetContents);
        m_csLnDatumParameters->setObjectName(QString::fromUtf8("m_csLnDatumParameters"));
        m_csLnDatumParameters->setMinimumSize(QSize(150, 24));
        m_csLnDatumParameters->setMaximumSize(QSize(150, 24));
        m_csLnDatumParameters->setFont(font);
        m_csLnDatumParameters->setStyleSheet(QString::fromUtf8("/*\n"
"color: rgb(93, 226, 255);*/\n"
"\n"
""));
        m_csLnDatumParameters->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(m_csLnDatumParameters);

        m_HLayoutDetectionDis_4 = new QHBoxLayout();
        m_HLayoutDetectionDis_4->setSpacing(20);
        m_HLayoutDetectionDis_4->setObjectName(QString::fromUtf8("m_HLayoutDetectionDis_4"));
        m_csLnDetectionDistce_4 = new QLabel(scrollAreaWidgetContents);
        m_csLnDetectionDistce_4->setObjectName(QString::fromUtf8("m_csLnDetectionDistce_4"));
        m_csLnDetectionDistce_4->setMinimumSize(QSize(140, 24));
        m_csLnDetectionDistce_4->setFont(font);
        m_csLnDetectionDistce_4->setStyleSheet(QString::fromUtf8(""));
        m_csLnDetectionDistce_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutDetectionDis_4->addWidget(m_csLnDetectionDistce_4);

        s_Vnum = new QLabel(scrollAreaWidgetContents);
        s_Vnum->setObjectName(QString::fromUtf8("s_Vnum"));
        s_Vnum->setMinimumSize(QSize(200, 24));
        s_Vnum->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutDetectionDis_4->addWidget(s_Vnum);


        verticalLayout_2->addLayout(m_HLayoutDetectionDis_4);

        m_HLayoutSpacingFactor_4 = new QHBoxLayout();
        m_HLayoutSpacingFactor_4->setSpacing(20);
        m_HLayoutSpacingFactor_4->setObjectName(QString::fromUtf8("m_HLayoutSpacingFactor_4"));
        m_csLnSpacingFactor_4 = new QLabel(scrollAreaWidgetContents);
        m_csLnSpacingFactor_4->setObjectName(QString::fromUtf8("m_csLnSpacingFactor_4"));
        m_csLnSpacingFactor_4->setMinimumSize(QSize(140, 24));
        m_csLnSpacingFactor_4->setFont(font);
        m_csLnSpacingFactor_4->setStyleSheet(QString::fromUtf8(""));
        m_csLnSpacingFactor_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutSpacingFactor_4->addWidget(m_csLnSpacingFactor_4);

        s_Date = new QLabel(scrollAreaWidgetContents);
        s_Date->setObjectName(QString::fromUtf8("s_Date"));
        s_Date->setMinimumSize(QSize(200, 24));
        s_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutSpacingFactor_4->addWidget(s_Date);


        verticalLayout_2->addLayout(m_HLayoutSpacingFactor_4);

        m_HLayoutNoofsonobuys_4 = new QHBoxLayout();
        m_HLayoutNoofsonobuys_4->setSpacing(20);
        m_HLayoutNoofsonobuys_4->setObjectName(QString::fromUtf8("m_HLayoutNoofsonobuys_4"));
        m_csLnNoofsonobuys_4 = new QLabel(scrollAreaWidgetContents);
        m_csLnNoofsonobuys_4->setObjectName(QString::fromUtf8("m_csLnNoofsonobuys_4"));
        m_csLnNoofsonobuys_4->setMinimumSize(QSize(140, 24));
        m_csLnNoofsonobuys_4->setFont(font);
        m_csLnNoofsonobuys_4->setStyleSheet(QString::fromUtf8(""));
        m_csLnNoofsonobuys_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutNoofsonobuys_4->addWidget(m_csLnNoofsonobuys_4);

        s_Rnote = new QTextEdit(scrollAreaWidgetContents);
        s_Rnote->setObjectName(QString::fromUtf8("s_Rnote"));
        s_Rnote->setMinimumSize(QSize(200, 71));
        s_Rnote->setMaximumSize(QSize(200, 71));
        s_Rnote->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        s_Rnote->setReadOnly(true);

        m_HLayoutNoofsonobuys_4->addWidget(s_Rnote);


        verticalLayout_2->addLayout(m_HLayoutNoofsonobuys_4);

        m_csLnDatumParameters_2 = new QLabel(scrollAreaWidgetContents);
        m_csLnDatumParameters_2->setObjectName(QString::fromUtf8("m_csLnDatumParameters_2"));
        m_csLnDatumParameters_2->setMinimumSize(QSize(150, 24));
        m_csLnDatumParameters_2->setMaximumSize(QSize(150, 24));
        m_csLnDatumParameters_2->setFont(font);
        m_csLnDatumParameters_2->setStyleSheet(QString::fromUtf8("/*\n"
"color: rgb(93, 226, 255);*/\n"
"\n"
""));
        m_csLnDatumParameters_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(m_csLnDatumParameters_2);

        m_HLayoutDetectionDis_5 = new QHBoxLayout();
        m_HLayoutDetectionDis_5->setSpacing(20);
        m_HLayoutDetectionDis_5->setObjectName(QString::fromUtf8("m_HLayoutDetectionDis_5"));
        m_csLnDetectionDistce_5 = new QLabel(scrollAreaWidgetContents);
        m_csLnDetectionDistce_5->setObjectName(QString::fromUtf8("m_csLnDetectionDistce_5"));
        m_csLnDetectionDistce_5->setMinimumSize(QSize(140, 24));
        m_csLnDetectionDistce_5->setFont(font);
        m_csLnDetectionDistce_5->setStyleSheet(QString::fromUtf8(""));
        m_csLnDetectionDistce_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutDetectionDis_5->addWidget(m_csLnDetectionDistce_5);

        kpi_Vnum = new QLabel(scrollAreaWidgetContents);
        kpi_Vnum->setObjectName(QString::fromUtf8("kpi_Vnum"));
        kpi_Vnum->setMinimumSize(QSize(200, 24));
        kpi_Vnum->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutDetectionDis_5->addWidget(kpi_Vnum);


        verticalLayout_2->addLayout(m_HLayoutDetectionDis_5);

        m_HLayoutSpacingFactor_5 = new QHBoxLayout();
        m_HLayoutSpacingFactor_5->setSpacing(20);
        m_HLayoutSpacingFactor_5->setObjectName(QString::fromUtf8("m_HLayoutSpacingFactor_5"));
        m_csLnSpacingFactor_5 = new QLabel(scrollAreaWidgetContents);
        m_csLnSpacingFactor_5->setObjectName(QString::fromUtf8("m_csLnSpacingFactor_5"));
        m_csLnSpacingFactor_5->setMinimumSize(QSize(140, 24));
        m_csLnSpacingFactor_5->setFont(font);
        m_csLnSpacingFactor_5->setStyleSheet(QString::fromUtf8(""));
        m_csLnSpacingFactor_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutSpacingFactor_5->addWidget(m_csLnSpacingFactor_5);

        kpi_Date = new QLabel(scrollAreaWidgetContents);
        kpi_Date->setObjectName(QString::fromUtf8("kpi_Date"));
        kpi_Date->setMinimumSize(QSize(200, 24));
        kpi_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutSpacingFactor_5->addWidget(kpi_Date);


        verticalLayout_2->addLayout(m_HLayoutSpacingFactor_5);

        m_HLayoutNoofsonobuys_5 = new QHBoxLayout();
        m_HLayoutNoofsonobuys_5->setSpacing(20);
        m_HLayoutNoofsonobuys_5->setObjectName(QString::fromUtf8("m_HLayoutNoofsonobuys_5"));
        m_csLnNoofsonobuys_5 = new QLabel(scrollAreaWidgetContents);
        m_csLnNoofsonobuys_5->setObjectName(QString::fromUtf8("m_csLnNoofsonobuys_5"));
        m_csLnNoofsonobuys_5->setMinimumSize(QSize(140, 24));
        m_csLnNoofsonobuys_5->setFont(font);
        m_csLnNoofsonobuys_5->setStyleSheet(QString::fromUtf8(""));
        m_csLnNoofsonobuys_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutNoofsonobuys_5->addWidget(m_csLnNoofsonobuys_5);

        kpi_Rnote = new QTextEdit(scrollAreaWidgetContents);
        kpi_Rnote->setObjectName(QString::fromUtf8("kpi_Rnote"));
        kpi_Rnote->setMinimumSize(QSize(200, 71));
        kpi_Rnote->setMaximumSize(QSize(200, 71));
        kpi_Rnote->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        kpi_Rnote->setReadOnly(true);

        m_HLayoutNoofsonobuys_5->addWidget(kpi_Rnote);


        verticalLayout_2->addLayout(m_HLayoutNoofsonobuys_5);

        m_csLnDatumParameters_3 = new QLabel(scrollAreaWidgetContents);
        m_csLnDatumParameters_3->setObjectName(QString::fromUtf8("m_csLnDatumParameters_3"));
        m_csLnDatumParameters_3->setMinimumSize(QSize(150, 24));
        m_csLnDatumParameters_3->setMaximumSize(QSize(200, 24));
        m_csLnDatumParameters_3->setFont(font);
        m_csLnDatumParameters_3->setStyleSheet(QString::fromUtf8("/*\n"
"color: rgb(93, 226, 255);*/\n"
"\n"
""));
        m_csLnDatumParameters_3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(m_csLnDatumParameters_3);

        m_HLayoutDetectionDis_6 = new QHBoxLayout();
        m_HLayoutDetectionDis_6->setSpacing(20);
        m_HLayoutDetectionDis_6->setObjectName(QString::fromUtf8("m_HLayoutDetectionDis_6"));
        m_csLnDetectionDistce_6 = new QLabel(scrollAreaWidgetContents);
        m_csLnDetectionDistce_6->setObjectName(QString::fromUtf8("m_csLnDetectionDistce_6"));
        m_csLnDetectionDistce_6->setMinimumSize(QSize(140, 24));
        m_csLnDetectionDistce_6->setFont(font);
        m_csLnDetectionDistce_6->setStyleSheet(QString::fromUtf8(""));
        m_csLnDetectionDistce_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutDetectionDis_6->addWidget(m_csLnDetectionDistce_6);

        kpicron_Vnum = new QLabel(scrollAreaWidgetContents);
        kpicron_Vnum->setObjectName(QString::fromUtf8("kpicron_Vnum"));
        kpicron_Vnum->setMinimumSize(QSize(200, 24));
        kpicron_Vnum->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutDetectionDis_6->addWidget(kpicron_Vnum);


        verticalLayout_2->addLayout(m_HLayoutDetectionDis_6);

        m_HLayoutSpacingFactor_6 = new QHBoxLayout();
        m_HLayoutSpacingFactor_6->setSpacing(20);
        m_HLayoutSpacingFactor_6->setObjectName(QString::fromUtf8("m_HLayoutSpacingFactor_6"));
        m_csLnSpacingFactor_6 = new QLabel(scrollAreaWidgetContents);
        m_csLnSpacingFactor_6->setObjectName(QString::fromUtf8("m_csLnSpacingFactor_6"));
        m_csLnSpacingFactor_6->setMinimumSize(QSize(140, 24));
        m_csLnSpacingFactor_6->setFont(font);
        m_csLnSpacingFactor_6->setStyleSheet(QString::fromUtf8(""));
        m_csLnSpacingFactor_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutSpacingFactor_6->addWidget(m_csLnSpacingFactor_6);

        kpicron_Date = new QLabel(scrollAreaWidgetContents);
        kpicron_Date->setObjectName(QString::fromUtf8("kpicron_Date"));
        kpicron_Date->setMinimumSize(QSize(200, 24));
        kpicron_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutSpacingFactor_6->addWidget(kpicron_Date);


        verticalLayout_2->addLayout(m_HLayoutSpacingFactor_6);

        m_HLayoutNoofsonobuys_6 = new QHBoxLayout();
        m_HLayoutNoofsonobuys_6->setSpacing(20);
        m_HLayoutNoofsonobuys_6->setObjectName(QString::fromUtf8("m_HLayoutNoofsonobuys_6"));
        m_csLnNoofsonobuys_6 = new QLabel(scrollAreaWidgetContents);
        m_csLnNoofsonobuys_6->setObjectName(QString::fromUtf8("m_csLnNoofsonobuys_6"));
        m_csLnNoofsonobuys_6->setMinimumSize(QSize(140, 24));
        m_csLnNoofsonobuys_6->setFont(font);
        m_csLnNoofsonobuys_6->setStyleSheet(QString::fromUtf8(""));
        m_csLnNoofsonobuys_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutNoofsonobuys_6->addWidget(m_csLnNoofsonobuys_6);

        kpicron_Rnote = new QTextEdit(scrollAreaWidgetContents);
        kpicron_Rnote->setObjectName(QString::fromUtf8("kpicron_Rnote"));
        kpicron_Rnote->setMinimumSize(QSize(200, 71));
        kpicron_Rnote->setMaximumSize(QSize(200, 71));
        kpicron_Rnote->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        kpicron_Rnote->setReadOnly(true);

        m_HLayoutNoofsonobuys_6->addWidget(kpicron_Rnote);


        verticalLayout_2->addLayout(m_HLayoutNoofsonobuys_6);

        m_csLnDatumParameters_4 = new QLabel(scrollAreaWidgetContents);
        m_csLnDatumParameters_4->setObjectName(QString::fromUtf8("m_csLnDatumParameters_4"));
        m_csLnDatumParameters_4->setMinimumSize(QSize(150, 24));
        m_csLnDatumParameters_4->setMaximumSize(QSize(195, 24));
        m_csLnDatumParameters_4->setFont(font);
        m_csLnDatumParameters_4->setStyleSheet(QString::fromUtf8("/*\n"
"color: rgb(93, 226, 255);*/\n"
"\n"
""));
        m_csLnDatumParameters_4->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(m_csLnDatumParameters_4);

        m_HLayoutDetectionDis_7 = new QHBoxLayout();
        m_HLayoutDetectionDis_7->setSpacing(20);
        m_HLayoutDetectionDis_7->setObjectName(QString::fromUtf8("m_HLayoutDetectionDis_7"));
        m_csLnDetectionDistce_7 = new QLabel(scrollAreaWidgetContents);
        m_csLnDetectionDistce_7->setObjectName(QString::fromUtf8("m_csLnDetectionDistce_7"));
        m_csLnDetectionDistce_7->setMinimumSize(QSize(140, 24));
        m_csLnDetectionDistce_7->setFont(font);
        m_csLnDetectionDistce_7->setStyleSheet(QString::fromUtf8(""));
        m_csLnDetectionDistce_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutDetectionDis_7->addWidget(m_csLnDetectionDistce_7);

        cs_Vnum = new QLabel(scrollAreaWidgetContents);
        cs_Vnum->setObjectName(QString::fromUtf8("cs_Vnum"));
        cs_Vnum->setMinimumSize(QSize(200, 24));
        cs_Vnum->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutDetectionDis_7->addWidget(cs_Vnum);


        verticalLayout_2->addLayout(m_HLayoutDetectionDis_7);

        m_HLayoutSpacingFactor_7 = new QHBoxLayout();
        m_HLayoutSpacingFactor_7->setSpacing(20);
        m_HLayoutSpacingFactor_7->setObjectName(QString::fromUtf8("m_HLayoutSpacingFactor_7"));
        m_csLnSpacingFactor_7 = new QLabel(scrollAreaWidgetContents);
        m_csLnSpacingFactor_7->setObjectName(QString::fromUtf8("m_csLnSpacingFactor_7"));
        m_csLnSpacingFactor_7->setMinimumSize(QSize(140, 24));
        m_csLnSpacingFactor_7->setFont(font);
        m_csLnSpacingFactor_7->setStyleSheet(QString::fromUtf8(""));
        m_csLnSpacingFactor_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutSpacingFactor_7->addWidget(m_csLnSpacingFactor_7);

        cs_Date = new QLabel(scrollAreaWidgetContents);
        cs_Date->setObjectName(QString::fromUtf8("cs_Date"));
        cs_Date->setMinimumSize(QSize(200, 24));
        cs_Date->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        m_HLayoutSpacingFactor_7->addWidget(cs_Date);


        verticalLayout_2->addLayout(m_HLayoutSpacingFactor_7);

        m_HLayoutNoofsonobuys_7 = new QHBoxLayout();
        m_HLayoutNoofsonobuys_7->setSpacing(20);
        m_HLayoutNoofsonobuys_7->setObjectName(QString::fromUtf8("m_HLayoutNoofsonobuys_7"));
        m_csLnNoofsonobuys_7 = new QLabel(scrollAreaWidgetContents);
        m_csLnNoofsonobuys_7->setObjectName(QString::fromUtf8("m_csLnNoofsonobuys_7"));
        m_csLnNoofsonobuys_7->setMinimumSize(QSize(140, 24));
        m_csLnNoofsonobuys_7->setFont(font);
        m_csLnNoofsonobuys_7->setStyleSheet(QString::fromUtf8(""));
        m_csLnNoofsonobuys_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        m_HLayoutNoofsonobuys_7->addWidget(m_csLnNoofsonobuys_7);

        cs_Rnote = new QTextEdit(scrollAreaWidgetContents);
        cs_Rnote->setObjectName(QString::fromUtf8("cs_Rnote"));
        cs_Rnote->setMinimumSize(QSize(200, 71));
        cs_Rnote->setMaximumSize(QSize(200, 71));
        cs_Rnote->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        cs_Rnote->setReadOnly(true);

        m_HLayoutNoofsonobuys_7->addWidget(cs_Rnote);


        verticalLayout_2->addLayout(m_HLayoutNoofsonobuys_7);

        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout_4->addWidget(scrollArea);

        tabWidget->addTab(Versions, QString());

        verticalLayout_3->addWidget(tabWidget);


        retranslateUi(AppVersions);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(AppVersions);
    } // setupUi

    void retranslateUi(QWidget *AppVersions)
    {
        AppVersions->setWindowTitle(QCoreApplication::translate("AppVersions", "Form", nullptr));
        textEdit->setHtml(QCoreApplication::translate("AppVersions", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"justify\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Pending...</p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(About), QCoreApplication::translate("AppVersions", "About App", nullptr));
        m_csLnScoutparameters->setText(QCoreApplication::translate("AppVersions", "<html><head/><body><p>plcdatacollector</p></body></html>", nullptr));
        m_csLnDetectionDistce_3->setText(QCoreApplication::translate("AppVersions", "Version Number", nullptr));
        pc_Vnum->setText(QString());
        m_csLnSpacingFactor_3->setText(QCoreApplication::translate("AppVersions", "Date", nullptr));
        pc_Date->setText(QString());
        m_csLnNoofsonobuys_3->setText(QCoreApplication::translate("AppVersions", "Release Note", nullptr));
        m_csLnSensorParameters->setText(QCoreApplication::translate("AppVersions", "<html><head/><body><p>alarmdatacollector</p></body></html>", nullptr));
        m_csLnDetectionDistce->setText(QCoreApplication::translate("AppVersions", "Version Number", nullptr));
        adc_Vnum->setText(QString());
        m_csLnSpacingFactor->setText(QCoreApplication::translate("AppVersions", "Date", nullptr));
        adc_Date->setText(QString());
        m_csLnNoofsonobuys->setText(QCoreApplication::translate("AppVersions", "Release Note", nullptr));
        m_csLnDatumParameters->setText(QCoreApplication::translate("AppVersions", "<html><head/><body><p>server</p></body></html>", nullptr));
        m_csLnDetectionDistce_4->setText(QCoreApplication::translate("AppVersions", "Version Number", nullptr));
        s_Vnum->setText(QString());
        m_csLnSpacingFactor_4->setText(QCoreApplication::translate("AppVersions", "Date", nullptr));
        s_Date->setText(QString());
        m_csLnNoofsonobuys_4->setText(QCoreApplication::translate("AppVersions", "Release Note", nullptr));
        m_csLnDatumParameters_2->setText(QCoreApplication::translate("AppVersions", "<html><head/><body><p>kpidata</p></body></html>", nullptr));
        m_csLnDetectionDistce_5->setText(QCoreApplication::translate("AppVersions", "Version Number", nullptr));
        kpi_Vnum->setText(QString());
        m_csLnSpacingFactor_5->setText(QCoreApplication::translate("AppVersions", "Date", nullptr));
        kpi_Date->setText(QString());
        m_csLnNoofsonobuys_5->setText(QCoreApplication::translate("AppVersions", "Release Note", nullptr));
        m_csLnDatumParameters_3->setText(QCoreApplication::translate("AppVersions", "<html><head/><body><p>kpidatacollectioncron</p></body></html>", nullptr));
        m_csLnDetectionDistce_6->setText(QCoreApplication::translate("AppVersions", "Version Number", nullptr));
        kpicron_Vnum->setText(QString());
        m_csLnSpacingFactor_6->setText(QCoreApplication::translate("AppVersions", "Date", nullptr));
        kpicron_Date->setText(QString());
        m_csLnNoofsonobuys_6->setText(QCoreApplication::translate("AppVersions", "Release Note", nullptr));
        m_csLnDatumParameters_4->setText(QCoreApplication::translate("AppVersions", "<html><head/><body><p>commissioning-server</p></body></html>", nullptr));
        m_csLnDetectionDistce_7->setText(QCoreApplication::translate("AppVersions", "Version Number", nullptr));
        cs_Vnum->setText(QString());
        m_csLnSpacingFactor_7->setText(QCoreApplication::translate("AppVersions", "Date", nullptr));
        cs_Date->setText(QString());
        m_csLnNoofsonobuys_7->setText(QCoreApplication::translate("AppVersions", "Release Note", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Versions), QCoreApplication::translate("AppVersions", "Get Versions", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AppVersions: public Ui_AppVersions {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPVERSIONS_H
