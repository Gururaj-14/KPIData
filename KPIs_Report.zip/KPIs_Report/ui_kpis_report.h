/********************************************************************************
** Form generated from reading UI file 'kpis_report.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KPIS_REPORT_H
#define UI_KPIS_REPORT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_KPIs_Report
{
public:
    QVBoxLayout *verticalLayout_8;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_16;
    QToolButton *toolButton;
    QLabel *label;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_3;
    QComboBox *comboBox_ConnectedIPs;
    QPushButton *pushButton_connect;
    QLabel *lbl_error_msg;
    QLabel *lbl_Connection;
    QToolButton *toolButton_Versions;
    QSpacerItem *horizontalSpacer_15;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *tab_2;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_3;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_4;
    QFrame *line;
    QRadioButton *radioButton_year;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer;
    QComboBox *comboBox_year_y;
    QRadioButton *radioButton_month;
    QHBoxLayout *horizontalLayout_13;
    QSpacerItem *horizontalSpacer_9;
    QComboBox *comboBox_month_m;
    QHBoxLayout *horizontalLayout_14;
    QSpacerItem *horizontalSpacer_10;
    QComboBox *comboBox_month_y;
    QRadioButton *radioButton_day;
    QHBoxLayout *horizontalLayout_12;
    QSpacerItem *horizontalSpacer_8;
    QComboBox *comboBox_day_d;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_6;
    QComboBox *comboBox_day_m;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_4;
    QComboBox *comboBox_day_y;
    QRadioButton *radioButton_searchbyperiod;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_11;
    QHBoxLayout *horizontalLayout_5;
    QDateTimeEdit *TimeStamp_StartTime;
    QSpacerItem *horizontalSpacer_14;
    QLabel *label_12;
    QHBoxLayout *horizontalLayout_7;
    QDateTimeEdit *TimeStamp_EndTime;
    QSpacerItem *horizontalSpacer_12;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *m_PshBtn_GetData;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_6;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_text;
    QSpacerItem *horizontalSpacer_13;
    QSpacerItem *verticalSpacer_5;
    QTableWidget *tableWidget_year_count;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_2;
    QToolButton *toolButton_prv;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_Result;
    QSpacerItem *horizontalSpacer_11;
    QToolButton *toolButton_nxt;
    QSpacerItem *verticalSpacer_3;
    QWidget *tab_4;
    QWidget *tab_5;

    void setupUi(QWidget *KPIs_Report)
    {
        if (KPIs_Report->objectName().isEmpty())
            KPIs_Report->setObjectName(QString::fromUtf8("KPIs_Report"));
        KPIs_Report->resize(1007, 721);
        QFont font;
        font.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        KPIs_Report->setFont(font);
        KPIs_Report->setStyleSheet(QString::fromUtf8("font: 11pt \"MS Shell Dlg 2\";\n"
"QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgb(204, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(204, 0, 0);\n"
"font: 10pt \"Open Sans\";\n"
"\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color: rgb(204, 0, 0);\n"
"     color: rgb(255, 255, 255);\n"
" }\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}"));
        verticalLayout_8 = new QVBoxLayout(KPIs_Report);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(-1, 4, -1, -1);
        toolButton = new QToolButton(KPIs_Report);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/C_logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(16, 16));

        horizontalLayout_16->addWidget(toolButton);

        label = new QLabel(KPIs_Report);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(204, 0, 0);"));

        horizontalLayout_16->addWidget(label);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_5);

        label_3 = new QLabel(KPIs_Report);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_16->addWidget(label_3);

        comboBox_ConnectedIPs = new QComboBox(KPIs_Report);
        comboBox_ConnectedIPs->setObjectName(QString::fromUtf8("comboBox_ConnectedIPs"));
        comboBox_ConnectedIPs->setMinimumSize(QSize(170, 30));
        comboBox_ConnectedIPs->setFont(font);
        comboBox_ConnectedIPs->setStyleSheet(QString::fromUtf8("font: 11pt \"MS Shell Dlg 2\";"));
        comboBox_ConnectedIPs->setEditable(true);

        horizontalLayout_16->addWidget(comboBox_ConnectedIPs);

        pushButton_connect = new QPushButton(KPIs_Report);
        pushButton_connect->setObjectName(QString::fromUtf8("pushButton_connect"));
        pushButton_connect->setMinimumSize(QSize(0, 30));
        pushButton_connect->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgb(204, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(204, 0, 0);\n"
"font: 10pt \"Open Sans\";\n"
"\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color: rgb(204, 0, 0);\n"
"     color: rgb(255, 255, 255);\n"
" }\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
""));

        horizontalLayout_16->addWidget(pushButton_connect);

        lbl_error_msg = new QLabel(KPIs_Report);
        lbl_error_msg->setObjectName(QString::fromUtf8("lbl_error_msg"));

        horizontalLayout_16->addWidget(lbl_error_msg);

        lbl_Connection = new QLabel(KPIs_Report);
        lbl_Connection->setObjectName(QString::fromUtf8("lbl_Connection"));
        lbl_Connection->setMinimumSize(QSize(30, 30));
        lbl_Connection->setMaximumSize(QSize(30, 30));
        lbl_Connection->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));

        horizontalLayout_16->addWidget(lbl_Connection);

        toolButton_Versions = new QToolButton(KPIs_Report);
        toolButton_Versions->setObjectName(QString::fromUtf8("toolButton_Versions"));
        toolButton_Versions->setMinimumSize(QSize(0, 30));

        horizontalLayout_16->addWidget(toolButton_Versions);

        horizontalSpacer_15 = new QSpacerItem(2, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_15);


        verticalLayout_2->addLayout(horizontalLayout_16);


        verticalLayout_8->addLayout(verticalLayout_2);

        tabWidget = new QTabWidget(KPIs_Report);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        verticalLayout_7 = new QVBoxLayout(tab_3);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        frame_2 = new QFrame(tab_3);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(frame_2->sizePolicy().hasHeightForWidth());
        frame_2->setSizePolicy(sizePolicy1);
        frame_2->setMinimumSize(QSize(163, 0));
        frame_2->setMaximumSize(QSize(150, 16777215));
        frame_2->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"background-color: rgb(185, 185, 185);\n"
"}\n"
"QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgb(204, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(204, 0, 0);\n"
"font: 10pt \"Open Sans\";\n"
"\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color: rgb(204, 0, 0);\n"
"     color: rgb(255, 255, 255);\n"
" }\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"/*QRadioButton:indicator\n"
"{\n"
"	width  : 15px;\n"
"	height :15 px;\n"
"}\n"
"QRadioButton::indicator:unchecked\n"
"{\n"
"	image:url(:/images/radiounchecked-20x20.png);\n"
"}\n"
"QRadioButton::indicator:checked\n"
"{\n"
"	image:url(:/images/radiochecked-20x20.png);\n"
"}*/"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(frame_2);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_4 = new QLabel(frame_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);

        verticalLayout_4->addWidget(label_4);

        line = new QFrame(frame_2);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_4->addWidget(line);

        radioButton_year = new QRadioButton(frame_2);
        radioButton_year->setObjectName(QString::fromUtf8("radioButton_year"));
        radioButton_year->setFont(font);

        verticalLayout_4->addWidget(radioButton_year);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(-1, -1, 0, -1);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer);

        comboBox_year_y = new QComboBox(frame_2);
        comboBox_year_y->setObjectName(QString::fromUtf8("comboBox_year_y"));
        comboBox_year_y->setMinimumSize(QSize(145, 25));
        comboBox_year_y->setFont(font);
        comboBox_year_y->setEditable(true);

        horizontalLayout_8->addWidget(comboBox_year_y);


        verticalLayout_4->addLayout(horizontalLayout_8);

        radioButton_month = new QRadioButton(frame_2);
        radioButton_month->setObjectName(QString::fromUtf8("radioButton_month"));
        radioButton_month->setFont(font);

        verticalLayout_4->addWidget(radioButton_month);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_9);

        comboBox_month_m = new QComboBox(frame_2);
        comboBox_month_m->setObjectName(QString::fromUtf8("comboBox_month_m"));
        comboBox_month_m->setMinimumSize(QSize(145, 25));
        comboBox_month_m->setFont(font);
        comboBox_month_m->setEditable(true);

        horizontalLayout_13->addWidget(comboBox_month_m);


        verticalLayout_4->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_10);

        comboBox_month_y = new QComboBox(frame_2);
        comboBox_month_y->setObjectName(QString::fromUtf8("comboBox_month_y"));
        comboBox_month_y->setMinimumSize(QSize(145, 25));
        comboBox_month_y->setFont(font);
        comboBox_month_y->setEditable(true);

        horizontalLayout_14->addWidget(comboBox_month_y);


        verticalLayout_4->addLayout(horizontalLayout_14);

        radioButton_day = new QRadioButton(frame_2);
        radioButton_day->setObjectName(QString::fromUtf8("radioButton_day"));
        radioButton_day->setFont(font);

        verticalLayout_4->addWidget(radioButton_day);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_8);

        comboBox_day_d = new QComboBox(frame_2);
        comboBox_day_d->setObjectName(QString::fromUtf8("comboBox_day_d"));
        comboBox_day_d->setMinimumSize(QSize(145, 25));
        comboBox_day_d->setFont(font);
        comboBox_day_d->setEditable(true);

        horizontalLayout_12->addWidget(comboBox_day_d);


        verticalLayout_4->addLayout(horizontalLayout_12);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_6);

        comboBox_day_m = new QComboBox(frame_2);
        comboBox_day_m->setObjectName(QString::fromUtf8("comboBox_day_m"));
        comboBox_day_m->setMinimumSize(QSize(145, 25));
        comboBox_day_m->setFont(font);
        comboBox_day_m->setEditable(true);

        horizontalLayout_10->addWidget(comboBox_day_m);


        verticalLayout_4->addLayout(horizontalLayout_10);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_4);

        comboBox_day_y = new QComboBox(frame_2);
        comboBox_day_y->setObjectName(QString::fromUtf8("comboBox_day_y"));
        comboBox_day_y->setMinimumSize(QSize(145, 25));
        comboBox_day_y->setFont(font);
        comboBox_day_y->setEditable(true);

        horizontalLayout_9->addWidget(comboBox_day_y);


        verticalLayout_4->addLayout(horizontalLayout_9);

        radioButton_searchbyperiod = new QRadioButton(frame_2);
        radioButton_searchbyperiod->setObjectName(QString::fromUtf8("radioButton_searchbyperiod"));
        radioButton_searchbyperiod->setFont(font);

        verticalLayout_4->addWidget(radioButton_searchbyperiod);

        frame_3 = new QFrame(frame_2);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        sizePolicy.setHeightForWidth(frame_3->sizePolicy().hasHeightForWidth());
        frame_3->setSizePolicy(sizePolicy);
        frame_3->setMinimumSize(QSize(0, 173));
        frame_3->setMaximumSize(QSize(16777215, 170));
        frame_3->setStyleSheet(QString::fromUtf8(""));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_3);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 15);
        label_11 = new QLabel(frame_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMaximumSize(QSize(16777215, 15));
        label_11->setFont(font);

        verticalLayout_3->addWidget(label_11);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(2);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(4, -1, 0, -1);
        TimeStamp_StartTime = new QDateTimeEdit(frame_3);
        TimeStamp_StartTime->setObjectName(QString::fromUtf8("TimeStamp_StartTime"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(TimeStamp_StartTime->sizePolicy().hasHeightForWidth());
        TimeStamp_StartTime->setSizePolicy(sizePolicy2);
        TimeStamp_StartTime->setMinimumSize(QSize(120, 30));
        TimeStamp_StartTime->setMaximumSize(QSize(120, 30));
        TimeStamp_StartTime->setFont(font);
        TimeStamp_StartTime->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);\n"
"\n"
""));
        TimeStamp_StartTime->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        TimeStamp_StartTime->setCurrentSection(QDateTimeEdit::DaySection);
        TimeStamp_StartTime->setCalendarPopup(true);

        horizontalLayout_5->addWidget(TimeStamp_StartTime);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_14);


        verticalLayout_3->addLayout(horizontalLayout_5);

        label_12 = new QLabel(frame_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMaximumSize(QSize(16777215, 15));
        label_12->setFont(font);

        verticalLayout_3->addWidget(label_12);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(2);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(4, -1, -1, -1);
        TimeStamp_EndTime = new QDateTimeEdit(frame_3);
        TimeStamp_EndTime->setObjectName(QString::fromUtf8("TimeStamp_EndTime"));
        sizePolicy2.setHeightForWidth(TimeStamp_EndTime->sizePolicy().hasHeightForWidth());
        TimeStamp_EndTime->setSizePolicy(sizePolicy2);
        TimeStamp_EndTime->setMinimumSize(QSize(120, 30));
        TimeStamp_EndTime->setMaximumSize(QSize(120, 30));
        TimeStamp_EndTime->setFont(font);
        TimeStamp_EndTime->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);\n"
"\n"
""));
        TimeStamp_EndTime->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        TimeStamp_EndTime->setCurrentSection(QDateTimeEdit::DaySection);
        TimeStamp_EndTime->setCalendarPopup(true);

        horizontalLayout_7->addWidget(TimeStamp_EndTime);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_12);


        verticalLayout_3->addLayout(horizontalLayout_7);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_2);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_3);

        m_PshBtn_GetData = new QPushButton(frame_3);
        m_PshBtn_GetData->setObjectName(QString::fromUtf8("m_PshBtn_GetData"));
        m_PshBtn_GetData->setMinimumSize(QSize(120, 25));
        m_PshBtn_GetData->setMaximumSize(QSize(100, 25));
        m_PshBtn_GetData->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgb(204, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(204, 0, 0);\n"
"font: 10pt \"Open Sans\";\n"
"\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color: rgb(204, 0, 0);\n"
"     color: rgb(255, 255, 255);\n"
" }\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/save-local.png"), QSize(), QIcon::Normal, QIcon::Off);
        m_PshBtn_GetData->setIcon(icon1);

        horizontalLayout_6->addWidget(m_PshBtn_GetData);


        verticalLayout_3->addLayout(horizontalLayout_6);


        verticalLayout_4->addWidget(frame_3);

        verticalSpacer = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer);


        verticalLayout_5->addLayout(verticalLayout_4);


        horizontalLayout_3->addWidget(frame_2);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(tab_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);

        horizontalLayout->addWidget(label_2);

        horizontalSpacer_2 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        label_text = new QLabel(tab_3);
        label_text->setObjectName(QString::fromUtf8("label_text"));
        label_text->setMinimumSize(QSize(200, 0));
        label_text->setFont(font);
        label_text->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout->addWidget(label_text);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_13);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer_5 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_5);

        tableWidget_year_count = new QTableWidget(tab_3);
        if (tableWidget_year_count->columnCount() < 3)
            tableWidget_year_count->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_year_count->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_year_count->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_year_count->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        tableWidget_year_count->setObjectName(QString::fromUtf8("tableWidget_year_count"));
        tableWidget_year_count->setMinimumSize(QSize(200, 0));
        tableWidget_year_count->setAutoScrollMargin(16);
        tableWidget_year_count->horizontalHeader()->setDefaultSectionSize(250);

        verticalLayout->addWidget(tableWidget_year_count);

        verticalSpacer_4 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_4);


        verticalLayout_6->addLayout(verticalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        toolButton_prv = new QToolButton(tab_3);
        toolButton_prv->setObjectName(QString::fromUtf8("toolButton_prv"));
        toolButton_prv->setMinimumSize(QSize(42, 41));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/icon_nav-start.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_prv->setIcon(icon2);
        toolButton_prv->setIconSize(QSize(35, 35));

        horizontalLayout_2->addWidget(toolButton_prv);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_7);

        label_Result = new QLabel(tab_3);
        label_Result->setObjectName(QString::fromUtf8("label_Result"));
        label_Result->setMinimumSize(QSize(200, 25));
        label_Result->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);\n"
""));
        label_Result->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_Result);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_11);

        toolButton_nxt = new QToolButton(tab_3);
        toolButton_nxt->setObjectName(QString::fromUtf8("toolButton_nxt"));
        toolButton_nxt->setMinimumSize(QSize(42, 41));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/icon_nav_end.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_nxt->setIcon(icon3);
        toolButton_nxt->setIconSize(QSize(35, 35));

        horizontalLayout_2->addWidget(toolButton_nxt);


        verticalLayout_6->addLayout(horizontalLayout_2);

        verticalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_6->addItem(verticalSpacer_3);


        horizontalLayout_3->addLayout(verticalLayout_6);


        verticalLayout_7->addLayout(horizontalLayout_3);

        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        tabWidget->addTab(tab_5, QString());

        verticalLayout_8->addWidget(tabWidget);


        retranslateUi(KPIs_Report);

        tabWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(KPIs_Report);
    } // setupUi

    void retranslateUi(QWidget *KPIs_Report)
    {
        KPIs_Report->setWindowTitle(QCoreApplication::translate("KPIs_Report", "KPIs_Report", nullptr));
        toolButton->setText(QCoreApplication::translate("KPIs_Report", "...", nullptr));
        label->setText(QCoreApplication::translate("KPIs_Report", "KONECRANES", nullptr));
        label_3->setText(QCoreApplication::translate("KPIs_Report", "Connect New & Connected IPs :", nullptr));
        pushButton_connect->setText(QCoreApplication::translate("KPIs_Report", "    Connect   ", nullptr));
        lbl_error_msg->setText(QCoreApplication::translate("KPIs_Report", "<Error message>", nullptr));
        lbl_Connection->setText(QString());
        toolButton_Versions->setText(QCoreApplication::translate("KPIs_Report", "About..", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("KPIs_Report", "Main", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("KPIs_Report", "Diagnostics", nullptr));
        label_4->setText(QCoreApplication::translate("KPIs_Report", "Machinery Counters", nullptr));
        radioButton_year->setText(QCoreApplication::translate("KPIs_Report", "Per Year", nullptr));
        comboBox_year_y->setCurrentText(QString());
        radioButton_month->setText(QCoreApplication::translate("KPIs_Report", "Per Month", nullptr));
        radioButton_day->setText(QCoreApplication::translate("KPIs_Report", "Per Day", nullptr));
        radioButton_searchbyperiod->setText(QCoreApplication::translate("KPIs_Report", "Search by period", nullptr));
        label_11->setText(QCoreApplication::translate("KPIs_Report", "Start Time", nullptr));
        TimeStamp_StartTime->setDisplayFormat(QCoreApplication::translate("KPIs_Report", "dd MMM yy", nullptr));
        label_12->setText(QCoreApplication::translate("KPIs_Report", "End Time", nullptr));
        TimeStamp_EndTime->setDisplayFormat(QCoreApplication::translate("KPIs_Report", "dd MMM yy", nullptr));
#if QT_CONFIG(tooltip)
        m_PshBtn_GetData->setToolTip(QCoreApplication::translate("KPIs_Report", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Open Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:600;\">Click to Go</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        m_PshBtn_GetData->setText(QCoreApplication::translate("KPIs_Report", "GET DATA", nullptr));
        label_2->setText(QCoreApplication::translate("KPIs_Report", " Period:", nullptr));
        label_text->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidget_year_count->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("KPIs_Report", "KPIs", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_year_count->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("KPIs_Report", "Drivestarts\\h", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_year_count->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("KPIs_Report", "Starts", nullptr));
        toolButton_prv->setText(QCoreApplication::translate("KPIs_Report", "...", nullptr));
        label_Result->setText(QString());
        toolButton_nxt->setText(QCoreApplication::translate("KPIs_Report", "...", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("KPIs_Report", "Statistics", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("KPIs_Report", "Production", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QCoreApplication::translate("KPIs_Report", "Trendtool", nullptr));
    } // retranslateUi

};

namespace Ui {
    class KPIs_Report: public Ui_KPIs_Report {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KPIS_REPORT_H
