/*
FileName	:commissionsetting.cpp
Purpose     :
Authour     :Gururaj B M & Kasturi Rangan.
*/

#include "commissionsetting.h"
#include "ui_commissionsetting.h"
#include "version.h"
#define GROUPSAVE "IP_PORT_GROUP_SAVE"
#define GROUP "IP_PORT_GROUP"
#define SUDOPASWD "Server_sudo_pswd"
#define KEY "IP_key"
#define DEFAULT_IP_PORT "10.96.46.55:9876"
//#define DEFAULT_PORT "9876"

CommissionSetting::CommissionSetting(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::CommissionSetting)
{
    ui->setupUi(this);

    QString Title = QString("Data Logger Commissioning Tool V %1.%2.%3").arg(VERSION_MAJ).arg(VERSION_MIN).arg(VERSION_REV);
    this->setWindowTitle(Title);

    // ui->label_password->hide();
    // ui->lEdt_Passwd->hide();
    // ui->pbtn_Passwd_Save->hide();

    //ui->m_lblLP_19->setHidden(true);

    QRegularExpression rx("[0-9]{4,5}");
    QValidator *validator = new QRegularExpressionValidator(rx, this);

    ui->lineEdit_APIPort->setValidator(validator);
    ui->lineEdit_DataPort->setValidator(validator);
    ui->lineEdit_AlarmPort->setValidator(validator);
    ui->kpi_port_lineEdit->setValidator(validator);
    ui->kpi_report_port_lineEdit->setValidator(validator);

    QRegularExpression per("[0-9]{1,2}");
    QValidator *perValidator = new QRegularExpressionValidator(per,this);
    ui->percenatge_lineEdit->setValidator(perValidator);

    QRegularExpression rj("([0-9]{0,3}[.]){3}[0-9]{0,3}[:][0-9]{4,5}");
    QValidator *validator1 = new QRegularExpressionValidator(rj, this);
    ui->comboBox_ConnectedIPs->setValidator(validator1);

    Disablefunc();

    QDateTime CurrentEndDateTime = QDateTime::currentDateTime();
    ui->TimeStamp_Date->setDateTime(CurrentEndDateTime);
    ui->timeEdit_Time->setTime(CurrentEndDateTime.time());

    socket_utc = new QTcpSocket(this);
    m_pingThread = new QThread();
    m_pingTimer = new QTimer();
    m_pingTimer->setInterval(10000);
    m_pingTimer->moveToThread(m_pingThread);
    connect(m_pingThread,SIGNAL(started()),m_pingTimer,SLOT(start()));
    connect(m_pingTimer,SIGNAL(timeout()),this,SLOT(CheckConnection()));

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(updateTime()));

    connect(ui->comboBox_databases,SIGNAL(currentTextChanged(QString)),this,SLOT(onComboTextChanged(QString)));

    ReloadDefaultIps();
    ReloadLastSelectedIPs();
    ChangeTimeZone();
    // Default_Alarm_Port();
}

CommissionSetting::~CommissionSetting()
{
    delete ui;
}
void CommissionSetting::updateTime()
{
    //qDebug() << "here"<<":"<<iSecs;
    if(bCalledApi)
        return;

    if(iSecs%60==59)
    {
        bCalledApi=true;
        // QtConcurrent::run(this,&CommissionSetting::UpdateTimezoneUTC);
        UpdateTimezoneUTC();
    }
    else
    {
        iSecs = (iSecs+1)%60;
        QString utcTime = ui->label_UTC_Time->text();
        if(utcTime != "")
        {
            utcTime = utcTime.left(utcTime.length()-2) + QString::number(iSecs).rightJustified(2, '0');
        }
        QString localeTime = ui->label_Locale_time->text();
        if(localeTime != "")
        {
            localeTime = localeTime.left(localeTime.length()-2) + QString::number(iSecs).rightJustified(2, '0');;
        }
        ui->label_UTC_Time->setText(utcTime);
        ui->label_Locale_time->setText(localeTime);
    }

}
void CommissionSetting::ReloadDefaultIps()
{
    QSettings setting("Finecho_IP_Port_Save","IP_Port_Details_Save");
    setting.beginGroup(GROUPSAVE);
    foreach (const QString &key, setting.childKeys())
    {
        QString value = setting.value(key).toString();
        ui->comboBox_ConnectedIPs->addItem(value);
    }
    setting.endGroup();
}

void CommissionSetting::onComboTextChanged(QString port)
{
    Q_UNUSED(port);

    if(ui->comboBox_databases->currentIndex()==-1)
    {
        //  qDebug() <<"index out of range";
    }else{
        sourceCurrentIndex = ui->comboBox_databases->currentIndex();
        QString source = ui->comboBox_databases->currentText();
       // ui->comboBox_databases->setMinimumWidth((source.length())*12);
       // qDebug() << source.length()*15;
    }

    if(Data_Port.size()==Data_Sources.size() && Data_Port.size()>0){

        QString currentPort = Data_Port.at(sourceCurrentIndex);
         //qDebug() <<"curPort:"<< currentPort;
        ui->lineEdit_DataPort->setText(Data_Port.at(sourceCurrentIndex));
    }
}

void CommissionSetting::ReloadLastSelectedIPs()
{
    QSettings settings("Finecho_IP_Port","IP_Port_Details");
    settings.beginGroup(GROUP);
    QString value = settings.value(KEY).toString();
    ui->comboBox_ConnectedIPs->setCurrentText(value);
    ui->comboBox_ConnectedIPs->setMinimumWidth(value.length()*12);
    QStringList strlst = value.split(':');
    int dSize = value.length();
    QString strIP,strPort;
    if(dSize > 0){
        strIP = strlst.at(0);
        strPort = strlst.at(1);
        ConnectToIp_Port(strIP,strPort);
    }
    else
    {
        strIP = "127.0.0.1";
        strPort = "6789";
        ConnectToIp_Port(strIP,strPort);
    }
    settings.endGroup();
}

void CommissionSetting::ConnectToIp_Port(QString strIP, QString strPort)
{
    socket = new QTcpSocket(this);

    socket->connectToHost(strIP, strPort.toInt());

    if(socket->waitForConnected(10000))
    {
        //bool statusConn = socket->ConnectedState;

        m_pingThread->exit();
        QSettings setting("Finecho_IP_Port_Save","IP_Port_Details_Save");
        setting.beginGroup(GROUPSAVE);
        int i=0;
        QStringList lst = setting.allKeys();
        if(lst.length() == 0)
        {
            setting.setValue(strIP, strIP+":"+strPort);
        }
        foreach (const QString &key, setting.childKeys())
        {
            int num = lst.length();
            QString value = setting.value(key).toString();
            if(value != strIP+":"+strPort )
            {
                i++;
            }
            if(num == i)
            {
                setting.setValue(strIP, strIP+":"+strPort);
            }
        }
        QStringList strlst;
        foreach (const QString &key, setting.childKeys())
        {
            QString value = setting.value(key).toString();
            strlst << value;
            ui->comboBox_ConnectedIPs->addItem(value);
        }
        strlst.removeDuplicates();

        ui->comboBox_ConnectedIPs->clear();
        ui->comboBox_ConnectedIPs->addItems(strlst);
        ui->comboBox_ConnectedIPs->setCurrentText(strIP+":"+strPort);

        // ui->label_password->setText(strIP +" SU Credentials");
        setting.endGroup();

        ui->lbl_Connection->setStyleSheet("background-color:green;");
        ui->pushButton_connect->setText("Connected");

        ui->lbl_error_msg->setText("");

        // close the connection
        socket->close();
        //============================
        Str_IPAddress = strIP;
        Str_port = strPort;

        QSettings settings("Finecho_IP_Port","IP_Port_Details");
        settings.beginGroup(GROUP);
        settings.setValue(KEY, strIP+":"+strPort);
        settings.endGroup();

        m_pingThread->start();
        timer->start(1000);
        iSecs = 59;
        Enablefunc();
        showDefaultPorts();

        Default_Alarm_Port();

        Default_CPU_and_Memory_Logging_status();

        //  showFirstTimePassword();


        socket1 = new QTcpSocket(this);
        if(socket1->state() == QAbstractSocket::UnconnectedState)
        {
            socket1->connectToHost(strIP, strPort.toInt());
        }
    }
    else
    {
        m_pingThread->exit();
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_error_msg->setText("Not Connected");
        //ui->comboBox_ConnectedIPs->setMinimumWidth((ui->comboBox_ConnectedIPs->currentText().length())*12);
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        // showFirstTimePassword();
    }
}

void CommissionSetting::on_pushButton_connect_clicked()
{
    QString strIPAddress, strIPPort, strIP;
    QStringList strParts;
    bool bFlag=false;

    strIP = ui->comboBox_ConnectedIPs->currentText();
    strParts = strIP.split(":");
    strIPAddress = strParts.at(0);
    if(strParts.count()<2)
        strIPPort = DEFAULT_PORT;
    else
        strIPPort = strParts.at(1);

    if(strIPAddress.split(".").count()==4)
    {
        QHostAddress address(strIPAddress);
        if(QAbstractSocket::IPv4Protocol==address.protocol())
        {
            bFlag= true;
        }
        else if(QAbstractSocket::IPv6Protocol==address.protocol())
        {
            bFlag= true;
        }
        else
        {
            QMessageBox::information(this,"Warning","Not a Valid IP Address");
            bFlag= false;
        }
    }
    else
    {
        QMessageBox::information(this,"Warning","Not a Valid IP Address");
        bFlag= false;
    }

    if(bFlag==true)
    {
        if(ui->comboBox_ConnectedIPs->findText(strIP,Qt::MatchExactly) == -1)
        {
            //Save to local disk here
        }
        ConnectToIp_Port(strIPAddress,strIPPort);
    }
}

void CommissionSetting::on_comboBox_ConnectedIPs_currentTextChanged(const QString &arg1)
{
    Q_UNUSED(arg1);
    Disablefunc();
    m_pingThread->exit();
    ui->pushButton_connect->setText("Connect");

    //    if(ui->radioBtn_Alarm640->isChecked()){
    //        ui->radioBtn_Alarm640->setChecked(false);
    //        qDebug() << "640";
    //    }else{
    //        ui->radioBtn_Alarm1280->setChecked(false);
    //        qDebug() << "1280";
    //    }

    ui->label_Alarm_message->setText("");
    ui->kpi_port_label_message->setText("");
    ui->kpi_report_port_label_message->setText("");
    ui->comboBox_databases->clear();
    clearWidgets();
    timer->stop();
    ui->lbl_Connection->setStyleSheet("background-color:red;");
}
void CommissionSetting::UpdateTimezoneUTC()
{
    QJsonObject jsonKeys_serverUTCTime;
    QJsonDocument jsonDoc_serverUTCTime;
    QJsonArray jsonArray_serverUTCTime;

    jsonKeys_serverUTCTime.insert("username","rushikesh");
    jsonKeys_serverUTCTime.insert("passcode","finecho@178");
    jsonKeys_serverUTCTime.insert("authkey","abcd");
    jsonKeys_serverUTCTime.insert("endpoint","showUTCtimeAndLocaltime");
    jsonArray_serverUTCTime.append(jsonKeys_serverUTCTime);
    jsonDoc_serverUTCTime = QJsonDocument(jsonArray_serverUTCTime);
    QByteArray data;
    QByteArray jByte(jsonDoc_serverUTCTime.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));


    socket_utc->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket_utc->waitForConnected(10000))
    {
        socket_utc->write(strLen.toUtf8());
        socket_utc->waitForBytesWritten(30000);

        socket_utc->write(jByte);
        socket_utc->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket_utc->waitForReadyRead(1000);
            iBytes = socket_utc->bytesAvailable();
            if(socket_utc->state() != QAbstractSocket::ConnectedState)
                break;
            data += socket_utc->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    } else{

        QMessageBox msgBox;
        msgBox.setText("Error: " + socket_utc->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        // m_pingThread->exit();
        // timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        bCalledApi=false;
        m_pingThread->exit();
        timer->stop();
        return;

    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString utctime;
    QString localtime;
    QString localtimezone;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    utctime = fieldObj.value("utctime").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    localtime = fieldObj.value("localtime").toString();

    fieldSet = fieldDefJSONArray.at(2);
    fieldObj = fieldSet.toObject();
    localtimezone = fieldObj.value("localtimezone").toString();

    socket_utc->close();

    if(utctime != "")
    {
        ui->label_UTC_Time->setText(utctime.trimmed());
        ui->label_Locale_time->setText("[" + localtimezone + "]" + " " + localtime.trimmed());
        iSecs = utctime.trimmed().right(2).toInt();
        ilocSecs = localtime.trimmed().right(2).toInt();
        bCalledApi=false;
    }
    else
    {
        ui->label_UTC_Time->setText("");
        ui->label_Locale_time->setText("");
        bCalledApi=false;
    }
}

void CommissionSetting::CheckConnection()
{
    if(socket1->state() == QAbstractSocket::UnconnectedState)
    {
        socket1->connectToHost(Str_IPAddress, Str_port.toInt());
    }

    if(socket1->state() == QAbstractSocket::ConnectedState)
    {
        ui->lbl_Connection->setStyleSheet("background-color:green;");
        ui->pushButton_connect->setText("Connected");
        ui->lbl_error_msg->setText("");
    }
    else
    {
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();

    }
}
void CommissionSetting::clearWidgets()
{
    ui->label_UTC_Time->clear();
    ui->label_AWLFile->clear();
    ui->label_Locale_time->clear();
    ui->lineEdit_DataPort->clear();
    ui->lineEdit_AlarmPort->clear();
    ui->lineEdit_APIPort->clear();
    ui->CPU_Memory_logging_label->clear();
    ui->kpi_port_lineEdit->clear();
    ui->kpi_report_port_lineEdit->clear();
    ui->percenatge_lineEdit->clear();

  /*  if(ui->radioBtn_Alarm640->isChecked()){
        //ui->radioBtn_Alarm640->setAutoExclusive(false);
        ui->radioBtn_Alarm640->setChecked(false);
       // ui->radioBtn_Alarm640->setAutoExclusive(true);
    }else{
       // ui->radioBtn_Alarm1280->setAutoExclusive(false);
        ui->radioBtn_Alarm1280->setChecked(false);
       // ui->radioBtn_Alarm1280->setAutoExclusive(true);
    }

    if(ui->rBtn_active->isChecked()){
       // ui->rBtn_active->setAutoExclusive(false);
        ui->rBtn_active->setChecked(false);
        //ui->rBtn_active->setAutoExclusive(true);
    }else{
      //  ui->rBtn_deActive->setAutoExclusive(false);
        ui->rBtn_deActive->setChecked(false);
      //  ui->rBtn_deActive->setAutoExclusive(true);
    }   */

    QAbstractButton *checked1 = ui->buttonGroup_1->checkedButton();
    if(checked1){
        ui->buttonGroup_1->setExclusive(false);
        checked1->setChecked(false);
        ui->buttonGroup_1->setExclusive(true);
    }

    QAbstractButton *checked2 = ui->buttonGroup_2->checkedButton();
    if(checked2){
        ui->buttonGroup_2->setExclusive(false);
        checked2->setChecked(false);
        ui->buttonGroup_2->setExclusive(true);
    }

}

void CommissionSetting::ChangeTimeZone()
{
    QStringList strLstlines;
    QFile file(qApp->applicationDirPath()+"/timezones.txt");
    if(!file.open(QFile::ReadOnly | QFile::Text))
    {
        qDebug() << " Could not open the file for reading";
        return;
    }
    while (!file.atEnd())
    {
        QByteArray line = file.readLine();
        strLstlines << QString(line).simplified();
    }
    ui->comboBox_Locale->addItems(strLstlines);
    file.close();
}

void CommissionSetting::on_m_PshBtn_UTC_Time_clicked()
{
    QDateTime startDateTime;
    QByteArray data;
    startDateTime = ui->TimeStamp_Date->dateTime();
    QString DTime = startDateTime.toString("yyyy-MM-dd hh:mm:ss");

    QJsonObject jsonKeys_serverUTCTime;
    QJsonDocument jsonDoc_serverUTCTime;
    QJsonArray jsonArray_serverUTCTime;

    QString password;

    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/

    jsonKeys_serverUTCTime.insert("username","rushikesh");
    jsonKeys_serverUTCTime.insert("passcode","finecho@178");
    jsonKeys_serverUTCTime.insert("authkey","abcd");
    jsonKeys_serverUTCTime.insert("endpoint","changeUTCtime");
    // jsonKeys_serverUTCTime.insert("password",password);
    jsonKeys_serverUTCTime.insert("newTime",DTime);
    jsonArray_serverUTCTime.append(jsonKeys_serverUTCTime);
    jsonDoc_serverUTCTime = QJsonDocument(jsonArray_serverUTCTime);
    //qDebug() << "jsonDoc_serverUTCTime===" << jsonDoc_serverUTCTime;
    QByteArray jByte(jsonDoc_serverUTCTime.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));
    //qDebug() << "strLen===" << strLen;
    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            iBytes = socket->bytesAvailable();
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);
    } else
    {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("Description").toString();
    socket->close();

    if(result == ""){
        result = "Failed";
    }
    if(result == "Success"){
        iSecs = 59;
    }

    QString message = QString("Change Server UTC Time: " + result + "\n" + Description);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_LocaleTime_clicked()
{
    QJsonObject jsonKeys_serverLocaleTime;
    QJsonDocument jsonDoc_serverLocaleTime;
    QJsonArray jsonArray_serverLocaleTime;

    QString timeZone = ui->comboBox_Locale->currentText();
    QString password ;
    /*= decryptData(Str_IPAddress);

    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys_serverLocaleTime.insert("username","rushikesh");
    jsonKeys_serverLocaleTime.insert("passcode","finecho@178");
    jsonKeys_serverLocaleTime.insert("authkey","abcd");
    jsonKeys_serverLocaleTime.insert("endpoint","changeTimeZone");
    //jsonKeys_serverLocaleTime.insert("password",password);
    jsonKeys_serverLocaleTime.insert("timezone",timeZone);
    jsonArray_serverLocaleTime.append(jsonKeys_serverLocaleTime);
    jsonDoc_serverLocaleTime = QJsonDocument(jsonArray_serverLocaleTime);
    QByteArray data;
    QByteArray jByte(jsonDoc_serverLocaleTime.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    //  qDebug() << jsonDoc_serverLocaleTime;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);
        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    } else
    {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    //qDebug() << data;
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("Description").toString();

    socket->close();

    if(result == ""){
        result = "Failed";
    }
    if(result == "Success"){
        iSecs = 59;
    }

    QString message = QString("Change Server Locale Time: " + result + "\n" + Description);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_toolButton_AWLFile_clicked()
{

    QStringList splitter;
     Awl_filePath  = QFileDialog::getOpenFileName(this,tr("Load From File"),"",tr("All files (*.db *.AWL *.awl *.DB);;"));
     splitter =  Awl_filePath.split("/");
     int nShpCnt = splitter.count() - 1;
     QString Path = splitter.at(nShpCnt);

     if(Path!="")
         ui->label_AWLFile->setText(Path);
     else
         ui->label_AWLFile->setText("selected AWL");

     QFileInfo fileInfo(Awl_filePath);
    // QString name = fileInfo.fileName();
     QStringList filePath = Awl_filePath.split(fileInfo.fileName());
     QDir dir(filePath.at(0));

     if(dir.exists() && Awl_filePath!=""){
         ui->m_PshBtn_AWLFileUpload->setEnabled(true);
     }else{
         ui->m_PshBtn_AWLFileUpload->setEnabled(false);
     }

}
void CommissionSetting::on_m_PshBtn_AWLFileUpload_clicked()
{
    QStringList strLstlines;
    QJsonDocument jsonDoc,jsonDocNew;
    QByteArray line;
    QFile file(Awl_filePath);
    if (!file.open(QIODevice::ReadOnly))   //|| ui->label_AWLFile->text()=="")
    {
        QString message = file.errorString();
        QMessageBox::information(this,"Result", message );
        return;
    }

    while (!file.atEnd())
    {
        line = file.readLine();
        strLstlines << QString(line).simplified();
    }
   // qDebug() << strLstlines;

   // Awl_filePath.clear();
    file.close();

    QJsonObject jsonAPI,jsonKeys;
    QJsonArray json_lineArray,line_array;
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("port",ui->lineEdit_DataPort->text());
    jsonKeys.insert("source",ui->comboBox_databases->currentText());
    jsonKeys.insert("endpoint","awlfile");
    QJsonArray param_lines;

    for (int i=0;i < strLstlines.length();i++)
    {
        param_lines.append(strLstlines.at(i).trimmed());
    }

    jsonKeys.insert("line",QJsonValue(param_lines));
    json_lineArray.append(jsonKeys);
    jsonDoc = QJsonDocument(json_lineArray);

    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));
    QByteArray data;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());

    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);


        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);
    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }

    QJsonParseError json_error;

    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }
    qDebug() << loadDoc;

    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QString result;
    QString Description_af_create,Description_af_update,Description_at_create;
    QString serviceStatus;

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();


    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    if(result=="success"){
        fieldSet = fieldDefJSONArray.at(4);
        fieldObj = fieldSet.toObject();
        serviceStatus = fieldObj.value("service").toString();
    }

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description_af_create = fieldObj.value("Description_af_create").toString();

    fieldSet = fieldDefJSONArray.at(2);
    fieldObj = fieldSet.toObject();
    Description_af_update = fieldObj.value("Description_af_update").toString();

    fieldSet = fieldDefJSONArray.at(3);
    fieldObj = fieldSet.toObject();
    Description_at_create = fieldObj.value("Description_at_create").toString();

    socket->close();

    QString message = QString("AWL_Confugration : " + result + "\n" + Description_af_create + "\n" + Description_af_update + "\n" +Description_at_create +"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}
void CommissionSetting::on_comboBox_ConnectedIPs_currentIndexChanged(const QString &arg1)
{
    //    ui->lEdt_Passwd->clear();
    //    QString strIP;
    //    QString add;
    //    strIP = arg1;
    //    QStringList strlst = strIP.split(':');
    //    int dSize = strlst.length();
    //    if(dSize > 0)
    //    {
    //        add = strlst.at(0);
    //    }
    //    ui->label_password->setText(add +" SU Credentials");
    //    QSettings setting("Finecho_SudoPaswd","Finecho_SudoPaswd_Details");
    //    setting.beginGroup(SUDOPASWD);
    //    ui->lEdt_Passwd->setText(setting.value(add).toString());
    //    setting.endGroup();
    Q_UNUSED(arg1);

}

void CommissionSetting::on_m_PshBtn_PLCDataPortSave_clicked()
{
    //    QString dataPort = ui->lineEdit_DataPort->text();
    if (Data_Port.size()>0)  oldPortData = Data_Port.at(sourceCurrentIndex);

    currentPort=ui->lineEdit_DataPort->text();
    if(currentPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }

    if(currentPort.toInt() < 4096 || currentPort.toInt()>65535){
        QMessageBox msgBox;
        msgBox.setText("Enter the valid Data Port Number \n"
                       "Port Range should be between 4096 and 65535");
        msgBox.exec();
        ui->lineEdit_DataPort->setText(oldPortData);
        return;
    }

    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password ;
    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","PortChangeForData");
    //jsonKeys.insert("password",password);
    jsonKeys.insert("port",currentPort);
    jsonKeys.insert("oldport",oldPortData);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }

    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;
    QString serviceStats;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    if(result=="success"){
        if(Data_Port.size()>0){
            Data_Port[sourceCurrentIndex]=currentPort;
            fieldSet=fieldDefJSONArray.at(2);
            fieldObj=fieldSet.toObject();
            serviceStats=fieldObj.value("service").toString();
        }
    }else if(result=="fail" || result =="failed" || result == "failed_1"){
        ui->lineEdit_DataPort->setText(oldPortData);
    }

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("reason").toString();

    socket->close();

    QString message = QString("Change Data Port: " + result + "\n" + Description+"\n"+serviceStats);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_PLCAlarmPortSave_clicked()
{
    QString dataPort = ui->lineEdit_AlarmPort->text();

    if(dataPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }

    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password;


    if(dataPort.toInt() < 4096 || dataPort.toInt()>65535){
        QMessageBox msgBox;
        msgBox.setText("Enter the valid Alarm Port Number \n"
                       "Port Range should be between 4096 and 65535");
        msgBox.exec();
        ui->lineEdit_AlarmPort->setText(oldPortAlarm);
        return;
    }

    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","PortChangeForAlarms");
    jsonKeys.insert("port",dataPort);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);
       // int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
           // iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
       // Q_UNUSED(iBytes);

    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }

    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));

    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();

    //qDebug() << rootObj;

    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;
    QString serviceStatus;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    if(result=="fail" || result =="failed")
        ui->lineEdit_AlarmPort->setText(oldPortAlarm);
    else{
        oldPortAlarm=dataPort;
        fieldSet=fieldDefJSONArray.at(2);
        fieldObj=fieldSet.toObject();
        serviceStatus=fieldObj.value("service").toString();
    }

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("reason").toString();

    socket->close();

    QString message = QString("Change Alarm Port: " + result + "\n" + Description+"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_API_Set_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString apiPort = ui->lineEdit_APIPort->text();
    if(apiPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
      //  ui->lineEdit_APIPort->setText(oldPortDataloggerAPI);
        return;
    }

    if(apiPort.toInt() < 4096 || apiPort.toInt()>65535){
        QMessageBox msgBox;
        msgBox.setText("Enter the valid  Port Number \n"
                       "Port Range should be between 4096 and 65535");
        msgBox.exec();
        ui->lineEdit_APIPort->setText(oldPortDataloggerAPI);
        return;
    }


    QString password ;
    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","dataloggerapiPortChange");
    jsonKeys.insert("port",apiPort);
    // jsonKeys.insert("password",password);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;

    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    // qDebug() << jsonDoc;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());

    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);


    }else{

        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();

     qDebug() << rootObj;

    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;
    QString serviceStatus;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    if(result=="fail" || result =="failed")
        ui->lineEdit_APIPort->setText(oldPortDataloggerAPI);
    else{
        fieldSet=fieldDefJSONArray.at(2);
        fieldObj=fieldSet.toObject();
        serviceStatus=fieldObj.value("service").toString();
        oldPortDataloggerAPI=apiPort;
    }

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("reason").toString();

    socket->close();

    QString message = QString("Datalogger-API-PortChange: " + result + "\n" + Description+"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_API_Check_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString apiPort = ui->lineEdit_APIPort->text();
    if(apiPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }
    QString password ;
    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","checkDataloggerAPIservice");
    jsonKeys.insert("port",apiPort);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    //  qDebug() << jsonDoc;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());

    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);
        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);


    } else {
        QMessageBox msgBox;
        // qDebug() << socket->state();
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();

    //qDebug() << rootObj;

    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("status").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("Description").toString();

    socket->close();

    QString message = QString("API Service Status: " + result + "\n" + Description);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_API_Reset_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password ;
    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","RestoreAndDefault");
    // jsonKeys.insert("password",password);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());

    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);


    }else {

        // qDebug()<< socket->state();

        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;
    QString serviceStatus;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("reason").toString();

    socket->close();

    if(result == "success"){
        ui->lineEdit_APIPort->setText("6789");
        oldPortDataloggerAPI="6789";
        fieldSet=fieldDefJSONArray.at(2);
        fieldObj=fieldSet.toObject();
        serviceStatus=fieldObj.value("service").toString();
    }else if(Description == "Provided port is busy,Please provide different port no."){
        ui->lineEdit_APIPort->setText("6789");
    }

    QString message = QString("Reset port: " + result + "\n" + Description +"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}

QString CommissionSetting::encryptData(QString strPswd)
{
    QByteArray ba;
    ba.append(strPswd);
    return ba.toBase64();
}

QString CommissionSetting::decryptData(QString strIP)
{
    QString DecryptStr;
    QSettings setting("Finecho_SudoPaswd","Finecho_SudoPaswd_Details");
    setting.beginGroup(SUDOPASWD);
    DecryptStr =  setting.value(strIP).toString();
    QByteArray ba;
    ba.append(DecryptStr);
    return QByteArray::fromBase64(ba);
}

/*void CommissionSetting::on_pbtn_Passwd_Save_clicked() // not calling
{
    if(ui->lEdt_Passwd->text() == "")
    {
        QString message = QString(" IP does not have sudo password");
        QMessageBox::information(this,"Erorr", message );
        return;
    }
    QString IPName_Paswd = ui->lEdt_Passwd->text();
    QString IPName = ui->label_password->text().trimmed();
    QStringList strlst = IPName.split(" ");
    int dSize = strlst.length();
    QString strIP,strPort;
    if(dSize > 0)
    {
        strIP = strlst.at(0);
    }
    QString srcString = IPName_Paswd;
    QString encodedString = encryptData(srcString);
    QSettings setting("Finecho_SudoPaswd","Finecho_SudoPaswd_Details");
    setting.beginGroup(SUDOPASWD);
    foreach (const QString &key, setting.childKeys())
    {
        QString value = key;
        if(value == strIP)
        {
            int nflag = 0;
            QMessageBox qmsgMessageBox;
            nflag = qmsgMessageBox.warning(this,"Alert","Do you want Replace " + strIP + " sudo password ?...",QMessageBox::Yes, QMessageBox::No);
            if(nflag == QMessageBox::Yes)
            {
                setting.remove(key);
            }
            else
            {
                return;
            }
        }
    }
    setting.setValue(strIP,encodedString);
    QString message = QString("Sudo password set successfully");
    QMessageBox::information(this,"Success", message );
    setting.endGroup();
}    */

void CommissionSetting::Enablefunc()
{
    ui->m_PshBtn_UTC_Time->setEnabled(true);
    ui->m_PshBtn_LocaleTime->setEnabled(true);
    ui->m_PshBtn_PLCDataPortSave->setEnabled(true);
    ui->m_PshBtn_PLCDataPortArrival->setEnabled(true);
    ui->m_PshBtn_DataPort_Reset->setEnabled(true);
    ui->m_PshBtn_AlarmPort_Reset->setEnabled(true);
    ui->m_PshBtn_PLCAlarmPortArrival->setEnabled(true);
    ui->m_PshBtn_PLCAlarmPortSave->setEnabled(true);
    //ui->m_PshBtn_AWLFileUpload->setEnabled(true);
    ui->m_PshBtn_Alarm->setEnabled(true);
    ui->m_PshBtn_API_Set->setEnabled(true);
    ui->m_PshBtn_API_Check->setEnabled(true);
    ui->m_PshBtn_API_Reset->setEnabled(true);
    ui->lineEdit_AlarmPort->setEnabled(true);
    ui->radioBtn_Alarm640->setEnabled(true);
    ui->radioBtn_Alarm1280->setEnabled(true);
    ui->toolButton_AWLFile->setEnabled(true);
    ui->lineEdit_APIPort->setEnabled(true);
    ui->lineEdit_DataPort->setEnabled(true);
    ui->lineEdit_AlarmPort->setEnabled(true);

    ui->rBtn_active->setEnabled(true);
    ui->rBtn_deActive->setEnabled(true);
    ui->m_PshBtn_EnableHourlyLog->setEnabled(true);

    ui->kpi_port_lineEdit->setEnabled(true);
    ui->kpi_port_set_pushButton->setEnabled(true);
    ui->kpi_port_data_arrival_clicked->setEnabled(true);
    ui->kpi_port_reset_to_default->setEnabled(true);

    ui->kpi_report_port_lineEdit->setEnabled(true);
    ui->kpi_report_port_set_pushButton->setEnabled(true);
    ui->kpi_report_check_service_pushButton->setEnabled(true);
    ui->kpi_report_port_reset_to_default->setEnabled(true);

    ui->kpi_openFile_toolbutton->setEnabled(true);
   // ui->KPI_upload_pushButton->setEnabled(true);

    ui->percenatge_lineEdit->setEnabled(true);
    //ui->percentage_Set_Button->setEnabled(true);

    ui->awl_download_Button->setEnabled(true);
    ui->kpi_awl_download_Button->setEnabled(true);

    ui->label_AWLFile->setText("selected AWL");
    ui->KPI_db_file_label->setText("selected AWL");
}
void CommissionSetting::Disablefunc()
{
    ui->m_PshBtn_UTC_Time->setEnabled(false);
    ui->m_PshBtn_LocaleTime->setEnabled(false);
    ui->m_PshBtn_PLCDataPortSave->setEnabled(false);
    ui->m_PshBtn_PLCDataPortArrival->setEnabled(false);
    ui->m_PshBtn_AlarmPort_Reset->setEnabled(false);
    ui->m_PshBtn_DataPort_Reset->setEnabled(false);
    ui->m_PshBtn_PLCAlarmPortArrival->setEnabled(false);
    ui->m_PshBtn_PLCAlarmPortSave->setEnabled(false);
    ui->m_PshBtn_AWLFileUpload->setEnabled(false);
    ui->m_PshBtn_Alarm->setEnabled(false);
    ui->m_PshBtn_API_Set->setEnabled(false);
    ui->m_PshBtn_API_Check->setEnabled(false);
    ui->m_PshBtn_API_Reset->setEnabled(false);
    ui->toolButton_AWLFile->setEnabled(false);
    ui->lineEdit_APIPort->setEnabled(false);
    ui->lineEdit_DataPort->setEnabled(false);
    ui->lineEdit_AlarmPort->setEnabled(false);

    ui->radioBtn_Alarm640->setEnabled(false);
    ui->radioBtn_Alarm1280->setEnabled(false);

    ui->rBtn_active->setEnabled(false);
    ui->rBtn_deActive->setEnabled(false);

    ui->m_PshBtn_EnableHourlyLog->setEnabled(false);

    ui->kpi_port_lineEdit->setEnabled(false);
    ui->kpi_port_set_pushButton->setEnabled(false);
    ui->kpi_port_data_arrival_clicked->setEnabled(false);
    ui->kpi_port_reset_to_default->setEnabled(false);

    ui->kpi_report_port_lineEdit->setEnabled(false);
    ui->kpi_report_port_set_pushButton->setEnabled(false);
    ui->kpi_report_check_service_pushButton->setEnabled(false);
    ui->kpi_report_port_reset_to_default->setEnabled(false);

    ui->kpi_openFile_toolbutton->setEnabled(false);
    ui->KPI_upload_pushButton->setEnabled(false);

    ui->percenatge_lineEdit->setEnabled(false);
    ui->percentage_Set_Button->setEnabled(false);

    ui->awl_download_Button->setEnabled(false);
    ui->kpi_awl_download_Button->setEnabled(false);


   /* if(ui->radioBtn_Alarm640->isChecked())
        ui->radioBtn_Alarm640->setChecked(false);

    if(ui->radioBtn_Alarm1280->isChecked()){
        ui->radioBtn_Alarm1280->setChecked(false);
    }  */
}

void CommissionSetting::on_timeEdit_Time_timeChanged(const QTime &time)
{
    ui->TimeStamp_Date->setTime(time);
}

void CommissionSetting::on_m_PshBtn_Alarm_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QByteArray data;
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    if(ui->radioBtn_Alarm640->isChecked())
    {
        jsonKeys.insert("endpoint","Alarm_Confugration_640");
        jsonKeys.insert("alarm_count","640");
    }
    else
    {
        jsonKeys.insert("endpoint","Alarm_Confugration_1280");
        jsonKeys.insert("alarm_count","1280");
    }
    jsonKeys.insert("source",ui->comboBox_databases->currentText());

    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);

    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description_af_create,Description_af_update,Description_at_create;
    QString serviceStatus;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    if(result == "success"){
        fieldSet=fieldDefJSONArray.at(4);
        fieldObj=fieldSet.toObject();
        serviceStatus = fieldObj.value("service").toString();
    }

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description_af_create = fieldObj.value("Description_af_create").toString();

    fieldSet = fieldDefJSONArray.at(2);
    fieldObj = fieldSet.toObject();
    Description_af_update = fieldObj.value("Description_af_update").toString();

    fieldSet = fieldDefJSONArray.at(3);
    fieldObj = fieldSet.toObject();
    Description_at_create = fieldObj.value("Description_at_create").toString();

    socket->close();

    QString message = QString("Alarm_Confugration : " + result + "\n" + Description_af_create + "\n" + Description_af_update + "\n" +Description_at_create+"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_PLCDataPortArrival_clicked()
{
    QString date_string = ui->label_UTC_Time->text().trimmed();
    QDateTime UTCDateTime = QDateTime::fromString(date_string,"dd-MM-yyyy hh:mm:ss");
    QString str_UTCDateTime = UTCDateTime.toString("yyyy-MM-dd hh:mm:ss");

    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password;

    if(ui->lineEdit_DataPort->text() == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }

    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/

    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","PlcDataloginStatus");
    jsonKeys.insert("port",ui->lineEdit_DataPort->text());
    jsonKeys.insert("source",ui->comboBox_databases->currentText());
    jsonKeys.insert("UTCTime",str_UTCDateTime);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    //qDebug() << loadDoc;

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("Description").toString();

    socket->close();

    QString message = QString("PlcDataloginStatus: " + result + "\n" + Description);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_PLCAlarmPortArrival_clicked()
{
    QString date_string = ui->label_UTC_Time->text().trimmed();
    QDateTime UTCDateTime = QDateTime::fromString(date_string,"dd-MM-yyyy hh:mm:ss");
    QString str_UTCDateTime = UTCDateTime.toString("yyyy-MM-dd hh:mm:ss");
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password;

    if(ui->lineEdit_AlarmPort->text() == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }

    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","AlarmDataloginStatus");
    jsonKeys.insert("port",ui->lineEdit_AlarmPort->text());
    jsonKeys.insert("source",ui->comboBox_databases->currentText());
    jsonKeys.insert("UTCTime",str_UTCDateTime);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;

    //qDebug() << jsonDoc;

    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);


    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("Description").toString();

    socket->close();

    QString message = QString("AlarmDataloginStatus: " + result + "\n" + Description);
    QMessageBox::information(this,"Result", message );
}
void CommissionSetting::showDefaultPorts()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","showDefaultPorts");
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);

    sourceCurrentIndex=0;

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);
        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            if(socket->state() != QAbstractSocket::ConnectedState)
                break;
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    //qDebug() << loadDoc;
    socket->close();

    QJsonArray fieldPortArray,fieldSourceArray,field_KPI_Report_array,KPI_data_port_array;

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result , Alarm_Port, Service_Port,KPI_Report_Port,KPI_data_port;


    fieldSet = fieldDefJSONArray.at(3);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("status").toString();
    //qDebug() << result;

    fieldSet = fieldDefJSONArray.at(4);
    fieldObj = fieldSet.toObject();
    fieldSourceArray = fieldObj.value("Data_Sources").toArray();

    sourcesCount=fieldSourceArray.size();
    // qDebug() << "count:"<<sourcesCount;

    if(sourcesCount==0){
        QString message = QString("No data sources found..");
        //QMessageBox::information(this,"Result", message );
        QMessageBox customMessageBox;
                if(!sourceStatus) {
                    QTimer::singleShot(3000,&customMessageBox, &QMessageBox::close);
                    sourceStatus=true;
                }
                customMessageBox.setWindowTitle("Result");
                customMessageBox.setIcon(QMessageBox::Information);
                customMessageBox.setText(message);
                customMessageBox.exec();

        Disablefunc();

    }else if(sourcesCount>1){

        ui->lineEdit_AlarmPort->setEnabled(false);
        ui->m_PshBtn_PLCAlarmPortSave->setEnabled(false);
        ui->m_PshBtn_PLCAlarmPortArrival->setEnabled(false);
        ui->m_PshBtn_AlarmPort_Reset->setEnabled(false);

        ui->radioBtn_Alarm640->setEnabled(false);
        ui->radioBtn_Alarm1280->setEnabled(false);
        ui->m_PshBtn_Alarm->setEnabled(false);

        ui->kpi_openFile_toolbutton->setEnabled(false);
        ui->KPI_upload_pushButton->setEnabled(false);
        ui->kpi_awl_download_Button->setEnabled(false);

        ui->m_PshBtn_DataPort_Reset->setEnabled(false);
    }

    ui->comboBox_databases->clear();
    Data_Sources.clear();

    for (int i=0;i<fieldSourceArray.size();i++) {
        Data_Sources.append(fieldSourceArray.at(i).toString());
        ui->comboBox_databases->addItem(fieldSourceArray.at(i).toString());
    }
    if(ui->comboBox_databases->currentText()!=""){
        QString source = ui->comboBox_databases->currentText();
        ui->comboBox_databases->setMinimumWidth(source.length()*15);
    }
    //qDebug() << Data_Sources;

    Data_Port.clear();
    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    fieldPortArray = fieldObj.value("Data_Port").toArray();

    // qDebug() <<"size="<<fieldPortArray.size();

    for(int j=0;j<fieldPortArray.size();j++){
        Data_Port.append(fieldPortArray.at(j).toString());
    }
    //qDebug() << "DataPort:"<<Data_Port;

    if(Data_Port.size()>0  && ui->comboBox_databases->currentIndex()!= -1) {
        ui->lineEdit_DataPort->setText(Data_Port.at(sourceCurrentIndex));
        oldPortData=Data_Port.at(sourceCurrentIndex);
    }

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Alarm_Port = fieldObj.value("Alarm_Port").toString();
    // qDebug() << "alramPort"<<Alarm_Port;

    if(Alarm_Port == "Alarm service is not running for multiple plc's" || Alarm_Port=="Default listener is not selected Alarm service"){

        //QString message = QString("Alarm service is not running for multiple plc's..");

        ui->label_Alarm_message->setText(Alarm_Port);

        ui->lineEdit_AlarmPort->setEnabled(false);
        ui->m_PshBtn_PLCAlarmPortSave->setEnabled(false);
        ui->m_PshBtn_PLCAlarmPortArrival->setEnabled(false);
        ui->m_PshBtn_AlarmPort_Reset->setEnabled(false);

        ui->radioBtn_Alarm640->setEnabled(false);
        ui->radioBtn_Alarm1280->setEnabled(false);
        ui->m_PshBtn_Alarm->setEnabled(false);
    }else{
        ui->lineEdit_AlarmPort->setText(Alarm_Port);
        ui->label_Alarm_message->setText("");
        oldPortAlarm=ui->lineEdit_AlarmPort->text();
    }

    fieldSet = fieldDefJSONArray.at(2);
    fieldObj = fieldSet.toObject();
    Service_Port = fieldObj.value("Service_Port").toString();
    ui->lineEdit_APIPort->setText(Service_Port);
    // qDebug() << "servicePort:"<<Service_Port;

    oldPortDataloggerAPI=ui->lineEdit_APIPort->text();
   // ui->label_AWLFile->setText("kcLog_CART.db");


    fieldSet = fieldDefJSONArray.at(5);
    fieldObj = fieldSet.toObject();
    field_KPI_Report_array = fieldObj.value("KPIlogger_Port").toArray();
    for (int k=0;k<field_KPI_Report_array.size();k++) {
        KPI_Report_Port=field_KPI_Report_array.at(k).toString();
    }
    if(KPI_Report_Port=="KPI data logger service is not running for multiple plc's" || KPI_Report_Port=="Default listener is not selected KPI data logger service"){
        ui->kpi_report_port_label_message->setText(KPI_Report_Port);
        ui->kpi_report_port_lineEdit->setEnabled(false);
        ui->kpi_report_port_set_pushButton->setEnabled(false);
        ui->kpi_report_check_service_pushButton->setEnabled(false);
        ui->kpi_report_port_reset_to_default->setEnabled(false);
        ui->KPI_upload_pushButton->setEnabled(false);
        ui->kpi_awl_download_Button->setEnabled(false);
        ui->kpi_openFile_toolbutton->setEnabled(false);
        ui->KPI_db_file_label->clear();
    }else{
        ui->kpi_report_port_lineEdit->setText(KPI_Report_Port);
        oldKPI_Report_port=ui->kpi_report_port_lineEdit->text();
        ui->kpi_report_port_label_message->setText("");
    }

    fieldSet = fieldDefJSONArray.at(6);
    fieldObj = fieldSet.toObject();
    KPI_data_port_array = fieldObj.value("KPIdata_Port").toArray();
    for(int h=0;h<KPI_data_port_array.size();h++){
        KPI_data_port= KPI_data_port_array.at(h).toString();
    }

    if(KPI_data_port=="KPI data collection service is not running for multiple plc's" || KPI_data_port=="Default listener is not selected KPI data collection service"){
        ui->kpi_port_label_message->setText(KPI_data_port);
        ui->kpi_port_lineEdit->setEnabled(false);
        ui->kpi_port_data_arrival_clicked->setEnabled(false);
        ui->kpi_port_set_pushButton->setEnabled(false);
        ui->kpi_port_reset_to_default->setEnabled(false);
    }else{
        ui->kpi_port_lineEdit->setText(KPI_data_port);
        oldKPIPort=ui->kpi_port_lineEdit->text();
        ui->kpi_port_label_message->setText("");
    }
    fieldSet=fieldDefJSONArray.at(7);
    fieldObj=fieldSet.toObject();
    QString percent=fieldObj.value("Disc_Space_Pcent").toString();
    ui->percenatge_lineEdit->setText(percent);
    oldPercent=percent;

   // qDebug() << KPI_data_port;

    if(Data_Port.size() != Data_Sources.size()){
        QString message = QString("Sources count not matched with data ports count..");
        QMessageBox::information(this,"Result", message );
    }
}

/*void CommissionSetting::showFirstTimePassword() // not calling
{
    ui->lEdt_Passwd->clear();
    QString strIP;
    QString add;
    strIP = ui->comboBox_ConnectedIPs->currentText();
    QStringList strlst = strIP.split(':');
    int dSize = strlst.length();
    if(dSize > 0)
    {
        add = strlst.at(0);
    }
    ui->label_password->setText(add +" SU Credentials");
    QSettings setting("Finecho_SudoPaswd","Finecho_SudoPaswd_Details");
    setting.beginGroup(SUDOPASWD);
    ui->lEdt_Passwd->setText(setting.value(add).toString());
    setting.endGroup();
}    */

void CommissionSetting::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this,"Commissioning Tool",
                                                                tr("Do you want to Exit?\n"),
                                                                QMessageBox::Yes | QMessageBox::No);
    if (resBtn != QMessageBox::Yes) {
        event->ignore();
    } else {
        // event->accept();
        QApplication::quit();
    }
}

void CommissionSetting::on_m_PshBtn_DataPort_Reset_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password ;

    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/

    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","RestoreAndDefault_DATAPORT");
    jsonKeys.insert("oldport",ui->lineEdit_DataPort->text());
    // jsonKeys.insert("password",password);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    // qDebug() << jsonDoc;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
               }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }
    //qDebug() << loadDoc;
    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;
    QString serviceStatus;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("reason").toString();

    socket->close();

    if(result == "success"){
        ui->lineEdit_DataPort->setText("40001");
        Data_Port[sourceCurrentIndex]="40001";
        fieldSet=fieldDefJSONArray.at(2);
        fieldObj=fieldSet.toObject();
        serviceStatus = fieldObj.value("service").toString();
    }else if(Description == "Provided port is busy,Please provide different port no."){
        ui->lineEdit_DataPort->setText("40001");
    }

    QString message = QString("Reset port: " + result + "\n" + Description+"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_m_PshBtn_AlarmPort_Reset_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password;
    /*= decryptData(Str_IPAddress);
    QString res,Desc,msg;
    Desc = "Operation Failed";
    if(password == "")
    {
        msg = QString("Please set the sudo password" + res + "\n" + Desc);
        QMessageBox::information(this,"Erorr", msg );
        ui->lEdt_Passwd->clear();
        return;
    }*/
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","RestoreAndDefault_ALARMPORT");
    // jsonKeys.insert("password",password);
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        return;
    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;
    QString serviceStatus;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("reason").toString();

    socket->close();

    if(result == "success"){
        ui->lineEdit_AlarmPort->setText("40002");
        oldPortAlarm="40002";
        fieldSet=fieldDefJSONArray.at(2);
        fieldObj=fieldSet.toObject();
        serviceStatus=fieldObj.value("service").toString();
    }else if(Description == "Provided port is busy,Please provide different port no."){
        ui->lineEdit_AlarmPort->setText("40002");
    }


    QString message = QString("Reset port: " + result + "\n" + Description+"\n"+serviceStatus);
    QMessageBox::information(this,"Result", message );
}
QString CommissionSetting::add_padding(QString strLen)
{
    int num = strLen.size();
    if(num == 1){
        strLen.prepend("000000000");
    }else if(num == 2){
        strLen.prepend("00000000");
    }else if(num == 3){
        strLen.prepend("0000000");
    }else if(num == 4){
        strLen.prepend("000000");
    }else if(num == 5){
        strLen.prepend("00000");
    }else if(num == 6){
        strLen.prepend("0000");
    }else if(num == 7){
        strLen.prepend("000");
    }else if(num == 8){
        strLen.prepend("00");
    }else if(num == 9){
        strLen.prepend("0");
    }
    return strLen;
}

void CommissionSetting::Default_Alarm_Port()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password;
    jsonKeys.insert("username","rushikesh");
    jsonKeys.insert("passcode","finecho@178");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","Default_Alarm_Confugration");
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);
    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));
    // qDebug() << jByte << newNum << strLen;
    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        int iBytes=0;
        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            iBytes = socket->bytesAvailable();
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
        Q_UNUSED(iBytes);

    }
    QJsonValue fieldSet;
    QJsonObject fieldObj;
    QJsonParseError json_error;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
    if (json_error.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_error.errorString();
    }

    QJsonObject rootObj = loadDoc.object();
    QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
    QString result;
    QString Description;

    fieldSet = fieldDefJSONArray.at(0);
    fieldObj = fieldSet.toObject();
    result = fieldObj.value("result").toString();

    fieldSet = fieldDefJSONArray.at(1);
    fieldObj = fieldSet.toObject();
    Description = fieldObj.value("Description").toString();

    socket->close();

    //qDebug() << Description;

    if(Description == "Alarm_Confugration_1280")
    {
        ui->radioBtn_Alarm1280->setChecked(true);
    }
    else if(Description == "Alarm_Confugration_640")
    {
        ui->radioBtn_Alarm640->setChecked(true);
    }
    else
    {
        ui->radioBtn_Alarm1280->setChecked(false);
        ui->radioBtn_Alarm640->setChecked(false);
        // ui->radioBtn_Alarm640->setDisabled(true);
        // ui->radioBtn_Alarm1280->setDisabled(true);
    }

    /*  if(Description == "Alarm_Confugration_1280" || Description == "Alarm_Confugration_640")
    {
        ui->m_PshBtn_AlarmPort_Reset->setEnabled(true);
        ui->m_PshBtn_PLCAlarmPortSave->setEnabled(true);
        ui->m_PshBtn_Alarm->setEnabled(true);
    }
    else
    {
        ui->m_PshBtn_AlarmPort_Reset->setEnabled(false);
        ui->m_PshBtn_PLCAlarmPortSave->setEnabled(false);
        ui->m_PshBtn_Alarm->setEnabled(false);
    }                                                     */
}

void CommissionSetting::on_toolButton_Version_clicked()
{
    m_appVersions = new AppVersions(Str_IPAddress,Str_port);
       m_appVersions->show();
       m_appVersions->activateWindow();

       //===============disable the main window==============
       this->setEnabled(false);

       m_appVersions->setAttribute(Qt::WA_DeleteOnClose,true);

       connect(m_appVersions , &QWidget::destroyed, this,[=]()->void{
               this->setEnabled(true);});
}

void CommissionSetting::Default_CPU_and_Memory_Logging_status()
{
            QJsonObject jsonKeys;
            QJsonDocument jsonDoc;
            QJsonArray jsonArray;
            QString password;
            jsonKeys.insert("username","rajendra");
            jsonKeys.insert("passcode","finecho@007");
            jsonKeys.insert("authkey","abcd");
            jsonKeys.insert("endpoint","Default_CPU_and_Memory_Logging_status");
            jsonArray.append(jsonKeys);
            jsonDoc = QJsonDocument(jsonArray);

            QByteArray data;
            QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
            int newNum = jByte.size();
            QString strLen = add_padding(QString::number(newNum));

            socket->connectToHost(Str_IPAddress,Str_port.toInt());

            if(socket->waitForConnected(10000))
            {
                socket->write(strLen.toUtf8());
                socket->waitForBytesWritten(30000);

                socket->write(jByte);
                socket->waitForBytesWritten(30000);

                for(int m=0; m<100; m++)
                {
                    socket->waitForReadyRead(1000);
                    QApplication::setOverrideCursor(Qt::WaitCursor);
                    if(socket->state() != QAbstractSocket::ConnectedState){
                        QApplication::setOverrideCursor(Qt::ArrowCursor);
                        break;
                    }
                    data += socket->readAll();
                    usleep(50000);
                }
            }
           // qDebug() << data;

            QJsonValue fieldSet;
            QJsonObject fieldObj;
            QJsonParseError json_error;
            QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
            if (json_error.error != QJsonParseError::NoError)
            {
                qDebug() << "JSON parse error: "<< json_error.errorString();
            }
           // qDebug() << loadDoc;
            QJsonObject rootObj = loadDoc.object();
            QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
            QString result;
            QString description;

            fieldSet = fieldDefJSONArray.at(0);
            fieldObj = fieldSet.toObject();
            result = fieldObj.value("result").toString();

            fieldSet = fieldDefJSONArray.at(1);
            fieldObj = fieldSet.toObject();
            description = fieldObj.value("status").toString();
            socket->close();

            if(result == "success"){
                if(description=="Active"){
                      ui->rBtn_active->setChecked(true);
                }else if(description=="InActive"){
                      ui->rBtn_deActive->setChecked(true);
                }else if(description=="file not found"){
                    ui->rBtn_active->setEnabled(false);
                    ui->rBtn_deActive->setEnabled(false);
                    ui->m_PshBtn_EnableHourlyLog->setEnabled(false);
                    ui->CPU_Memory_logging_label->setText("CPU & Memory logging file is not configured");
                }
            }else if(result=="failed"){
                ui->rBtn_active->setEnabled(false);
                ui->rBtn_deActive->setEnabled(false);
                ui->m_PshBtn_EnableHourlyLog->setEnabled(false);
                ui->CPU_Memory_logging_label->setText("CPU & Memory logging file is not configured");
            }
}

void CommissionSetting::on_m_PshBtn_EnableHourlyLog_clicked()
{
        QJsonObject jsonKeys;
        QJsonDocument jsonDoc;
        QJsonArray jsonArray;
        QString password;
        jsonKeys.insert("username","rajendra");
        jsonKeys.insert("passcode","finecho@007");
        jsonKeys.insert("authkey","abcd");

        if(ui->rBtn_active->isChecked()){
            jsonKeys.insert("currentStatus","Active");
        }else if(ui->rBtn_deActive->isChecked()){
            jsonKeys.insert("currentStatus","Deactive");
        }

        jsonKeys.insert("endpoint","Set_CPU_and_Memory_Logging");
        jsonArray.append(jsonKeys);
        jsonDoc = QJsonDocument(jsonArray);
        QByteArray data;
        //qDebug() << "Data:"<<jsonDoc;

        QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
        int newNum = jByte.size();
        QString strLen = add_padding(QString::number(newNum));

        socket->connectToHost(Str_IPAddress,Str_port.toInt());
        if(socket->waitForConnected(10000))
        {
            socket->write(strLen.toUtf8());
            socket->waitForBytesWritten(30000);

            socket->write(jByte);
            socket->waitForBytesWritten(30000);

            for(int m=0; m<100; m++)
            {
                socket->waitForReadyRead(1000);
                QApplication::setOverrideCursor(Qt::WaitCursor);
                if(socket->state() != QAbstractSocket::ConnectedState){
                    QApplication::setOverrideCursor(Qt::ArrowCursor);
                    break;
                }
                data += socket->readAll();
                usleep(50000);
            }
        }

        QJsonValue fieldSet;
        QJsonObject fieldObj;
        QJsonParseError json_error;
        QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
        if (json_error.error != QJsonParseError::NoError)
        {
            qDebug() << "JSON parse error: "<< json_error.errorString();
        }

        QJsonObject rootObj = loadDoc.object();
        QJsonArray fieldDefJSONArray = rootObj.value("field").toArray();
        QString result;
        QString status;

        fieldSet = fieldDefJSONArray.at(0);
        fieldObj = fieldSet.toObject();
        result = fieldObj.value("result").toString();

        fieldSet = fieldDefJSONArray.at(1);
        fieldObj = fieldSet.toObject();
        status = fieldObj.value("status").toString();
        socket->close();

        QString message = QString("CPU & Memory logging: " + result + "\n" + status);
        QMessageBox::information(this,"Result", message );
}



void CommissionSetting::on_kpi_openFile_toolbutton_clicked()
{
    QStringList splitter;
    kpi_db_file  = QFileDialog::getOpenFileName(this,tr("Load From File"),"",tr("All files (*.db *.DB *.awl *.AWL);;"));
    splitter =  kpi_db_file.split("/");
    int nShpCnt = splitter.count() - 1;
    QString Path = splitter.at(nShpCnt);

    if(Path!="")
        ui->KPI_db_file_label->setText(Path);
    else
        ui->KPI_db_file_label->setText("selected AWL");

    QFileInfo fileInfo(kpi_db_file);
   // QString name = fileInfo.fileName();
    QStringList filePath = kpi_db_file.split(fileInfo.fileName());
    QDir dir(filePath.at(0));

    if(dir.exists() && kpi_db_file!=""){
        ui->KPI_upload_pushButton->setEnabled(true);
    }else{
        ui->KPI_upload_pushButton->setEnabled(false);
    }
}

void CommissionSetting::on_KPI_upload_pushButton_clicked()
{
    QFile file(kpi_db_file);
    QStringList strLstlines;

    QByteArray line;
    if(!file.open(QIODevice::ReadOnly)){
        QString message = file.errorString();
        QMessageBox::information(this,"Result", message );
        return;
    }

    while (!file.atEnd()) {
        // line=line+file.readLine().simplified();
        line = file.readLine();
        strLstlines << QString(line).simplified();
    }
    //qDebug() << strLstlines;
    file.close();

    QJsonObject jsonKeys;
    QJsonArray jsonArray;
    QJsonDocument jsonDoc;

    jsonKeys.insert("username","harsha");
    jsonKeys.insert("password","finecho@007");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","kpiAWLUpload");
    jsonKeys.insert("port",ui->kpi_port_lineEdit->text());
    jsonKeys.insert("source",ui->comboBox_databases->currentText());
    QJsonArray jsonLineArray;
    int validationCount=0;
    for(int i=0;i<strLstlines.size();i++){
        //qDebug() << (strLstlines.at(i)).split(":").at(0).simplified();
        if((strLstlines.at(i)).split(":").at(0).simplified().toLower()=="container_move"||(strLstlines.at(i)).split(":").at(0).simplified().toLower()=="move" || (strLstlines.at(i)).split(":").at(0).simplified().toLower()=="a1_load" || (strLstlines.at(i)).split(":").at(0).simplified().toLower()=="a2_load" )
            validationCount++;
        jsonLineArray.append(strLstlines.at(i).trimmed());
    }

    if(validationCount==3){
        //qDebug() << "valid";
    }else{
        //qDebug() << "Invalid";
        QMessageBox::information(this,"Result","uploaded AWL file not valid for KPI calculation");
        return;
    }

    jsonKeys.insert("line",QJsonValue(jsonLineArray));

    jsonArray.append(jsonKeys);
    jsonDoc=QJsonDocument(jsonArray);

   // qDebug() << jsonDoc;

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum=jByte.size();
    QString strLen=add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000)){
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int k=0;k<100;k++){
            socket->waitForReadyRead(1000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state()!=QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data+=socket->readAll();
            usleep(50000);
        }
    }else{
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonParseError jsonParseError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data,&jsonParseError));
    if(jsonParseError.error!=QJsonParseError::NoError){
        qDebug() << "Json Parse Error:"<<jsonParseError.errorString();
    }
    //qDebug() << loadDoc;

    QJsonObject rootObject=loadDoc.object();
    QJsonArray jsonValueArray=rootObject.value("field").toArray();
    QJsonValue fieldVal;
    QJsonObject fieldObject;
    QString result,description_of_create,description_of_update,description_of_update1,service;
    QString description_at_create,description_at_create1,description_at_create2,description_at_create3,description_at_create4;

    fieldVal=jsonValueArray.at(0);
    fieldObject=fieldVal.toObject();
    result=fieldObject.value("result").toString();

    if(result=="success"){
        fieldVal=jsonValueArray.at(8);
        fieldObject=fieldVal.toObject();
        service=fieldObject.value("service").toString();
    }

    fieldVal=jsonValueArray.at(1);
    fieldObject=fieldVal.toObject();
    description_of_create=fieldObject.value("Description_at_create").toString();

    fieldVal=jsonValueArray.at(2);
    fieldObject=fieldVal.toObject();
    description_of_update=fieldObject.value("Description_at_update").toString();

    fieldVal=jsonValueArray.at(3);
    fieldObject=fieldVal.toObject();
    description_at_create1=fieldObject.value("Description_at_create1").toString();

    fieldVal=jsonValueArray.at(4);
    fieldObject=fieldVal.toObject();
    description_of_update1=fieldObject.value("Description_at_update1").toString();

    fieldVal=jsonValueArray.at(5);
    fieldObject=fieldVal.toObject();
    description_at_create2=fieldObject.value("Description_at_create2").toString();

    fieldVal=jsonValueArray.at(6);
    fieldObject=fieldVal.toObject();
    description_at_create3=fieldObject.value("Description_at_create3").toString();

    fieldVal=jsonValueArray.at(7);
    fieldObject=fieldVal.toObject();
    description_at_create4=fieldObject.value("Description_at_create4").toString();

    socket->close();

    QString message = QString("AWL Configuration:"+result+"\n"+description_of_create+"\n"+description_of_update+"\n"+description_at_create1+"\n"+
                              description_of_update1+"\n"+description_at_create2+"\n"+description_at_create3+"\n"+description_at_create4+"\n"+service);
    QMessageBox::information(this,"Result",message);

}

void CommissionSetting::on_kpi_port_set_pushButton_clicked()
{
    QString kpiDataPort = ui->kpi_port_lineEdit->text();

    if(kpiDataPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }
    //qDebug() << kpiDataPort;
    if(kpiDataPort.toInt() < 4096 || kpiDataPort.toInt() > 65535){
        QMessageBox msgBox;
        msgBox.setText("Enter the valid KPI Port Number \n"
                       "Port Range should be between 4096 and 65535");
        msgBox.exec();
        ui->kpi_port_lineEdit->setText(oldKPIPort);
        return;
    }

    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;

   jsonKeys.insert("username","rajendra");
   jsonKeys.insert("password","finecho@007");
   jsonKeys.insert("authkey","abcd");
   jsonKeys.insert("endpoint","Port_Change_For_Kpidata");
   jsonKeys.insert("oldPort",oldKPIPort);
   jsonKeys.insert("Port",kpiDataPort);

   jsonArray.append(jsonKeys);

   jsonDoc=QJsonDocument(jsonArray);
   //qDebug() <<"Port_Change_For_Kpidata:"<< jsonDoc;

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
    }else {
        QMessageBox msgBox;
        // qDebug() << socket->state();
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonParseError jsonParseError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data,&jsonParseError));
    if(jsonParseError.error!=QJsonParseError::NoError){
        qDebug() << "Json Parse error.."<<jsonParseError.errorString();
    }
    //qDebug() << loadDoc;
    QJsonObject rootObject=loadDoc.object();
    QJsonArray jsonValueArray=rootObject.value("field").toArray();

    QJsonValue fieldVal;
    QJsonObject fieldObject;

    QString result,description,service;

    fieldVal=jsonValueArray.at(0);
    fieldObject=fieldVal.toObject();
    result=fieldObject.value("result").toString();

    if(result=="failed" || result == "fail"){
        ui->kpi_port_lineEdit->setText(oldKPIPort);
    }else{
        oldKPIPort=kpiDataPort;
        fieldVal=jsonValueArray.at(2);
        fieldObject=fieldVal.toObject();
        service=fieldObject.value("service").toString();
    }

    fieldVal=jsonValueArray.at(1);
    fieldObject=fieldVal.toObject();
    description=fieldObject.value("reason").toString();

    socket->close();

    QString message = QString("KPI_Data_port Set:"+result+"\n"+description+"\n"+service);
    QMessageBox::information(this,"Result",message);
}
void CommissionSetting::on_kpi_port_data_arrival_clicked_clicked()
{
    QString utcDataTimeString = ui->label_UTC_Time->text().trimmed();
    QDateTime utcDateTime=QDateTime::fromString(utcDataTimeString,"dd-MM-yyyy hh:mm:ss");
    QString str_UTCDateTime = utcDateTime.toString("yyyy-MM-dd hh:mm:ss");

    QJsonObject jsonKeys;
    QJsonArray jsonArray;
    QJsonDocument jsonDoc;

    if(ui->kpi_port_lineEdit->text() == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }

    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("username","rajendra");
    jsonKeys.insert("password","finecho@007");
    jsonKeys.insert("endpoint","KpiDataLoggingStatus");
    jsonKeys.insert("port",ui->kpi_port_lineEdit->text());
    jsonKeys.insert("source",ui->comboBox_databases->currentText());
    jsonKeys.insert("UTCTime",str_UTCDateTime);

    jsonArray.append(jsonKeys);
    jsonDoc=QJsonDocument(jsonArray);

    //qDebug() <<"KpiDataLoggingStatus:"<< jsonDoc;

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));


    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000)){

        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);
        for(int m=0;m<100;m++){
            socket->waitForReadyRead(1000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state()!=QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data+=socket->readAll();
            usleep(50000);
        }

    }else{

        QMessageBox msgBox;
        // qDebug() << socket->state();
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonParseError jsonParseError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data,&jsonParseError));

    if(jsonParseError.error!=QJsonParseError::NoError){
        qDebug()<<"Json Parse Error:"<<jsonParseError.errorString();
    }

    //qDebug() << loadDoc;
    QJsonObject rootObject=loadDoc.object();
    QJsonArray jsonValueArray=rootObject.value("field").toArray();

    QJsonObject fieldObject;
    QJsonValue fieldVal;
    QString result,description;

    fieldVal=jsonValueArray.at(0);
    fieldObject=fieldVal.toObject();
    result=fieldObject.value("result").toString();

    fieldVal=jsonValueArray.at(1);
    fieldObject=fieldVal.toObject();
    description=fieldObject.value("Description").toString();

    socket->close();

    QString message=QString("KpiDataLoggingStatus:"+result+"\n"+description);
    QMessageBox::information(this,"Result",message);


}

void CommissionSetting::on_kpi_port_reset_to_default_clicked()
{
    QString kpiDataPort=ui->kpi_port_lineEdit->text();

    if(kpiDataPort==""){
        QMessageBox::information(this,"Result","Please enter the port number");
        return;
    }

    QJsonArray jsonArray;
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;

    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("password","finecho@007");
    jsonKeys.insert("endpoint","RestoreAndDefault_Kpidata");
    jsonKeys.insert("oldPort",kpiDataPort);

    jsonArray.append(jsonKeys);
    jsonDoc=QJsonDocument(jsonArray);

   // qDebug() <<"RestoreAndDefault_Kpidata:"<<jsonDoc;

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
    }else {
        QMessageBox msgBox;
        // qDebug() << socket->state();
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonParseError jsonParseError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data,&jsonParseError));

    if(jsonParseError.error!=QJsonParseError::NoError){
        qDebug() << "Josn Parse Error:"<<jsonParseError.errorString();
    }
    //qDebug() << loadDoc;
    QJsonObject rootObject=loadDoc.object();
    QJsonArray jsonFieldValueArray=rootObject.value("field").toArray();

    QJsonValue fieldVal;
    QJsonObject fieldObject;

    QString result,description,service;

    fieldVal=jsonFieldValueArray.at(0);
    fieldObject=fieldVal.toObject();
    result=fieldObject.value("result").toString();

    fieldVal=jsonFieldValueArray.at(1);
    fieldObject=fieldVal.toObject();
    description=fieldObject.value("reason").toString();

    socket->close();

    if(result=="success"){
        ui->kpi_port_lineEdit->setText("40003");
        oldKPIPort="40003";

        fieldVal=jsonFieldValueArray.at(2);
        fieldObject=fieldVal.toObject();
        service=fieldObject.value("service").toString();

    }else if(description=="Provided port is busy,Please provide different port no."){
        ui->lineEdit_AlarmPort->setText("40003");
    }

    QString message = QString("KPI Port Reset:"+result+"\n"+description+"\n"+service);
    QMessageBox::information(this,"Result",message);

}


void CommissionSetting::on_kpi_report_port_set_pushButton_clicked()
{
    QString kpiReportPort = ui->kpi_report_port_lineEdit->text();

    if(kpiReportPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }
    if(kpiReportPort.toInt() < 4096 || kpiReportPort.toInt() > 65535){
        QMessageBox msgBox;
        msgBox.setText("Enter the valid KPI Report Port Number \n"
                       "Port Range should be between 4096 and 65535");
        msgBox.exec();
        ui->kpi_report_port_lineEdit->setText(oldKPI_Report_port);
        return;
    }

    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;

   jsonKeys.insert("username","rajendra");
   jsonKeys.insert("password","finecho@007");
   jsonKeys.insert("authkey","abcd");
   jsonKeys.insert("endpoint","Port_Change_For_Kpiloggerapi");
   jsonKeys.insert("oldPort",oldKPI_Report_port);
   jsonKeys.insert("Port",kpiReportPort);
   jsonArray.append(jsonKeys);
   jsonDoc = QJsonDocument(jsonArray);

   //qDebug() <<"Port_Change_For_Kpiloggerapi:"<< jsonDoc;
   QByteArray data;
   QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
   int newNum = jByte.size();
   QString strLen = add_padding(QString::number(newNum));

   socket->connectToHost(Str_IPAddress,Str_port.toInt());
   if(socket->waitForConnected(10000))
   {
       socket->write(strLen.toUtf8());
       socket->waitForBytesWritten(30000);

       socket->write(jByte);
       socket->waitForBytesWritten(30000);

       for(int m=0; m<100; m++)
       {
           socket->waitForReadyRead(1000);
           QApplication::setOverrideCursor(Qt::WaitCursor);
           if(socket->state() != QAbstractSocket::ConnectedState){
               QApplication::setOverrideCursor(Qt::ArrowCursor);
               break;
           }
           data += socket->readAll();
           usleep(50000);
       }
   }else {
       QMessageBox msgBox;
       // qDebug() << socket->state();
       msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
       msgBox.exec();
       ui->lbl_Connection->setStyleSheet("background-color:red;");
       ui->pushButton_connect->setText("Connect");
       ui->lbl_error_msg->setText("Connection lost");
       m_pingThread->exit();
       timer->stop();
       Disablefunc();
       ui->comboBox_databases->clear();
       clearWidgets();
       socket->close();
       return;
   }

   QJsonParseError json_error;
   QJsonDocument loadDoc(QJsonDocument::fromJson(data, &json_error));
   if (json_error.error != QJsonParseError::NoError)
   {
       qDebug() << "JSON parse error: "<< json_error.errorString();
   }

    //qDebug() << loadDoc;
    QJsonValue fieldVal;
    QJsonObject fieldObj;

    QJsonObject rootObject = loadDoc.object();
    QJsonArray fieldJsonArray = rootObject.value("field").toArray();

    QString result;
    QString reason;
    QString service;

    fieldVal = fieldJsonArray.at(0);
    fieldObj = fieldVal.toObject();
    result = fieldObj.value("result").toString();
    if(result == "fail"  || result == "failed"){
        ui->kpi_report_port_lineEdit->setText(oldKPI_Report_port);
    }else{
        oldKPI_Report_port = kpiReportPort;
        fieldVal = fieldJsonArray.at(2);
        fieldObj = fieldVal.toObject();
        service = fieldObj.value("service").toString();
    }

    fieldVal = fieldJsonArray.at(1);
    fieldObj = fieldVal.toObject();
    reason = fieldObj.value("reason").toString();

    socket->close();

    QString message = QString("Change KPILoggerApi Port: " + result + "\n" + reason+"\n"+service);
    QMessageBox::information(this,"Result", message );

}

void CommissionSetting::on_kpi_report_check_service_pushButton_clicked()
{
    QString kpiReportPort = ui->kpi_report_port_lineEdit->text();
    if(kpiReportPort == "")
    {
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;

   jsonKeys.insert("username","rajendra");
   jsonKeys.insert("password","finecho@007");
   jsonKeys.insert("authkey","abcd");
   jsonKeys.insert("endpoint","checkKPIloggerAPIservice");
   jsonKeys.insert("port",kpiReportPort);
   jsonArray.append(jsonKeys);
   jsonDoc = QJsonDocument(jsonArray);

  // qDebug() <<"checkKPIloggerAPIservice:"<< jsonDoc;

   QByteArray data;
   QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
   int newNum = jByte.size();
   QString strLen = add_padding(QString::number(newNum));

   socket->connectToHost(Str_IPAddress,Str_port.toInt());
   if(socket->waitForConnected(10000))
   {
       socket->write(strLen.toUtf8());
       socket->waitForBytesWritten(30000);

       socket->write(jByte);
       socket->waitForBytesWritten(30000);

       for(int m=0; m<100; m++)
       {
           socket->waitForReadyRead(1000);
           QApplication::setOverrideCursor(Qt::WaitCursor);
           if(socket->state() != QAbstractSocket::ConnectedState){
               QApplication::setOverrideCursor(Qt::ArrowCursor);
               break;
           }
           data += socket->readAll();
           usleep(50000);
       }
   }else {
       QMessageBox msgBox;
       // qDebug() << socket->state();
       msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
       msgBox.exec();
       ui->lbl_Connection->setStyleSheet("background-color:red;");
       ui->pushButton_connect->setText("Connect");
       ui->lbl_error_msg->setText("Connection lost");
       m_pingThread->exit();
       timer->stop();
       Disablefunc();
       ui->comboBox_databases->clear();
       clearWidgets();
       socket->close();
       return;
   }

   QJsonParseError json_parseError;
   QJsonDocument loadDoc(QJsonDocument::fromJson(data,&json_parseError));

   if (json_parseError.error != QJsonParseError::NoError)
   {
       qDebug() << "JSON parse error: "<< json_parseError.errorString();
   }
    //qDebug() << loadDoc;
   QJsonObject rootObject=loadDoc.object();
   QJsonArray fieldValueArray=rootObject.value("field").toArray();

   QJsonValue fieldVal;
   QJsonObject fieldObject;
   QString status;
   QString Description;

   fieldVal = fieldValueArray.at(0);
   fieldObject = fieldVal.toObject();
   status = fieldObject.value("status").toString();

   fieldVal = fieldValueArray.at(1);
   fieldObject = fieldVal.toObject();
   Description = fieldObject.value("Description").toString();

   socket->close();

   QString message = QString("KPIReportApi Service: " + status + "\n" + Description);
   QMessageBox::information(this,"Result", message );


}

void CommissionSetting::on_kpi_report_port_reset_to_default_clicked()
{
    QJsonObject jsonKeys;
    QJsonArray jsonArray;
    QJsonDocument jsonDoc;
    QString kpi_report_port=ui->kpi_report_port_lineEdit->text();

    if(kpi_report_port==""){
        QString Portmsg = QString("Please enter the port number");
        QMessageBox::information(this,"Erorr",Portmsg );
        return;
    }

    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("password","finecho@007");
    jsonKeys.insert("endpoint","RestoreAndDefault_Kpiloggerapi");
    jsonKeys.insert("oldport",kpi_report_port);

    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);

    //qDebug() <<"RestoreAndDefault_Kpiloggerapi:"<< jsonDoc;

    QByteArray data;
    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000))
    {
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int m=0; m<100; m++)
        {
            socket->waitForReadyRead(1000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state() != QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data += socket->readAll();
            usleep(50000);
        }
    }else {
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonParseError json_parseError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data,&json_parseError));

    if (json_parseError.error != QJsonParseError::NoError)
    {
        qDebug() << "JSON parse error: "<< json_parseError.errorString();
    }

   // qDebug() << loadDoc;
    QJsonObject rootObject = loadDoc.object();
    QJsonArray fieldJsonValueArray = rootObject.value("field").toArray();

    QJsonValue fieldVal;
    QJsonObject fieldOject;

    QString Status;
    QString Description;
    QString service;

    fieldVal = fieldJsonValueArray.at(0);
    fieldOject = fieldVal.toObject();
    Status = fieldOject.value("result").toString();

    if(Status == "success"){
        ui->kpi_report_port_lineEdit->setText("9876");
        oldKPI_Report_port="9876";
        fieldVal=fieldJsonValueArray.at(2);
        fieldOject=fieldVal.toObject();
        service=fieldOject.value("service").toString();
    }else if(Description == "Provided port is busy,Please provide different port no."){
        ui->lineEdit_APIPort->setText("9876");
    }

    fieldVal = fieldJsonValueArray.at(1);
    fieldOject = fieldVal.toObject();
    Description = fieldOject.value("reason").toString();

    socket->close();

    QString message = QString("KPI Report Reset port: " + Status + "\n" + Description +"\n"+service);
    QMessageBox::information(this,"Result", message );
}

void CommissionSetting::on_percentage_Set_Button_clicked()
{
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;
    QJsonArray jsonArray;
    QString password;

    if(ui->percenatge_lineEdit->text()==""){
        QMessageBox::information(this,"Result","Please enter the percentage");
        return;
    }

    if(oldPercent.toInt()==ui->percenatge_lineEdit->text().toInt()){
        QMessageBox::information(this,"Result","Please enter different percentage value.");
        return;
    }

    if(oldPercent.toInt() > ui->percenatge_lineEdit->text().toInt())
    {
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this,"Warning","Old data will be deleted, do you want to continue?",QMessageBox::Yes | QMessageBox::No);
        if(reply==QMessageBox::No)
        {
            ui->percentage_Set_Button->setEnabled(false);
            ui->percenatge_lineEdit->setText(oldPercent);
            return;
        }
    }

    jsonKeys.insert("username","rajendra");
    jsonKeys.insert("passcode","finecho@007");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("endpoint","Set_Disk_Space_Percentage");
    jsonKeys.insert("percentage",ui->percenatge_lineEdit->text());
    jsonArray.append(jsonKeys);
    jsonDoc = QJsonDocument(jsonArray);

    //qDebug() <<"Set_Disk_Space_Percentage:"<< jsonDoc;

    QByteArray jByte(jsonDoc.toJson(QJsonDocument::Compact));
    int newNum = jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    QByteArray data;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000)){
        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int p=0;p<100;p++){
            socket->waitForReadyRead(10000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state()!=QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data+=socket->readAll();
            usleep(50000);
        }
    }else{

        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    QJsonParseError jsonParseError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(data,&jsonParseError));
    if(jsonParseError.error!=QJsonParseError::NoError){
        qDebug() << "Json Parse Error:"<<jsonParseError.errorString();
    }
    //qDebug() << loadDoc;

    QJsonObject rootObject=loadDoc.object();
    QJsonArray jsonValArray=rootObject.value("field").toArray();

    QJsonObject fieldObject;
    QJsonValue fieldVal;

    QString result,description;

    fieldVal=jsonValArray.at(0);
    fieldObject=fieldVal.toObject();
    result=fieldObject.value("result").toString();

    if(result=="failed"||result=="fail"){
        ui->percenatge_lineEdit->setText(oldPercent);
    }else if(result=="success"){
        oldPercent=ui->percenatge_lineEdit->text();
    }

    fieldVal=jsonValArray.at(1);
    fieldObject=fieldVal.toObject();
    description=fieldObject.value("reason").toString();

    socket->close();
    ui->percentage_Set_Button->setEnabled(false);
    QString message=QString("Limit Disc Usage Set:"+result+"\n"+description);
    QMessageBox::information(this,"Result",message);
}


void CommissionSetting::on_awl_download_Button_clicked()
{
    QJsonArray jsonArray;
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;

    jsonKeys.insert("username","lokesh");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("password","finehco@007");
    jsonKeys.insert("endpoint","get_awlFile");
    jsonKeys.insert("source",ui->comboBox_databases->currentText());

    jsonArray.append(jsonKeys);

    jsonDoc=QJsonDocument(jsonArray);
   // qDebug() <<"get_awlFile:"<< jsonDoc;

    QByteArray jByte=jsonDoc.toJson(QJsonDocument::Compact);

    int newNum=jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    QString data;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000)){

        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int p=0;p<100;p++){
            socket->waitForReadyRead(10000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state()!=QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data+=socket->readAll();
            usleep(50000);
        }

    }else{
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }

    if(data==""){
        QMessageBox::information(this,"Result","No data found");
        return;
    }
   // qDebug() << data;

    QSettings pathSetting(PATHSAVE,APPLICATION);
    QString path;
    QString selected_path;

    path = pathSetting.value(PATHSAVE).toString();
    QDir dir(path);

    QString dateString = (QDateTime::currentDateTime()).toString("yyyy-MM-dd_hhmmss");
    //qDebug()<<dateString;

    if(path == "" || !dir.exists() ){
         selected_path = QFileDialog::getExistingDirectory(this,tr("Choose Folder"));
         pathSetting.setValue(PATHSAVE,selected_path);
    }else{
         selected_path = QFileDialog::getSaveFileName(this,tr("save File"),path+dateString+"_sample.AWL",tr("Text Files (*.AWL *.db);;All Files (*)"));
    }
        QString Sample;
        //QString filePath = QFileDialog::getSaveFileName(this,tr("Save file"),path+"sample.AWL",tr("Text Files (*.AWL *.db);;All Files (*)"));
        QFile file(selected_path);

        if(!file.open(QIODevice::WriteOnly | QIODevice::Text)){
            qDebug() << "file not opened...";
            QMessageBox::information(this,"Result",file.errorString());
            return;
        }
        QTextStream out(&file);

        for(int i=0;i<data.size();i++){
            if(data.at(i)=="\n"){
                QByteArray ba;
                ba.append(Sample);
                out << QByteArray::fromBase64(ba).simplified();
                out << "\n";
                Sample="";
            }else{
                Sample+=data.at(i);
            }
           }
        file.close();

        if(selected_path != ""){
            QFileInfo file(selected_path);
            QStringList list = selected_path.split(file.fileName());
            selected_path=list[0];
        }else{
            selected_path=path;
        }

    if(selected_path != path)
        pathSetting.setValue(PATHSAVE,selected_path);

    socket->close();
    QMessageBox::information(this,"Result","file downloaded successfully.");
}

void CommissionSetting::on_kpi_awl_download_Button_clicked()
{
    QJsonArray jsonArray;
    QJsonObject jsonKeys;
    QJsonDocument jsonDoc;

    jsonKeys.insert("username","lokesh");
    jsonKeys.insert("authkey","abcd");
    jsonKeys.insert("password","finehco@007");
    jsonKeys.insert("endpoint","get_kpi_awlFile");
    jsonKeys.insert("source",ui->comboBox_databases->currentText());

    jsonArray.append(jsonKeys);

    jsonDoc=QJsonDocument(jsonArray);
   // qDebug() <<"get_kpi_awlFile:"<< jsonDoc;

    QByteArray jByte=jsonDoc.toJson(QJsonDocument::Compact);

    int newNum=jByte.size();
    QString strLen = add_padding(QString::number(newNum));

    QString data;

    socket->connectToHost(Str_IPAddress,Str_port.toInt());
    if(socket->waitForConnected(10000)){

        socket->write(strLen.toUtf8());
        socket->waitForBytesWritten(30000);

        socket->write(jByte);
        socket->waitForBytesWritten(30000);

        for(int p=0;p<100;p++){
            socket->waitForReadyRead(10000);
            QApplication::setOverrideCursor(Qt::WaitCursor);
            if(socket->state()!=QAbstractSocket::ConnectedState){
                QApplication::setOverrideCursor(Qt::ArrowCursor);
                break;
            }
            data+=socket->readAll();
            usleep(50000);
        }
    }else{
        QMessageBox msgBox;
        msgBox.setText("Error: " + socket->errorString() + "\nPlease Check connectivity to server");
        msgBox.exec();
        ui->lbl_Connection->setStyleSheet("background-color:red;");
        ui->pushButton_connect->setText("Connect");
        ui->lbl_error_msg->setText("Connection lost");
        m_pingThread->exit();
        timer->stop();
        Disablefunc();
        ui->comboBox_databases->clear();
        clearWidgets();
        socket->close();
        return;
    }
    if(data==""){
        QMessageBox::information(this,"Result","No data found");
        return;
    }

    QSettings pathSetting(PATHSAVE,APPLICATION);
    QString path;
    QString selected_path;

    path = pathSetting.value(PATHSAVE).toString();
    QDir dir(path);
    QString dateString = (QDateTime::currentDateTime()).toString("yyyy-MM-dd_hhmmss");

    if(path == "" || !dir.exists() ){
        selected_path = QFileDialog::getExistingDirectory(this,tr("Choose Folder"));
        pathSetting.setValue(PATHSAVE,selected_path);
    }else{
        selected_path = QFileDialog::getSaveFileName(this,tr("save File"),path+dateString+"_sample.AWL",tr("Text Files (*.AWL *.db);;All Files (*)"));
    }
        QString Sample;
        //QString filePath = QFileDialog::getSaveFileName(this,tr("Save file"),qApp->applicationDirPath(),tr("Text Files (*.AWL *.db);;All Files (*)"));
        QFile file(selected_path);

        if(!file.open(QIODevice::WriteOnly | QIODevice::Text)){
            qDebug() << "file not opened...";
            QMessageBox::information(this,"Result",file.errorString());
            return;
        }
        QTextStream out(&file);

            for(int i=0;i<data.size();i++){
                if(data.at(i)=="\n"){
                    QByteArray ba;
                    ba.append(Sample);
                    //finalData+=QByteArray::fromBase64(ba);
                    out << QByteArray::fromBase64(ba).simplified();
                    out << "\n";
                    Sample="";
                }else{
                    Sample+=data.at(i);
                }
            }
            file.close();

            if(selected_path != ""){
                QFileInfo file(selected_path);
                QStringList list = selected_path.split(file.fileName());
                selected_path=list[0];
            }else{
                selected_path=path;
            }

    if(selected_path != path)
        pathSetting.setValue(PATHSAVE,selected_path);

    socket->close();
    QMessageBox::information(this,"Result","file downloaded successfully.");

}

void CommissionSetting::on_percenatge_lineEdit_textEdited(const QString &arg1)
{
   // qDebug() <<"current:"<< arg1;
    ui->percentage_Set_Button->setEnabled(true);

    if(oldPercent.toInt() == arg1.toInt() ){
        ui->percentage_Set_Button->setEnabled(false);
    }
}
