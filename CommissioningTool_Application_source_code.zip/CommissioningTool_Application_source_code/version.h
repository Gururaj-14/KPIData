/*
FileName	:version
Purpose     :This Files is used to set the application versions.
Authour     :Gururaj B M / Kasturi Rangan.
*/

#ifndef VERSION_H
#define VERSION_H

#define VERSION_MAJ 2
#define VERSION_MIN 0
#define VERSION_REV 2

#define DEFAULT_PORT "6789"

#endif // VERSION_H
