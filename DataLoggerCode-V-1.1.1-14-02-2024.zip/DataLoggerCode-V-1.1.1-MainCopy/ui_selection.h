/********************************************************************************
** Form generated from reading UI file 'selection.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SELECTION_H
#define UI_SELECTION_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Selection
{
public:
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_3;
    QToolButton *toolButton;
    QLabel *label;
    QSpacerItem *horizontalSpacer;
    QToolButton *toolButton_2;
    QLabel *label_Location;
    QLabel *lbl_Connection;
    QComboBox *comboBox_ConnectedIPs;
    QPushButton *pushButton_connect;
    QComboBox *comboBox_databases;
    QPushButton *pushButton_about;
    QPushButton *pushButton;
    QTabWidget *tabWidget;
    QWidget *Search;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QLabel *m_lblLP_12;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QLabel *m_lblLP_6;
    QDateTimeEdit *Pvalue_StartdateTime;
    QTimeEdit *timeEdit_PValueStart;
    QPushButton *pshbtnSearchNow;
    QRadioButton *End_PvradioBtn;
    QDateTimeEdit *Pvalue_EnddateTime;
    QTimeEdit *timeEdit_PValueEnd;
    QRadioButton *Dur_PvradioBtn;
    QComboBox *cmbBx_EtimeDur;
    QLabel *label_TSDurPv;
    QSpacerItem *horizontalSpacer_14;
    QVBoxLayout *verticalLayout;
    QLabel *m_lblLP_13;
    QFrame *line;
    QHBoxLayout *horizontalLayout_7;
    QLabel *m_lblLP_14;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_13;
    QComboBox *comboBox_CriParm;
    QComboBox *comboBox_CriOpr;
    QLineEdit *lineEdit_Parm;
    QSpacerItem *horizontalSpacer_15;
    QHBoxLayout *horizontalLayout_8;
    QLabel *m_lblLP_15;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_14;
    QComboBox *comboBox_AndCriParm;
    QComboBox *comboBox_AndCriOpr;
    QLineEdit *lineEdit_AndParm;
    QSpacerItem *horizontalSpacer_16;
    QVBoxLayout *verticalLayout_2;
    QLabel *m_lblLP_17;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout_15;
    QComboBox *cmbx_Discreate;
    QComboBox *comboBox_true;
    QSpacerItem *horizontalSpacer_17;
    QHBoxLayout *horizontalLayout_12;
    QLabel *m_lblLP_19;
    QSpacerItem *horizontalSpacer_12;
    QHBoxLayout *horizontalLayout_16;
    QComboBox *cmbx_DiscreateAnd;
    QComboBox *comboBox_false;
    QSpacerItem *horizontalSpacer_18;
    QHBoxLayout *horizontalLayout_22;
    QFrame *line_3;
    QSpacerItem *horizontalSpacer_13;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *PshBtn_search;
    QWidget *Select;
    QVBoxLayout *verticalLayout_40;
    QVBoxLayout *verticalLayout_5;
    QLabel *m_lblLP_18;
    QFrame *line_4;
    QHBoxLayout *horizontalLayout_44;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_2;
    QLabel *lbl_TSCount;
    QSpacerItem *horizontalSpacer_3;
    QTreeWidget *treeWidget_ParameterTimeValue;
    QHBoxLayout *horizontalLayout_97;
    QLineEdit *lineEdit_Before;
    QLabel *m_lblLP_57;
    QLineEdit *lineEdit_After;
    QLabel *m_lblLP_58;
    QSpacerItem *horizontalSpacer_7;
    QVBoxLayout *verticalLayout_39;
    QFrame *frame_17;
    QVBoxLayout *verticalLayout_30;
    QHBoxLayout *horizontalLayout_74;
    QLabel *label_21;
    QSpacerItem *horizontalSpacer_34;
    QHBoxLayout *horizontalLayout_36;
    QLabel *m_lblLP_8;
    QSpacerItem *horizontalSpacer_32;
    QHBoxLayout *horizontalLayout_24;
    QDateTimeEdit *TimeStamp_StartTime;
    QTimeEdit *timeEdit_StartTime;
    QPushButton *pshbtnSelectNow;
    QSpacerItem *horizontalSpacer_33;
    QHBoxLayout *horizontalLayout_75;
    QRadioButton *radioButton_TSEndTime;
    QLabel *m_lblLP_44;
    QSpacerItem *horizontalSpacer_35;
    QHBoxLayout *horizontalLayout_76;
    QDateTimeEdit *TimeStamp_EndTime;
    QTimeEdit *timeEdit_EndTime;
    QSpacerItem *horizontalSpacer_63;
    QHBoxLayout *horizontalLayout_77;
    QRadioButton *radioButton_TSDurTime;
    QLabel *m_lblLP_45;
    QSpacerItem *horizontalSpacer_64;
    QHBoxLayout *horizontalLayout_78;
    QComboBox *cmbBx_Etime;
    QLabel *label_TSDur;
    QSpacerItem *horizontalSpacer_65;
    QVBoxLayout *verticalLayout_38;
    QLabel *m_lblLP_46;
    QHBoxLayout *horizontalLayout_11;
    QComboBox *cmbBx_Samples;
    QLabel *label_Samples;
    QLabel *m_lblLP_50;
    QHBoxLayout *horizontalLayout_43;
    QComboBox *cmbBx_SavedGroup;
    QLabel *label_Samples_6;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_11;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QVBoxLayout *verticalLayout_20;
    QGridLayout *gridLayoutTree;
    QHBoxLayout *horizontalLayout_18;
    QFrame *frame_trackType;
    QVBoxLayout *verticalLayout_7;
    QTreeWidget *treeWidget_TrackTypes;
    QVBoxLayout *verticalLayout_10;
    QPushButton *pshBtn_clearParams;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_17;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *PshBtn_PLot;
    QWidget *Plot;
    QVBoxLayout *verticalLayout_15;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_14;
    QVBoxLayout *verticalLayout_19;
    QRadioButton *radioButton_x_axis;
    QRadioButton *radioButton_y_axis;
    QRadioButton *radioButton_y_axis2;
    QLabel *label_Samples_2;
    QVBoxLayout *verticalLayout_13;
    QLabel *m_lblLP;
    QComboBox *cmbBx_Type;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *m_PshBtn_SavedPlots;
    QPushButton *m_PshBtn_Delete;
    QPushButton *m_PshBtn_Save;
    QPushButton *m_PshBtn_export;
    QVBoxLayout *verticalLayout_21;
    QLabel *m_lblLP_2;
    QPushButton *m_PshBtn_Scaling;
    QPushButton *m_PshBtn_ImportGraph;
    QPushButton *m_PshBtn_exportcsvFrmDB;
    QSpacerItem *verticalSpacer_3;
    QVBoxLayout *verticalLayout_16;
    QCustomPlot *customPlot;
    QLabel *label_sel;
    QHBoxLayout *horizontalLayout_21;
    QVBoxLayout *verticalLayout_17;
    QLabel *label_StartTime;
    QSpacerItem *horizontalSpacer_19;
    QLabel *label_x_y;
    QSpacerItem *horizontalSpacer_20;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_Etime;
    QLabel *label_nan;

    void setupUi(QWidget *Selection)
    {
        if (Selection->objectName().isEmpty())
            Selection->setObjectName(QString::fromUtf8("Selection"));
        Selection->resize(1239, 668);
        Selection->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_12 = new QVBoxLayout(Selection);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(4);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, -1, 1, -1);
        toolButton = new QToolButton(Selection);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setStyleSheet(QString::fromUtf8("QToolButton\n"
"{\n"
"border:none\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/C_logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(25, 25));

        horizontalLayout_3->addWidget(toolButton);

        label = new QLabel(Selection);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(14);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(204, 0, 0);"));

        horizontalLayout_3->addWidget(label);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        toolButton_2 = new QToolButton(Selection);
        toolButton_2->setObjectName(QString::fromUtf8("toolButton_2"));
        toolButton_2->setMinimumSize(QSize(30, 0));
        toolButton_2->setStyleSheet(QString::fromUtf8("QToolButton\n"
"{\n"
"border:none\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/own-position-icon-DayNight.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_2->setIcon(icon1);
        toolButton_2->setIconSize(QSize(30, 30));

        horizontalLayout_3->addWidget(toolButton_2);

        label_Location = new QLabel(Selection);
        label_Location->setObjectName(QString::fromUtf8("label_Location"));
        label_Location->setStyleSheet(QString::fromUtf8("font: 11pt \"MS Shell Dlg 2\";"));

        horizontalLayout_3->addWidget(label_Location);

        lbl_Connection = new QLabel(Selection);
        lbl_Connection->setObjectName(QString::fromUtf8("lbl_Connection"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(30);
        sizePolicy1.setVerticalStretch(30);
        sizePolicy1.setHeightForWidth(lbl_Connection->sizePolicy().hasHeightForWidth());
        lbl_Connection->setSizePolicy(sizePolicy1);
        lbl_Connection->setMinimumSize(QSize(10, 30));
        lbl_Connection->setMaximumSize(QSize(10, 16777215));
        lbl_Connection->setBaseSize(QSize(30, 30));
        lbl_Connection->setAutoFillBackground(false);
        lbl_Connection->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        horizontalLayout_3->addWidget(lbl_Connection);

        comboBox_ConnectedIPs = new QComboBox(Selection);
        comboBox_ConnectedIPs->setObjectName(QString::fromUtf8("comboBox_ConnectedIPs"));
        comboBox_ConnectedIPs->setMinimumSize(QSize(230, 30));
        comboBox_ConnectedIPs->setStyleSheet(QString::fromUtf8("font: 11pt \"MS Shell Dlg 2\";"));

        horizontalLayout_3->addWidget(comboBox_ConnectedIPs);

        pushButton_connect = new QPushButton(Selection);
        pushButton_connect->setObjectName(QString::fromUtf8("pushButton_connect"));
        pushButton_connect->setMinimumSize(QSize(85, 30));
        pushButton_connect->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
""));

        horizontalLayout_3->addWidget(pushButton_connect);

        comboBox_databases = new QComboBox(Selection);
        comboBox_databases->setObjectName(QString::fromUtf8("comboBox_databases"));
        comboBox_databases->setMinimumSize(QSize(140, 30));
        QFont font1;
        font1.setPointSize(11);
        comboBox_databases->setFont(font1);

        horizontalLayout_3->addWidget(comboBox_databases);

        pushButton_about = new QPushButton(Selection);
        pushButton_about->setObjectName(QString::fromUtf8("pushButton_about"));
        pushButton_about->setMinimumSize(QSize(85, 30));
        pushButton_about->setMaximumSize(QSize(85, 30));
        pushButton_about->setFont(font1);
        pushButton_about->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_3->addWidget(pushButton_about);

        pushButton = new QPushButton(Selection);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(85, 30));
        pushButton->setMaximumSize(QSize(85, 30));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
""));

        horizontalLayout_3->addWidget(pushButton);


        verticalLayout_12->addLayout(horizontalLayout_3);

        tabWidget = new QTabWidget(Selection);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font2.setPointSize(11);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        tabWidget->setFont(font2);
        tabWidget->setStyleSheet(QString::fromUtf8("font: 11pt \"MS Shell Dlg 2\";\n"
""));
        tabWidget->setTabShape(QTabWidget::Rounded);
        tabWidget->setTabBarAutoHide(false);
        Search = new QWidget();
        Search->setObjectName(QString::fromUtf8("Search"));
        verticalLayout_3 = new QVBoxLayout(Search);
        verticalLayout_3->setSpacing(1);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(4, 0, 4, 0);
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        m_lblLP_12 = new QLabel(Search);
        m_lblLP_12->setObjectName(QString::fromUtf8("m_lblLP_12"));
        m_lblLP_12->setMinimumSize(QSize(200, 30));
        m_lblLP_12->setMaximumSize(QSize(200, 30));
        m_lblLP_12->setFont(font2);
        m_lblLP_12->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        horizontalLayout_5->addWidget(m_lblLP_12);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        m_lblLP_6 = new QLabel(Search);
        m_lblLP_6->setObjectName(QString::fromUtf8("m_lblLP_6"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(m_lblLP_6->sizePolicy().hasHeightForWidth());
        m_lblLP_6->setSizePolicy(sizePolicy2);
        m_lblLP_6->setMinimumSize(QSize(80, 30));
        m_lblLP_6->setMaximumSize(QSize(16777215, 30));
        m_lblLP_6->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout->addWidget(m_lblLP_6);

        Pvalue_StartdateTime = new QDateTimeEdit(Search);
        Pvalue_StartdateTime->setObjectName(QString::fromUtf8("Pvalue_StartdateTime"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(Pvalue_StartdateTime->sizePolicy().hasHeightForWidth());
        Pvalue_StartdateTime->setSizePolicy(sizePolicy3);
        Pvalue_StartdateTime->setMinimumSize(QSize(130, 30));
        Pvalue_StartdateTime->setMaximumSize(QSize(16777215, 30));
        Pvalue_StartdateTime->setFont(font2);
        Pvalue_StartdateTime->setStyleSheet(QString::fromUtf8(""));
        Pvalue_StartdateTime->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        Pvalue_StartdateTime->setCurrentSection(QDateTimeEdit::DaySection);
        Pvalue_StartdateTime->setCalendarPopup(true);

        horizontalLayout->addWidget(Pvalue_StartdateTime);

        timeEdit_PValueStart = new QTimeEdit(Search);
        timeEdit_PValueStart->setObjectName(QString::fromUtf8("timeEdit_PValueStart"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(timeEdit_PValueStart->sizePolicy().hasHeightForWidth());
        timeEdit_PValueStart->setSizePolicy(sizePolicy4);
        timeEdit_PValueStart->setMinimumSize(QSize(135, 30));
        timeEdit_PValueStart->setMaximumSize(QSize(135, 30));
        timeEdit_PValueStart->setStyleSheet(QString::fromUtf8(""));
        timeEdit_PValueStart->setCalendarPopup(true);

        horizontalLayout->addWidget(timeEdit_PValueStart);

        pshbtnSearchNow = new QPushButton(Search);
        pshbtnSearchNow->setObjectName(QString::fromUtf8("pshbtnSearchNow"));
        pshbtnSearchNow->setMinimumSize(QSize(40, 30));
        pshbtnSearchNow->setMaximumSize(QSize(50, 30));
        pshbtnSearchNow->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
""));

        horizontalLayout->addWidget(pshbtnSearchNow);

        End_PvradioBtn = new QRadioButton(Search);
        End_PvradioBtn->setObjectName(QString::fromUtf8("End_PvradioBtn"));
        End_PvradioBtn->setMinimumSize(QSize(90, 30));
        End_PvradioBtn->setMaximumSize(QSize(16777215, 30));

        horizontalLayout->addWidget(End_PvradioBtn);

        Pvalue_EnddateTime = new QDateTimeEdit(Search);
        Pvalue_EnddateTime->setObjectName(QString::fromUtf8("Pvalue_EnddateTime"));
        sizePolicy3.setHeightForWidth(Pvalue_EnddateTime->sizePolicy().hasHeightForWidth());
        Pvalue_EnddateTime->setSizePolicy(sizePolicy3);
        Pvalue_EnddateTime->setMinimumSize(QSize(130, 30));
        Pvalue_EnddateTime->setMaximumSize(QSize(16777215, 30));
        Pvalue_EnddateTime->setStyleSheet(QString::fromUtf8("/*QDateTimeEdit\n"
"{\n"
"background-color: rgb(212, 212, 212);\n"
"}\n"
"QDateTimeEdit:!enabled\n"
"{	\n"
"background-color: rgb(212, 212, 212);\n"
"	color:black;\n"
"}*/"));
        Pvalue_EnddateTime->setCalendarPopup(true);

        horizontalLayout->addWidget(Pvalue_EnddateTime);

        timeEdit_PValueEnd = new QTimeEdit(Search);
        timeEdit_PValueEnd->setObjectName(QString::fromUtf8("timeEdit_PValueEnd"));
        sizePolicy4.setHeightForWidth(timeEdit_PValueEnd->sizePolicy().hasHeightForWidth());
        timeEdit_PValueEnd->setSizePolicy(sizePolicy4);
        timeEdit_PValueEnd->setMinimumSize(QSize(135, 30));
        timeEdit_PValueEnd->setMaximumSize(QSize(135, 30));
        timeEdit_PValueEnd->setStyleSheet(QString::fromUtf8("/*background-color: rgb(212, 212, 212);*/"));
        timeEdit_PValueEnd->setCalendarPopup(true);

        horizontalLayout->addWidget(timeEdit_PValueEnd);

        Dur_PvradioBtn = new QRadioButton(Search);
        Dur_PvradioBtn->setObjectName(QString::fromUtf8("Dur_PvradioBtn"));
        Dur_PvradioBtn->setMinimumSize(QSize(85, 30));
        Dur_PvradioBtn->setMaximumSize(QSize(16777215, 30));

        horizontalLayout->addWidget(Dur_PvradioBtn);

        cmbBx_EtimeDur = new QComboBox(Search);
        cmbBx_EtimeDur->setObjectName(QString::fromUtf8("cmbBx_EtimeDur"));
        cmbBx_EtimeDur->setMinimumSize(QSize(100, 30));
        cmbBx_EtimeDur->setMaximumSize(QSize(16777215, 30));

        horizontalLayout->addWidget(cmbBx_EtimeDur);

        label_TSDurPv = new QLabel(Search);
        label_TSDurPv->setObjectName(QString::fromUtf8("label_TSDurPv"));
        label_TSDurPv->setMinimumSize(QSize(170, 30));
        label_TSDurPv->setMaximumSize(QSize(16777215, 30));

        horizontalLayout->addWidget(label_TSDurPv);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_14);


        verticalLayout_3->addLayout(horizontalLayout);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        m_lblLP_13 = new QLabel(Search);
        m_lblLP_13->setObjectName(QString::fromUtf8("m_lblLP_13"));
        m_lblLP_13->setMinimumSize(QSize(0, 30));
        m_lblLP_13->setMaximumSize(QSize(16777215, 30));
        m_lblLP_13->setFont(font2);
        m_lblLP_13->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        verticalLayout->addWidget(m_lblLP_13);

        line = new QFrame(Search);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFont(font2);
        line->setLineWidth(1);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);


        verticalLayout_3->addLayout(verticalLayout);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        m_lblLP_14 = new QLabel(Search);
        m_lblLP_14->setObjectName(QString::fromUtf8("m_lblLP_14"));
        m_lblLP_14->setMinimumSize(QSize(100, 20));
        m_lblLP_14->setMaximumSize(QSize(100, 20));
        m_lblLP_14->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_7->addWidget(m_lblLP_14);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_4);


        verticalLayout_3->addLayout(horizontalLayout_7);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(30);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        comboBox_CriParm = new QComboBox(Search);
        comboBox_CriParm->setObjectName(QString::fromUtf8("comboBox_CriParm"));
        comboBox_CriParm->setMinimumSize(QSize(350, 30));
        comboBox_CriParm->setMaximumSize(QSize(350, 30));
        comboBox_CriParm->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_13->addWidget(comboBox_CriParm);

        comboBox_CriOpr = new QComboBox(Search);
        comboBox_CriOpr->setObjectName(QString::fromUtf8("comboBox_CriOpr"));
        comboBox_CriOpr->setMinimumSize(QSize(65, 30));
        comboBox_CriOpr->setMaximumSize(QSize(65, 30));

        horizontalLayout_13->addWidget(comboBox_CriOpr);

        lineEdit_Parm = new QLineEdit(Search);
        lineEdit_Parm->setObjectName(QString::fromUtf8("lineEdit_Parm"));
        lineEdit_Parm->setMinimumSize(QSize(100, 30));
        lineEdit_Parm->setMaximumSize(QSize(100, 30));

        horizontalLayout_13->addWidget(lineEdit_Parm);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_15);


        verticalLayout_3->addLayout(horizontalLayout_13);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        m_lblLP_15 = new QLabel(Search);
        m_lblLP_15->setObjectName(QString::fromUtf8("m_lblLP_15"));
        m_lblLP_15->setMinimumSize(QSize(100, 20));
        m_lblLP_15->setMaximumSize(QSize(100, 20));
        m_lblLP_15->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_8->addWidget(m_lblLP_15);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_5);


        verticalLayout_3->addLayout(horizontalLayout_8);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(30);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        comboBox_AndCriParm = new QComboBox(Search);
        comboBox_AndCriParm->setObjectName(QString::fromUtf8("comboBox_AndCriParm"));
        comboBox_AndCriParm->setMinimumSize(QSize(350, 30));
        comboBox_AndCriParm->setMaximumSize(QSize(350, 30));
        comboBox_AndCriParm->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_14->addWidget(comboBox_AndCriParm);

        comboBox_AndCriOpr = new QComboBox(Search);
        comboBox_AndCriOpr->setObjectName(QString::fromUtf8("comboBox_AndCriOpr"));
        comboBox_AndCriOpr->setMinimumSize(QSize(65, 30));
        comboBox_AndCriOpr->setMaximumSize(QSize(65, 30));

        horizontalLayout_14->addWidget(comboBox_AndCriOpr);

        lineEdit_AndParm = new QLineEdit(Search);
        lineEdit_AndParm->setObjectName(QString::fromUtf8("lineEdit_AndParm"));
        lineEdit_AndParm->setMinimumSize(QSize(100, 30));
        lineEdit_AndParm->setMaximumSize(QSize(100, 30));

        horizontalLayout_14->addWidget(lineEdit_AndParm);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_16);


        verticalLayout_3->addLayout(horizontalLayout_14);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        m_lblLP_17 = new QLabel(Search);
        m_lblLP_17->setObjectName(QString::fromUtf8("m_lblLP_17"));
        m_lblLP_17->setMinimumSize(QSize(0, 20));
        m_lblLP_17->setMaximumSize(QSize(16777215, 20));
        m_lblLP_17->setFont(font2);
        m_lblLP_17->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        verticalLayout_2->addWidget(m_lblLP_17);

        line_2 = new QFrame(Search);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setLineWidth(1);
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_2);


        verticalLayout_3->addLayout(verticalLayout_2);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(30);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        cmbx_Discreate = new QComboBox(Search);
        cmbx_Discreate->setObjectName(QString::fromUtf8("cmbx_Discreate"));
        cmbx_Discreate->setMinimumSize(QSize(350, 30));
        cmbx_Discreate->setMaximumSize(QSize(350, 30));
        cmbx_Discreate->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_15->addWidget(cmbx_Discreate);

        comboBox_true = new QComboBox(Search);
        comboBox_true->setObjectName(QString::fromUtf8("comboBox_true"));
        comboBox_true->setMinimumSize(QSize(100, 30));
        comboBox_true->setMaximumSize(QSize(100, 30));

        horizontalLayout_15->addWidget(comboBox_true);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_17);


        verticalLayout_3->addLayout(horizontalLayout_15);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        m_lblLP_19 = new QLabel(Search);
        m_lblLP_19->setObjectName(QString::fromUtf8("m_lblLP_19"));
        m_lblLP_19->setMinimumSize(QSize(0, 20));
        m_lblLP_19->setMaximumSize(QSize(16777215, 20));
        m_lblLP_19->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_12->addWidget(m_lblLP_19);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_12);


        verticalLayout_3->addLayout(horizontalLayout_12);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(30);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        cmbx_DiscreateAnd = new QComboBox(Search);
        cmbx_DiscreateAnd->setObjectName(QString::fromUtf8("cmbx_DiscreateAnd"));
        cmbx_DiscreateAnd->setMinimumSize(QSize(350, 30));
        cmbx_DiscreateAnd->setMaximumSize(QSize(350, 30));
        cmbx_DiscreateAnd->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_16->addWidget(cmbx_DiscreateAnd);

        comboBox_false = new QComboBox(Search);
        comboBox_false->setObjectName(QString::fromUtf8("comboBox_false"));
        comboBox_false->setMinimumSize(QSize(100, 30));
        comboBox_false->setMaximumSize(QSize(100, 30));

        horizontalLayout_16->addWidget(comboBox_false);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_18);


        verticalLayout_3->addLayout(horizontalLayout_16);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(0);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        line_3 = new QFrame(Search);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFont(font2);
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setLineWidth(1);
        line_3->setFrameShape(QFrame::HLine);

        horizontalLayout_22->addWidget(line_3);

        horizontalSpacer_13 = new QSpacerItem(1, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_13);


        verticalLayout_3->addLayout(horizontalLayout_22);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(8);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_6);

        PshBtn_search = new QPushButton(Search);
        PshBtn_search->setObjectName(QString::fromUtf8("PshBtn_search"));
        PshBtn_search->setMinimumSize(QSize(120, 30));
        PshBtn_search->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/apply-btn.png"), QSize(), QIcon::Normal, QIcon::Off);
        PshBtn_search->setIcon(icon2);

        horizontalLayout_6->addWidget(PshBtn_search);


        verticalLayout_3->addLayout(horizontalLayout_6);

        tabWidget->addTab(Search, QString());
        Select = new QWidget();
        Select->setObjectName(QString::fromUtf8("Select"));
        verticalLayout_40 = new QVBoxLayout(Select);
        verticalLayout_40->setObjectName(QString::fromUtf8("verticalLayout_40"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        m_lblLP_18 = new QLabel(Select);
        m_lblLP_18->setObjectName(QString::fromUtf8("m_lblLP_18"));
        m_lblLP_18->setMinimumSize(QSize(0, 20));
        m_lblLP_18->setMaximumSize(QSize(16777215, 20));
        m_lblLP_18->setFont(font2);
        m_lblLP_18->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        verticalLayout_5->addWidget(m_lblLP_18);

        line_4 = new QFrame(Select);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setLineWidth(1);
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout_5->addWidget(line_4);


        verticalLayout_40->addLayout(verticalLayout_5);

        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setObjectName(QString::fromUtf8("horizontalLayout_44"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(0);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(-1, -1, 0, -1);
        label_2 = new QLabel(Select);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(100, 0));
        label_2->setMaximumSize(QSize(100, 16777215));
        label_2->setFont(font2);
        label_2->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_10->addWidget(label_2);

        lbl_TSCount = new QLabel(Select);
        lbl_TSCount->setObjectName(QString::fromUtf8("lbl_TSCount"));
        lbl_TSCount->setMinimumSize(QSize(200, 0));
        lbl_TSCount->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lbl_TSCount->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout_10->addWidget(lbl_TSCount);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_3);


        verticalLayout_4->addLayout(horizontalLayout_10);

        treeWidget_ParameterTimeValue = new QTreeWidget(Select);
        treeWidget_ParameterTimeValue->setObjectName(QString::fromUtf8("treeWidget_ParameterTimeValue"));
        treeWidget_ParameterTimeValue->setMinimumSize(QSize(320, 0));
        treeWidget_ParameterTimeValue->setMaximumSize(QSize(320, 16777215));
        treeWidget_ParameterTimeValue->setFont(font2);
        treeWidget_ParameterTimeValue->setMouseTracking(false);
        treeWidget_ParameterTimeValue->setFocusPolicy(Qt::NoFocus);
        treeWidget_ParameterTimeValue->setStyleSheet(QString::fromUtf8("QScrollBar:vertical\n"
"{\n"
"	background-color: #001a46 ; \n"
"	width: 10px; \n"
"}\n"
"QScrollBar:handle:vertical\n"
"{\n"
"	background: #ffc81d ; \n"
"   min-height: 25px; \n"
"} \n"
"/*QTreeWidget{	\n"
"	color: black;\n"
"	background-color: rgb(212, 212, 212);\n"
"	selection-background-color: rgb(212, 212, 212);\n"
"	selection-color: rgb(153, 153, 153);\n"
"	/*selection-background-color: transparent;\n"
"}\n"
"QTreeWidget::item:hover,QTreeWidget::item:hover:selected{\n"
"	border:0px;\n"
"	border-radius:0px;\n"
"	background-color: rgba(255,255, 255,100);\n"
"}\n"
"QTreeWidget::item:selected{\n"
"	border:none;\n"
"	border:0px;\n"
"	color: black;\n"
"	border-color: rgba(212, 212, 212);\n"
"	background-color: rgb(212, 212, 212);\n"
"}\n"
"\n"
"QTreeWidget::indicator:unchecked\n"
"{\n"
"	image:url(:/images/unchecked-15x15.png);\n"
"}\n"
"QTreeWidget::indicator:checked\n"
"{\n"
"	image:url(:/images/checked-15x15.png);\n"
"}\n"
"QCheckBox:indicator\n"
"{\n"
"	width  : 15px;\n"
"	height :15 px;\n"
"}\n"
"QCheckBox"
                        "::indicator:unchecked\n"
"{\n"
"	image:url(:/images/unchecked-15x15.png);\n"
"}\n"
"QCheckBox::indicator:checked\n"
"{\n"
"	image:url(:/images/checked-15x15.png);\n"
"}*/"));
        treeWidget_ParameterTimeValue->setFrameShape(QFrame::Box);
        treeWidget_ParameterTimeValue->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        treeWidget_ParameterTimeValue->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        treeWidget_ParameterTimeValue->setEditTriggers(QAbstractItemView::DoubleClicked|QAbstractItemView::EditKeyPressed);
        treeWidget_ParameterTimeValue->setSelectionMode(QAbstractItemView::SingleSelection);
        treeWidget_ParameterTimeValue->setSelectionBehavior(QAbstractItemView::SelectRows);
        treeWidget_ParameterTimeValue->setIconSize(QSize(15, 15));
        treeWidget_ParameterTimeValue->setIndentation(10);
        treeWidget_ParameterTimeValue->setRootIsDecorated(true);
        treeWidget_ParameterTimeValue->setUniformRowHeights(true);
        treeWidget_ParameterTimeValue->setAnimated(true);
        treeWidget_ParameterTimeValue->setColumnCount(0);
        treeWidget_ParameterTimeValue->header()->setVisible(false);
        treeWidget_ParameterTimeValue->header()->setStretchLastSection(true);

        verticalLayout_4->addWidget(treeWidget_ParameterTimeValue);

        horizontalLayout_97 = new QHBoxLayout();
        horizontalLayout_97->setSpacing(0);
        horizontalLayout_97->setObjectName(QString::fromUtf8("horizontalLayout_97"));
        horizontalLayout_97->setContentsMargins(0, 0, 0, 0);
        lineEdit_Before = new QLineEdit(Select);
        lineEdit_Before->setObjectName(QString::fromUtf8("lineEdit_Before"));
        lineEdit_Before->setMinimumSize(QSize(55, 30));
        lineEdit_Before->setMaximumSize(QSize(70, 30));
        lineEdit_Before->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);"));
        lineEdit_Before->setAlignment(Qt::AlignCenter);

        horizontalLayout_97->addWidget(lineEdit_Before);

        m_lblLP_57 = new QLabel(Select);
        m_lblLP_57->setObjectName(QString::fromUtf8("m_lblLP_57"));
        m_lblLP_57->setMinimumSize(QSize(80, 30));
        m_lblLP_57->setMaximumSize(QSize(80, 30));
        m_lblLP_57->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_97->addWidget(m_lblLP_57);

        lineEdit_After = new QLineEdit(Select);
        lineEdit_After->setObjectName(QString::fromUtf8("lineEdit_After"));
        lineEdit_After->setMinimumSize(QSize(55, 30));
        lineEdit_After->setMaximumSize(QSize(70, 30));
        lineEdit_After->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);"));
        lineEdit_After->setAlignment(Qt::AlignCenter);

        horizontalLayout_97->addWidget(lineEdit_After);

        m_lblLP_58 = new QLabel(Select);
        m_lblLP_58->setObjectName(QString::fromUtf8("m_lblLP_58"));
        m_lblLP_58->setMinimumSize(QSize(80, 30));
        m_lblLP_58->setMaximumSize(QSize(80, 30));
        m_lblLP_58->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_97->addWidget(m_lblLP_58);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_97->addItem(horizontalSpacer_7);


        verticalLayout_4->addLayout(horizontalLayout_97);


        horizontalLayout_44->addLayout(verticalLayout_4);

        verticalLayout_39 = new QVBoxLayout();
        verticalLayout_39->setObjectName(QString::fromUtf8("verticalLayout_39"));
        frame_17 = new QFrame(Select);
        frame_17->setObjectName(QString::fromUtf8("frame_17"));
        QSizePolicy sizePolicy5(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(frame_17->sizePolicy().hasHeightForWidth());
        frame_17->setSizePolicy(sizePolicy5);
        frame_17->setStyleSheet(QString::fromUtf8("QFrame{\n"
"border:none;\n"
"}"));
        frame_17->setFrameShape(QFrame::StyledPanel);
        frame_17->setFrameShadow(QFrame::Raised);
        verticalLayout_30 = new QVBoxLayout(frame_17);
        verticalLayout_30->setSpacing(15);
        verticalLayout_30->setObjectName(QString::fromUtf8("verticalLayout_30"));
        verticalLayout_30->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_74 = new QHBoxLayout();
        horizontalLayout_74->setObjectName(QString::fromUtf8("horizontalLayout_74"));
        label_21 = new QLabel(frame_17);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        sizePolicy3.setHeightForWidth(label_21->sizePolicy().hasHeightForWidth());
        label_21->setSizePolicy(sizePolicy3);
        label_21->setMinimumSize(QSize(100, 25));
        label_21->setFont(font2);
        label_21->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));
        label_21->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout_74->addWidget(label_21);

        horizontalSpacer_34 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_74->addItem(horizontalSpacer_34);


        verticalLayout_30->addLayout(horizontalLayout_74);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setSpacing(3);
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        horizontalLayout_36->setContentsMargins(-1, 0, 0, -1);
        m_lblLP_8 = new QLabel(frame_17);
        m_lblLP_8->setObjectName(QString::fromUtf8("m_lblLP_8"));
        sizePolicy2.setHeightForWidth(m_lblLP_8->sizePolicy().hasHeightForWidth());
        m_lblLP_8->setSizePolicy(sizePolicy2);
        m_lblLP_8->setMinimumSize(QSize(0, 25));
        m_lblLP_8->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_36->addWidget(m_lblLP_8);

        horizontalSpacer_32 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_32);


        verticalLayout_30->addLayout(horizontalLayout_36);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(12);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        horizontalLayout_24->setContentsMargins(27, -1, 0, -1);
        TimeStamp_StartTime = new QDateTimeEdit(frame_17);
        TimeStamp_StartTime->setObjectName(QString::fromUtf8("TimeStamp_StartTime"));
        sizePolicy3.setHeightForWidth(TimeStamp_StartTime->sizePolicy().hasHeightForWidth());
        TimeStamp_StartTime->setSizePolicy(sizePolicy3);
        TimeStamp_StartTime->setMinimumSize(QSize(130, 30));
        TimeStamp_StartTime->setFont(font2);
        TimeStamp_StartTime->setStyleSheet(QString::fromUtf8(""));
        TimeStamp_StartTime->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        TimeStamp_StartTime->setCurrentSection(QDateTimeEdit::DaySection);
        TimeStamp_StartTime->setCalendarPopup(true);

        horizontalLayout_24->addWidget(TimeStamp_StartTime);

        timeEdit_StartTime = new QTimeEdit(frame_17);
        timeEdit_StartTime->setObjectName(QString::fromUtf8("timeEdit_StartTime"));
        sizePolicy.setHeightForWidth(timeEdit_StartTime->sizePolicy().hasHeightForWidth());
        timeEdit_StartTime->setSizePolicy(sizePolicy);
        timeEdit_StartTime->setMinimumSize(QSize(120, 30));
        timeEdit_StartTime->setStyleSheet(QString::fromUtf8(""));
        timeEdit_StartTime->setCalendarPopup(true);

        horizontalLayout_24->addWidget(timeEdit_StartTime);

        pshbtnSelectNow = new QPushButton(frame_17);
        pshbtnSelectNow->setObjectName(QString::fromUtf8("pshbtnSelectNow"));
        pshbtnSelectNow->setMinimumSize(QSize(40, 30));
        pshbtnSelectNow->setMaximumSize(QSize(50, 30));
        pshbtnSelectNow->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
""));

        horizontalLayout_24->addWidget(pshbtnSelectNow);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_33);


        verticalLayout_30->addLayout(horizontalLayout_24);

        horizontalLayout_75 = new QHBoxLayout();
        horizontalLayout_75->setSpacing(12);
        horizontalLayout_75->setObjectName(QString::fromUtf8("horizontalLayout_75"));
        horizontalLayout_75->setContentsMargins(4, -1, -1, -1);
        radioButton_TSEndTime = new QRadioButton(frame_17);
        radioButton_TSEndTime->setObjectName(QString::fromUtf8("radioButton_TSEndTime"));
        radioButton_TSEndTime->setStyleSheet(QString::fromUtf8("/*QRadioButton::indicator:unchecked\n"
"{\n"
"	image:url(:/images/radiounchecked-20x20.png);\n"
"}\n"
"QRadioButton::indicator:checked\n"
"{\n"
"	image:url(:/images/radiochecked-20x20.png);\n"
"}*/"));

        horizontalLayout_75->addWidget(radioButton_TSEndTime);

        m_lblLP_44 = new QLabel(frame_17);
        m_lblLP_44->setObjectName(QString::fromUtf8("m_lblLP_44"));
        sizePolicy3.setHeightForWidth(m_lblLP_44->sizePolicy().hasHeightForWidth());
        m_lblLP_44->setSizePolicy(sizePolicy3);
        m_lblLP_44->setMinimumSize(QSize(0, 25));
        m_lblLP_44->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_75->addWidget(m_lblLP_44);

        horizontalSpacer_35 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_75->addItem(horizontalSpacer_35);


        verticalLayout_30->addLayout(horizontalLayout_75);

        horizontalLayout_76 = new QHBoxLayout();
        horizontalLayout_76->setSpacing(12);
        horizontalLayout_76->setObjectName(QString::fromUtf8("horizontalLayout_76"));
        horizontalLayout_76->setContentsMargins(28, -1, 0, -1);
        TimeStamp_EndTime = new QDateTimeEdit(frame_17);
        TimeStamp_EndTime->setObjectName(QString::fromUtf8("TimeStamp_EndTime"));
        sizePolicy.setHeightForWidth(TimeStamp_EndTime->sizePolicy().hasHeightForWidth());
        TimeStamp_EndTime->setSizePolicy(sizePolicy);
        TimeStamp_EndTime->setMinimumSize(QSize(130, 30));
        TimeStamp_EndTime->setStyleSheet(QString::fromUtf8("/*QDateTimeEdit\n"
"{\n"
"background-color: rgb(212, 212, 212);\n"
"}\n"
"QDateTimeEdit:!enabled\n"
"{	\n"
"background-color: rgb(212, 212, 212);\n"
"	color:black;\n"
"}*/"));
        TimeStamp_EndTime->setCalendarPopup(true);

        horizontalLayout_76->addWidget(TimeStamp_EndTime);

        timeEdit_EndTime = new QTimeEdit(frame_17);
        timeEdit_EndTime->setObjectName(QString::fromUtf8("timeEdit_EndTime"));
        sizePolicy.setHeightForWidth(timeEdit_EndTime->sizePolicy().hasHeightForWidth());
        timeEdit_EndTime->setSizePolicy(sizePolicy);
        timeEdit_EndTime->setMinimumSize(QSize(120, 30));
        timeEdit_EndTime->setStyleSheet(QString::fromUtf8(""));
        timeEdit_EndTime->setCalendarPopup(true);

        horizontalLayout_76->addWidget(timeEdit_EndTime);

        horizontalSpacer_63 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_76->addItem(horizontalSpacer_63);


        verticalLayout_30->addLayout(horizontalLayout_76);

        horizontalLayout_77 = new QHBoxLayout();
        horizontalLayout_77->setSpacing(12);
        horizontalLayout_77->setObjectName(QString::fromUtf8("horizontalLayout_77"));
        horizontalLayout_77->setContentsMargins(4, -1, -1, -1);
        radioButton_TSDurTime = new QRadioButton(frame_17);
        radioButton_TSDurTime->setObjectName(QString::fromUtf8("radioButton_TSDurTime"));
        radioButton_TSDurTime->setStyleSheet(QString::fromUtf8("/*QRadioButton::indicator:unchecked\n"
"{\n"
"	image:url(:/images/radiounchecked-20x20.png);\n"
"}\n"
"QRadioButton::indicator:checked\n"
"{\n"
"	image:url(:/images/radiochecked-20x20.png);\n"
"}*/"));

        horizontalLayout_77->addWidget(radioButton_TSDurTime);

        m_lblLP_45 = new QLabel(frame_17);
        m_lblLP_45->setObjectName(QString::fromUtf8("m_lblLP_45"));
        sizePolicy3.setHeightForWidth(m_lblLP_45->sizePolicy().hasHeightForWidth());
        m_lblLP_45->setSizePolicy(sizePolicy3);
        m_lblLP_45->setMinimumSize(QSize(0, 25));
        m_lblLP_45->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout_77->addWidget(m_lblLP_45);

        horizontalSpacer_64 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_77->addItem(horizontalSpacer_64);


        verticalLayout_30->addLayout(horizontalLayout_77);

        horizontalLayout_78 = new QHBoxLayout();
        horizontalLayout_78->setSpacing(6);
        horizontalLayout_78->setObjectName(QString::fromUtf8("horizontalLayout_78"));
        horizontalLayout_78->setContentsMargins(32, -1, 0, 6);
        cmbBx_Etime = new QComboBox(frame_17);
        cmbBx_Etime->setObjectName(QString::fromUtf8("cmbBx_Etime"));
        cmbBx_Etime->setMinimumSize(QSize(100, 30));
        cmbBx_Etime->setMaximumSize(QSize(100, 16777215));

        horizontalLayout_78->addWidget(cmbBx_Etime);

        label_TSDur = new QLabel(frame_17);
        label_TSDur->setObjectName(QString::fromUtf8("label_TSDur"));
        sizePolicy4.setHeightForWidth(label_TSDur->sizePolicy().hasHeightForWidth());
        label_TSDur->setSizePolicy(sizePolicy4);
        label_TSDur->setMinimumSize(QSize(220, 30));
        label_TSDur->setFont(font2);
        label_TSDur->setStyleSheet(QString::fromUtf8(""));
        label_TSDur->setAlignment(Qt::AlignCenter);

        horizontalLayout_78->addWidget(label_TSDur);

        horizontalSpacer_65 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_78->addItem(horizontalSpacer_65);


        verticalLayout_30->addLayout(horizontalLayout_78);


        verticalLayout_39->addWidget(frame_17);

        verticalLayout_38 = new QVBoxLayout();
        verticalLayout_38->setObjectName(QString::fromUtf8("verticalLayout_38"));
        m_lblLP_46 = new QLabel(Select);
        m_lblLP_46->setObjectName(QString::fromUtf8("m_lblLP_46"));
        sizePolicy3.setHeightForWidth(m_lblLP_46->sizePolicy().hasHeightForWidth());
        m_lblLP_46->setSizePolicy(sizePolicy3);
        m_lblLP_46->setMinimumSize(QSize(100, 25));
        m_lblLP_46->setMaximumSize(QSize(100, 25));
        m_lblLP_46->setStyleSheet(QString::fromUtf8(""));

        verticalLayout_38->addWidget(m_lblLP_46);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(4);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, -1, 100, -1);
        cmbBx_Samples = new QComboBox(Select);
        cmbBx_Samples->setObjectName(QString::fromUtf8("cmbBx_Samples"));
        sizePolicy.setHeightForWidth(cmbBx_Samples->sizePolicy().hasHeightForWidth());
        cmbBx_Samples->setSizePolicy(sizePolicy);
        cmbBx_Samples->setMinimumSize(QSize(100, 30));
        cmbBx_Samples->setMaximumSize(QSize(100, 16777215));
        cmbBx_Samples->setStyleSheet(QString::fromUtf8(""));
        cmbBx_Samples->setEditable(true);

        horizontalLayout_11->addWidget(cmbBx_Samples);

        label_Samples = new QLabel(Select);
        label_Samples->setObjectName(QString::fromUtf8("label_Samples"));
        sizePolicy.setHeightForWidth(label_Samples->sizePolicy().hasHeightForWidth());
        label_Samples->setSizePolicy(sizePolicy);
        label_Samples->setMinimumSize(QSize(126, 30));
        label_Samples->setMaximumSize(QSize(126, 30));
        label_Samples->setStyleSheet(QString::fromUtf8(""));
        label_Samples->setAlignment(Qt::AlignCenter);

        horizontalLayout_11->addWidget(label_Samples);


        verticalLayout_38->addLayout(horizontalLayout_11);

        m_lblLP_50 = new QLabel(Select);
        m_lblLP_50->setObjectName(QString::fromUtf8("m_lblLP_50"));
        sizePolicy3.setHeightForWidth(m_lblLP_50->sizePolicy().hasHeightForWidth());
        m_lblLP_50->setSizePolicy(sizePolicy3);
        m_lblLP_50->setMinimumSize(QSize(150, 25));
        m_lblLP_50->setMaximumSize(QSize(150, 25));
        m_lblLP_50->setStyleSheet(QString::fromUtf8(""));

        verticalLayout_38->addWidget(m_lblLP_50);

        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setSpacing(4);
        horizontalLayout_43->setObjectName(QString::fromUtf8("horizontalLayout_43"));
        horizontalLayout_43->setContentsMargins(0, -1, 0, -1);
        cmbBx_SavedGroup = new QComboBox(Select);
        cmbBx_SavedGroup->addItem(QString());
        cmbBx_SavedGroup->setObjectName(QString::fromUtf8("cmbBx_SavedGroup"));
        sizePolicy.setHeightForWidth(cmbBx_SavedGroup->sizePolicy().hasHeightForWidth());
        cmbBx_SavedGroup->setSizePolicy(sizePolicy);
        cmbBx_SavedGroup->setMinimumSize(QSize(200, 30));
        cmbBx_SavedGroup->setMaximumSize(QSize(125, 16777215));
        cmbBx_SavedGroup->setStyleSheet(QString::fromUtf8(""));
        cmbBx_SavedGroup->setEditable(false);

        horizontalLayout_43->addWidget(cmbBx_SavedGroup);

        label_Samples_6 = new QLabel(Select);
        label_Samples_6->setObjectName(QString::fromUtf8("label_Samples_6"));
        sizePolicy.setHeightForWidth(label_Samples_6->sizePolicy().hasHeightForWidth());
        label_Samples_6->setSizePolicy(sizePolicy);
        label_Samples_6->setMinimumSize(QSize(126, 30));
        label_Samples_6->setMaximumSize(QSize(126, 30));
        label_Samples_6->setStyleSheet(QString::fromUtf8(""));
        label_Samples_6->setAlignment(Qt::AlignCenter);

        horizontalLayout_43->addWidget(label_Samples_6);


        verticalLayout_38->addLayout(horizontalLayout_43);


        verticalLayout_39->addLayout(verticalLayout_38);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_39->addItem(verticalSpacer);


        horizontalLayout_44->addLayout(verticalLayout_39);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(5);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        scrollArea = new QScrollArea(Select);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setMinimumSize(QSize(0, 140));
        scrollArea->setMaximumSize(QSize(16777215, 140));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 416, 138));
        verticalLayout_20 = new QVBoxLayout(scrollAreaWidgetContents_2);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        verticalLayout_20->setContentsMargins(4, 4, 4, 4);
        gridLayoutTree = new QGridLayout();
        gridLayoutTree->setObjectName(QString::fromUtf8("gridLayoutTree"));

        verticalLayout_20->addLayout(gridLayoutTree);

        scrollArea->setWidget(scrollAreaWidgetContents_2);

        verticalLayout_11->addWidget(scrollArea);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(4);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        frame_trackType = new QFrame(Select);
        frame_trackType->setObjectName(QString::fromUtf8("frame_trackType"));
        QSizePolicy sizePolicy6(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(frame_trackType->sizePolicy().hasHeightForWidth());
        frame_trackType->setSizePolicy(sizePolicy6);
        frame_trackType->setMinimumSize(QSize(360, 0));
        frame_trackType->setStyleSheet(QString::fromUtf8("/*QFrame\n"
"{\n"
"	background-color: rgb(143, 180, 207);\n"
"}*/"));
        frame_trackType->setFrameShape(QFrame::NoFrame);
        frame_trackType->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(frame_trackType);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(4, 4, 4, 4);
        treeWidget_TrackTypes = new QTreeWidget(frame_trackType);
        treeWidget_TrackTypes->setObjectName(QString::fromUtf8("treeWidget_TrackTypes"));
        treeWidget_TrackTypes->setMinimumSize(QSize(291, 0));
        treeWidget_TrackTypes->setFont(font2);
        treeWidget_TrackTypes->setMouseTracking(false);
        treeWidget_TrackTypes->setFocusPolicy(Qt::NoFocus);
        treeWidget_TrackTypes->setStyleSheet(QString::fromUtf8("QScrollBar:vertical\n"
"{\n"
"	background-color: #001a46 ; \n"
"	width: 10px; \n"
"}\n"
"QScrollBar:handle:vertical\n"
"{\n"
"	background: #ffc81d ; \n"
"   min-height: 25px; \n"
"} \n"
"/*QTreeWidget{	\n"
"	color: #005797;\n"
"	background-color: rgb(143, 180, 207);\n"
"	selection-background-color:rgb(143, 180, 207);\n"
"	selection-color: rgb(255, 255, 255);\n"
"	selection-background-color: transparent;\n"
"}\n"
"QTreeWidget::item:hover,QTreeWidget::item:hover:selected{\n"
"	border:0px;\n"
"	border-radius:5px;\n"
"	background-color: rgba(255,255, 255,100);\n"
"}\n"
"QTreeWidget::item:selected{\n"
"	border:none;\n"
"	border:0px;\n"
"	color: #005797;\n"
"	border-color: rgba(143,180,207);\n"
"	background-color: rgba(143,180,207);\n"
"}\n"
"\n"
"/*QTreeWidget::indicator:unchecked\n"
"{\n"
"	image:url(:/images/unchecked-15x15.png);\n"
"}\n"
"QTreeWidget::indicator:checked\n"
"{\n"
"	image:url(:/images/checked-15x15.png);\n"
"}\n"
"QCheckBox:indicator\n"
"{\n"
"	width  : 15px;\n"
"	height :15 px;\n"
"}\n"
"QCheckBox"
                        "::indicator:unchecked\n"
"{\n"
"	image:url(:/images/unchecked-15x15.png);\n"
"}\n"
"QCheckBox::indicator:checked\n"
"{\n"
"	image:url(:/images/checked-15x15.png);\n"
"}*/"));
        treeWidget_TrackTypes->setFrameShape(QFrame::Box);
        treeWidget_TrackTypes->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        treeWidget_TrackTypes->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        treeWidget_TrackTypes->setEditTriggers(QAbstractItemView::DoubleClicked|QAbstractItemView::EditKeyPressed);
        treeWidget_TrackTypes->setSelectionMode(QAbstractItemView::SingleSelection);
        treeWidget_TrackTypes->setSelectionBehavior(QAbstractItemView::SelectRows);
        treeWidget_TrackTypes->setIconSize(QSize(15, 15));
        treeWidget_TrackTypes->setIndentation(10);
        treeWidget_TrackTypes->setRootIsDecorated(true);
        treeWidget_TrackTypes->setUniformRowHeights(true);
        treeWidget_TrackTypes->setAnimated(true);
        treeWidget_TrackTypes->setColumnCount(0);
        treeWidget_TrackTypes->header()->setVisible(false);
        treeWidget_TrackTypes->header()->setDefaultSectionSize(200);
        treeWidget_TrackTypes->header()->setStretchLastSection(true);

        verticalLayout_7->addWidget(treeWidget_TrackTypes);


        horizontalLayout_18->addWidget(frame_trackType);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(20);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(-1, 4, -1, -1);
        pshBtn_clearParams = new QPushButton(Select);
        pshBtn_clearParams->setObjectName(QString::fromUtf8("pshBtn_clearParams"));
        pshBtn_clearParams->setMinimumSize(QSize(50, 26));
        pshBtn_clearParams->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));

        verticalLayout_10->addWidget(pshBtn_clearParams);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_2);


        horizontalLayout_18->addLayout(verticalLayout_10);


        verticalLayout_11->addLayout(horizontalLayout_18);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_9);

        PshBtn_PLot = new QPushButton(Select);
        PshBtn_PLot->setObjectName(QString::fromUtf8("PshBtn_PLot"));
        PshBtn_PLot->setMinimumSize(QSize(120, 30));
        PshBtn_PLot->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));
        PshBtn_PLot->setIcon(icon2);

        horizontalLayout_17->addWidget(PshBtn_PLot);


        verticalLayout_11->addLayout(horizontalLayout_17);


        horizontalLayout_44->addLayout(verticalLayout_11);


        verticalLayout_40->addLayout(horizontalLayout_44);

        tabWidget->addTab(Select, QString());
        Plot = new QWidget();
        Plot->setObjectName(QString::fromUtf8("Plot"));
        verticalLayout_15 = new QVBoxLayout(Plot);
        verticalLayout_15->setSpacing(4);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        verticalLayout_15->setContentsMargins(4, 2, 4, 2);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(12);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setSpacing(10);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        radioButton_x_axis = new QRadioButton(Plot);
        radioButton_x_axis->setObjectName(QString::fromUtf8("radioButton_x_axis"));
        radioButton_x_axis->setMinimumSize(QSize(200, 0));
        radioButton_x_axis->setMaximumSize(QSize(200, 16777215));

        verticalLayout_19->addWidget(radioButton_x_axis);

        radioButton_y_axis = new QRadioButton(Plot);
        radioButton_y_axis->setObjectName(QString::fromUtf8("radioButton_y_axis"));
        radioButton_y_axis->setMinimumSize(QSize(200, 0));
        radioButton_y_axis->setMaximumSize(QSize(200, 16777215));

        verticalLayout_19->addWidget(radioButton_y_axis);

        radioButton_y_axis2 = new QRadioButton(Plot);
        radioButton_y_axis2->setObjectName(QString::fromUtf8("radioButton_y_axis2"));

        verticalLayout_19->addWidget(radioButton_y_axis2);

        label_Samples_2 = new QLabel(Plot);
        label_Samples_2->setObjectName(QString::fromUtf8("label_Samples_2"));
        label_Samples_2->setMinimumSize(QSize(200, 30));
        label_Samples_2->setMaximumSize(QSize(200, 30));
        label_Samples_2->setAlignment(Qt::AlignCenter);

        verticalLayout_19->addWidget(label_Samples_2);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(8);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        m_lblLP = new QLabel(Plot);
        m_lblLP->setObjectName(QString::fromUtf8("m_lblLP"));
        m_lblLP->setMinimumSize(QSize(0, 25));
        m_lblLP->setMaximumSize(QSize(16777215, 25));
        m_lblLP->setFont(font2);
        m_lblLP->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        verticalLayout_13->addWidget(m_lblLP);

        cmbBx_Type = new QComboBox(Plot);
        cmbBx_Type->setObjectName(QString::fromUtf8("cmbBx_Type"));
        cmbBx_Type->setMinimumSize(QSize(203, 30));
        cmbBx_Type->setMaximumSize(QSize(203, 16777215));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(212, 212, 212, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        QBrush brush2(QColor(255, 200, 29, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Highlight, brush2);
        palette.setBrush(QPalette::Active, QPalette::HighlightedText, brush);
        QBrush brush3(QColor(0, 0, 0, 128));
        brush3.setStyle(Qt::NoBrush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush3);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Highlight, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::HighlightedText, brush);
        QBrush brush4(QColor(0, 0, 0, 128));
        brush4.setStyle(Qt::NoBrush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush4);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Highlight, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::HighlightedText, brush);
        QBrush brush5(QColor(0, 0, 0, 128));
        brush5.setStyle(Qt::NoBrush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush5);
#endif
        cmbBx_Type->setPalette(palette);
        cmbBx_Type->setFocusPolicy(Qt::NoFocus);
        cmbBx_Type->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);"));
        cmbBx_Type->setEditable(true);

        verticalLayout_13->addWidget(cmbBx_Type);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        m_PshBtn_SavedPlots = new QPushButton(Plot);
        m_PshBtn_SavedPlots->setObjectName(QString::fromUtf8("m_PshBtn_SavedPlots"));
        m_PshBtn_SavedPlots->setMinimumSize(QSize(97, 30));
        m_PshBtn_SavedPlots->setMaximumSize(QSize(97, 30));
        m_PshBtn_SavedPlots->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));

        horizontalLayout_2->addWidget(m_PshBtn_SavedPlots);

        m_PshBtn_Delete = new QPushButton(Plot);
        m_PshBtn_Delete->setObjectName(QString::fromUtf8("m_PshBtn_Delete"));
        m_PshBtn_Delete->setMinimumSize(QSize(97, 30));
        m_PshBtn_Delete->setMaximumSize(QSize(97, 30));
        m_PshBtn_Delete->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));

        horizontalLayout_2->addWidget(m_PshBtn_Delete);


        verticalLayout_13->addLayout(horizontalLayout_2);


        verticalLayout_19->addLayout(verticalLayout_13);

        m_PshBtn_Save = new QPushButton(Plot);
        m_PshBtn_Save->setObjectName(QString::fromUtf8("m_PshBtn_Save"));
        sizePolicy.setHeightForWidth(m_PshBtn_Save->sizePolicy().hasHeightForWidth());
        m_PshBtn_Save->setSizePolicy(sizePolicy);
        m_PshBtn_Save->setMinimumSize(QSize(203, 30));
        m_PshBtn_Save->setMaximumSize(QSize(203, 30));
        m_PshBtn_Save->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/save-local.png"), QSize(), QIcon::Normal, QIcon::Off);
        m_PshBtn_Save->setIcon(icon3);

        verticalLayout_19->addWidget(m_PshBtn_Save);

        m_PshBtn_export = new QPushButton(Plot);
        m_PshBtn_export->setObjectName(QString::fromUtf8("m_PshBtn_export"));
        sizePolicy.setHeightForWidth(m_PshBtn_export->sizePolicy().hasHeightForWidth());
        m_PshBtn_export->setSizePolicy(sizePolicy);
        m_PshBtn_export->setMinimumSize(QSize(203, 30));
        m_PshBtn_export->setMaximumSize(QSize(203, 30));
        m_PshBtn_export->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/images/export.png"), QSize(), QIcon::Normal, QIcon::Off);
        m_PshBtn_export->setIcon(icon4);

        verticalLayout_19->addWidget(m_PshBtn_export);


        verticalLayout_14->addLayout(verticalLayout_19);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setSpacing(10);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        m_lblLP_2 = new QLabel(Plot);
        m_lblLP_2->setObjectName(QString::fromUtf8("m_lblLP_2"));
        m_lblLP_2->setMinimumSize(QSize(0, 20));
        m_lblLP_2->setMaximumSize(QSize(16777215, 20));
        m_lblLP_2->setFont(font2);
        m_lblLP_2->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        verticalLayout_21->addWidget(m_lblLP_2);

        m_PshBtn_Scaling = new QPushButton(Plot);
        m_PshBtn_Scaling->setObjectName(QString::fromUtf8("m_PshBtn_Scaling"));
        m_PshBtn_Scaling->setMinimumSize(QSize(203, 30));
        m_PshBtn_Scaling->setMaximumSize(QSize(203, 30));
        m_PshBtn_Scaling->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));
        m_PshBtn_Scaling->setIcon(icon3);

        verticalLayout_21->addWidget(m_PshBtn_Scaling);

        m_PshBtn_ImportGraph = new QPushButton(Plot);
        m_PshBtn_ImportGraph->setObjectName(QString::fromUtf8("m_PshBtn_ImportGraph"));
        m_PshBtn_ImportGraph->setMinimumSize(QSize(203, 30));
        m_PshBtn_ImportGraph->setMaximumSize(QSize(203, 30));
        m_PshBtn_ImportGraph->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));

        verticalLayout_21->addWidget(m_PshBtn_ImportGraph);

        m_PshBtn_exportcsvFrmDB = new QPushButton(Plot);
        m_PshBtn_exportcsvFrmDB->setObjectName(QString::fromUtf8("m_PshBtn_exportcsvFrmDB"));
        m_PshBtn_exportcsvFrmDB->setMinimumSize(QSize(203, 30));
        m_PshBtn_exportcsvFrmDB->setMaximumSize(QSize(203, 30));
        m_PshBtn_exportcsvFrmDB->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"border: 2px solid red;\n"
"border-width : 2px;\n"
"border-color: rgba(2,169,170,255);\n"
"	color: rgb(255, 255, 255);\n"
"background-color: rgba(2,169,170,255);\n"
"font: 10pt \"Open Sans\";\n"
"}\n"
"QPushButton:pressed\n"
"{\n"
"	border:1px solid red;\n"
"}\n"
" QPushButton:hover \n"
"{\n"
"     background-color:rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
" }\n"
"QToolTip\n"
"{\n"
"	background-color: rgb(255, 255, 127);\n"
"	color:rgb(0,0,0);\n"
"}\n"
"QPushButton:disabled {\n"
"background-color:rgb(211, 215, 207);\n"
"}\n"
""));

        verticalLayout_21->addWidget(m_PshBtn_exportcsvFrmDB);


        verticalLayout_14->addLayout(verticalLayout_21);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_14->addItem(verticalSpacer_3);


        horizontalLayout_4->addLayout(verticalLayout_14);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        customPlot = new QCustomPlot(Plot);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        sizePolicy6.setHeightForWidth(customPlot->sizePolicy().hasHeightForWidth());
        customPlot->setSizePolicy(sizePolicy6);
        label_sel = new QLabel(customPlot);
        label_sel->setObjectName(QString::fromUtf8("label_sel"));
        label_sel->setGeometry(QRect(340, 190, 311, 231));
        label_sel->setAutoFillBackground(false);
        label_sel->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"border: 2px solid black;\n"
"background-color: rgb(0, 0, 255);\n"
"visible:false;\n"
"}\n"
""));
        label_sel->setAlignment(Qt::AlignCenter);

        verticalLayout_16->addWidget(customPlot);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        label_StartTime = new QLabel(Plot);
        label_StartTime->setObjectName(QString::fromUtf8("label_StartTime"));
        sizePolicy2.setHeightForWidth(label_StartTime->sizePolicy().hasHeightForWidth());
        label_StartTime->setSizePolicy(sizePolicy2);
        label_StartTime->setMinimumSize(QSize(187, 30));
        label_StartTime->setMaximumSize(QSize(16777215, 30));
        label_StartTime->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);"));
        label_StartTime->setAlignment(Qt::AlignCenter);

        verticalLayout_17->addWidget(label_StartTime);


        horizontalLayout_21->addLayout(verticalLayout_17);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_19);

        label_x_y = new QLabel(Plot);
        label_x_y->setObjectName(QString::fromUtf8("label_x_y"));
        label_x_y->setMinimumSize(QSize(300, 30));
        label_x_y->setMaximumSize(QSize(16777215, 30));
        label_x_y->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);"));
        label_x_y->setAlignment(Qt::AlignCenter);

        horizontalLayout_21->addWidget(label_x_y);

        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_20);

        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        verticalLayout_18->setContentsMargins(0, -1, 0, -1);
        label_Etime = new QLabel(Plot);
        label_Etime->setObjectName(QString::fromUtf8("label_Etime"));
        sizePolicy2.setHeightForWidth(label_Etime->sizePolicy().hasHeightForWidth());
        label_Etime->setSizePolicy(sizePolicy2);
        label_Etime->setMinimumSize(QSize(187, 30));
        label_Etime->setMaximumSize(QSize(16777215, 30));
        label_Etime->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 212, 212);"));
        label_Etime->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(label_Etime);


        horizontalLayout_21->addLayout(verticalLayout_18);


        verticalLayout_16->addLayout(horizontalLayout_21);

        label_nan = new QLabel(Plot);
        label_nan->setObjectName(QString::fromUtf8("label_nan"));
        label_nan->setMinimumSize(QSize(0, 24));
        label_nan->setMaximumSize(QSize(16777215, 15));
        QFont font3;
        font3.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font3.setPointSize(9);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        label_nan->setFont(font3);
        label_nan->setStyleSheet(QString::fromUtf8("font: 9pt \"MS Shell Dlg 2\";\n"
"color: rgba(2,169,170,255);"));
        label_nan->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_16->addWidget(label_nan);


        horizontalLayout_4->addLayout(verticalLayout_16);


        verticalLayout_15->addLayout(horizontalLayout_4);

        tabWidget->addTab(Plot, QString());

        verticalLayout_12->addWidget(tabWidget);


        retranslateUi(Selection);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Selection);
    } // setupUi

    void retranslateUi(QWidget *Selection)
    {
        Selection->setWindowTitle(QCoreApplication::translate("Selection", "Selection", nullptr));
        toolButton->setText(QCoreApplication::translate("Selection", "...", nullptr));
        label->setText(QCoreApplication::translate("Selection", "KONECRANES", nullptr));
        toolButton_2->setText(QCoreApplication::translate("Selection", "...", nullptr));
        label_Location->setText(QString());
        lbl_Connection->setText(QString());
        pushButton_connect->setText(QCoreApplication::translate("Selection", "Connect", nullptr));
        pushButton_about->setText(QCoreApplication::translate("Selection", "More...", nullptr));
        pushButton->setText(QCoreApplication::translate("Selection", "Close", nullptr));
        m_lblLP_12->setText(QCoreApplication::translate("Selection", "TimeStamp Search", nullptr));
        m_lblLP_6->setText(QCoreApplication::translate("Selection", "Start time", nullptr));
        Pvalue_StartdateTime->setDisplayFormat(QCoreApplication::translate("Selection", "dd MMM yy", nullptr));
        timeEdit_PValueStart->setDisplayFormat(QCoreApplication::translate("Selection", "hh:mm:ss", nullptr));
        pshbtnSearchNow->setText(QCoreApplication::translate("Selection", "Now", nullptr));
        End_PvradioBtn->setText(QCoreApplication::translate("Selection", "End Time", nullptr));
        Pvalue_EnddateTime->setDisplayFormat(QCoreApplication::translate("Selection", "dd MMM yy ", nullptr));
        timeEdit_PValueEnd->setDisplayFormat(QCoreApplication::translate("Selection", "hh:mm:ss", nullptr));
        Dur_PvradioBtn->setText(QCoreApplication::translate("Selection", "Duration", nullptr));
        label_TSDurPv->setText(QString());
        m_lblLP_13->setText(QCoreApplication::translate("Selection", " Analog", nullptr));
        m_lblLP_14->setText(QCoreApplication::translate("Selection", "Parameter", nullptr));
        lineEdit_Parm->setText(QCoreApplication::translate("Selection", "100", nullptr));
        m_lblLP_15->setText(QCoreApplication::translate("Selection", "AND", nullptr));
        lineEdit_AndParm->setText(QCoreApplication::translate("Selection", "100", nullptr));
        m_lblLP_17->setText(QCoreApplication::translate("Selection", "Discrete", nullptr));
        m_lblLP_19->setText(QCoreApplication::translate("Selection", "AND", nullptr));
#if QT_CONFIG(tooltip)
        PshBtn_search->setToolTip(QCoreApplication::translate("Selection", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Open Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:600;\">Click to Plot</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        PshBtn_search->setText(QCoreApplication::translate("Selection", "Search", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Search), QCoreApplication::translate("Selection", "Search          ", nullptr));
        m_lblLP_18->setText(QCoreApplication::translate("Selection", "Select time and variable for plot ", nullptr));
        label_2->setText(QCoreApplication::translate("Selection", "Time stamps :      ", nullptr));
        lbl_TSCount->setText(QCoreApplication::translate("Selection", " 0 pcs", nullptr));
        lineEdit_Before->setText(QCoreApplication::translate("Selection", "30", nullptr));
        m_lblLP_57->setText(QCoreApplication::translate("Selection", " s before  ", nullptr));
        lineEdit_After->setText(QCoreApplication::translate("Selection", "30", nullptr));
        m_lblLP_58->setText(QCoreApplication::translate("Selection", " s after", nullptr));
        label_21->setText(QCoreApplication::translate("Selection", "  Adjust time", nullptr));
        m_lblLP_8->setText(QCoreApplication::translate("Selection", "  Start time", nullptr));
        TimeStamp_StartTime->setDisplayFormat(QCoreApplication::translate("Selection", "dd MMM yy", nullptr));
        timeEdit_StartTime->setDisplayFormat(QCoreApplication::translate("Selection", "hh:mm:ss", nullptr));
        pshbtnSelectNow->setText(QCoreApplication::translate("Selection", "Now", nullptr));
        radioButton_TSEndTime->setText(QString());
        m_lblLP_44->setText(QCoreApplication::translate("Selection", "End time", nullptr));
        TimeStamp_EndTime->setDisplayFormat(QCoreApplication::translate("Selection", "dd MMM yy ", nullptr));
        timeEdit_EndTime->setDisplayFormat(QCoreApplication::translate("Selection", "hh:mm:ss", nullptr));
        radioButton_TSDurTime->setText(QString());
        m_lblLP_45->setText(QCoreApplication::translate("Selection", "Duration", nullptr));
        label_TSDur->setText(QString());
        m_lblLP_46->setText(QCoreApplication::translate("Selection", "  Samples", nullptr));
        label_Samples->setText(QString());
        m_lblLP_50->setText(QCoreApplication::translate("Selection", "  GroupNames", nullptr));
        cmbBx_SavedGroup->setItemText(0, QCoreApplication::translate("Selection", "       ==None==", nullptr));

        label_Samples_6->setText(QString());
        pshBtn_clearParams->setText(QCoreApplication::translate("Selection", "Clear", nullptr));
#if QT_CONFIG(tooltip)
        PshBtn_PLot->setToolTip(QCoreApplication::translate("Selection", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Open Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:600;\">Click to Plot</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        PshBtn_PLot->setText(QCoreApplication::translate("Selection", "Plot", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Select), QCoreApplication::translate("Selection", "Select            ", nullptr));
        radioButton_x_axis->setText(QCoreApplication::translate("Selection", "Zoom/Pan X-axis", nullptr));
        radioButton_y_axis->setText(QCoreApplication::translate("Selection", "Zoom/Pan Y-axis", nullptr));
        radioButton_y_axis2->setText(QCoreApplication::translate("Selection", "Zoom/Pan Y-axis2", nullptr));
        label_Samples_2->setText(QCoreApplication::translate("Selection", " Res", nullptr));
        m_lblLP->setText(QCoreApplication::translate("Selection", "Saved Plots", nullptr));
#if QT_CONFIG(tooltip)
        cmbBx_Type->setToolTip(QCoreApplication::translate("Selection", "<html><head/><body><p>List of Saved Plots</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        m_PshBtn_SavedPlots->setText(QCoreApplication::translate("Selection", "Plot ", nullptr));
        m_PshBtn_Delete->setText(QCoreApplication::translate("Selection", "Delete", nullptr));
#if QT_CONFIG(tooltip)
        m_PshBtn_Save->setToolTip(QCoreApplication::translate("Selection", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Open Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:600;\">Click to Save Image</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        m_PshBtn_Save->setText(QCoreApplication::translate("Selection", "Save Image", nullptr));
#if QT_CONFIG(tooltip)
        m_PshBtn_export->setToolTip(QCoreApplication::translate("Selection", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Open Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:600;\">Click to Export Graph</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        m_PshBtn_export->setText(QCoreApplication::translate("Selection", "Export Graph", nullptr));
        m_lblLP_2->setText(QCoreApplication::translate("Selection", "Settings", nullptr));
#if QT_CONFIG(tooltip)
        m_PshBtn_Scaling->setToolTip(QCoreApplication::translate("Selection", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Open Sans'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:600;\">Click to Scalling</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        m_PshBtn_Scaling->setText(QCoreApplication::translate("Selection", "Scaling", nullptr));
        m_PshBtn_ImportGraph->setText(QCoreApplication::translate("Selection", "Import Graph", nullptr));
        m_PshBtn_exportcsvFrmDB->setText(QCoreApplication::translate("Selection", "Export to CSV from DB", nullptr));
        label_sel->setText(QString());
        label_StartTime->setText(QString());
        label_x_y->setText(QString());
        label_Etime->setText(QString());
        label_nan->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(Plot), QCoreApplication::translate("Selection", "Plot                 ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Selection: public Ui_Selection {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SELECTION_H
