/****************************************************************************
** Meta object code from reading C++ file 'commissionsetting.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "commissionsetting.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'commissionsetting.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CommissionSetting_t {
    QByteArrayData data[27];
    char stringdata0[732];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CommissionSetting_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CommissionSetting_t qt_meta_stringdata_CommissionSetting = {
    {
QT_MOC_LITERAL(0, 0, 17), // "CommissionSetting"
QT_MOC_LITERAL(1, 18, 29), // "on_pushButton_connect_clicked"
QT_MOC_LITERAL(2, 48, 0), // ""
QT_MOC_LITERAL(3, 49, 15), // "CheckConnection"
QT_MOC_LITERAL(4, 65, 10), // "updateTime"
QT_MOC_LITERAL(5, 76, 17), // "UpdateTimezoneUTC"
QT_MOC_LITERAL(6, 94, 43), // "on_comboBox_ConnectedIPs_curr..."
QT_MOC_LITERAL(7, 138, 4), // "arg1"
QT_MOC_LITERAL(8, 143, 28), // "on_m_PshBtn_UTC_Time_clicked"
QT_MOC_LITERAL(9, 172, 30), // "on_m_PshBtn_LocaleTime_clicked"
QT_MOC_LITERAL(10, 203, 29), // "on_toolButton_AWLFile_clicked"
QT_MOC_LITERAL(11, 233, 33), // "on_m_PshBtn_AWLFileUpload_cli..."
QT_MOC_LITERAL(12, 267, 35), // "on_m_PshBtn_PLCDataPortSave_c..."
QT_MOC_LITERAL(13, 303, 36), // "on_m_PshBtn_PLCAlarmPortSave_..."
QT_MOC_LITERAL(14, 340, 27), // "on_m_PshBtn_API_Set_clicked"
QT_MOC_LITERAL(15, 368, 29), // "on_m_PshBtn_API_Check_clicked"
QT_MOC_LITERAL(16, 398, 29), // "on_m_PshBtn_API_Reset_clicked"
QT_MOC_LITERAL(17, 428, 28), // "on_timeEdit_Time_timeChanged"
QT_MOC_LITERAL(18, 457, 4), // "time"
QT_MOC_LITERAL(19, 462, 25), // "on_m_PshBtn_Alarm_clicked"
QT_MOC_LITERAL(20, 488, 38), // "on_m_PshBtn_PLCDataPortArriva..."
QT_MOC_LITERAL(21, 527, 39), // "on_m_PshBtn_PLCAlarmPortArriv..."
QT_MOC_LITERAL(22, 567, 44), // "on_comboBox_ConnectedIPs_curr..."
QT_MOC_LITERAL(23, 612, 34), // "on_m_PshBtn_DataPort_Reset_cl..."
QT_MOC_LITERAL(24, 647, 35), // "on_m_PshBtn_AlarmPort_Reset_c..."
QT_MOC_LITERAL(25, 683, 29), // "on_toolButton_Version_clicked"
QT_MOC_LITERAL(26, 713, 18) // "onComboTextChanged"

    },
    "CommissionSetting\0on_pushButton_connect_clicked\0"
    "\0CheckConnection\0updateTime\0"
    "UpdateTimezoneUTC\0"
    "on_comboBox_ConnectedIPs_currentTextChanged\0"
    "arg1\0on_m_PshBtn_UTC_Time_clicked\0"
    "on_m_PshBtn_LocaleTime_clicked\0"
    "on_toolButton_AWLFile_clicked\0"
    "on_m_PshBtn_AWLFileUpload_clicked\0"
    "on_m_PshBtn_PLCDataPortSave_clicked\0"
    "on_m_PshBtn_PLCAlarmPortSave_clicked\0"
    "on_m_PshBtn_API_Set_clicked\0"
    "on_m_PshBtn_API_Check_clicked\0"
    "on_m_PshBtn_API_Reset_clicked\0"
    "on_timeEdit_Time_timeChanged\0time\0"
    "on_m_PshBtn_Alarm_clicked\0"
    "on_m_PshBtn_PLCDataPortArrival_clicked\0"
    "on_m_PshBtn_PLCAlarmPortArrival_clicked\0"
    "on_comboBox_ConnectedIPs_currentIndexChanged\0"
    "on_m_PshBtn_DataPort_Reset_clicked\0"
    "on_m_PshBtn_AlarmPort_Reset_clicked\0"
    "on_toolButton_Version_clicked\0"
    "onComboTextChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CommissionSetting[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x08 /* Private */,
       3,    0,  130,    2, 0x08 /* Private */,
       4,    0,  131,    2, 0x08 /* Private */,
       5,    0,  132,    2, 0x08 /* Private */,
       6,    1,  133,    2, 0x08 /* Private */,
       8,    0,  136,    2, 0x08 /* Private */,
       9,    0,  137,    2, 0x08 /* Private */,
      10,    0,  138,    2, 0x08 /* Private */,
      11,    0,  139,    2, 0x08 /* Private */,
      12,    0,  140,    2, 0x08 /* Private */,
      13,    0,  141,    2, 0x08 /* Private */,
      14,    0,  142,    2, 0x08 /* Private */,
      15,    0,  143,    2, 0x08 /* Private */,
      16,    0,  144,    2, 0x08 /* Private */,
      17,    1,  145,    2, 0x08 /* Private */,
      19,    0,  148,    2, 0x08 /* Private */,
      20,    0,  149,    2, 0x08 /* Private */,
      21,    0,  150,    2, 0x08 /* Private */,
      22,    1,  151,    2, 0x08 /* Private */,
      23,    0,  154,    2, 0x08 /* Private */,
      24,    0,  155,    2, 0x08 /* Private */,
      25,    0,  156,    2, 0x08 /* Private */,
      26,    1,  157,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QTime,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,

       0        // eod
};

void CommissionSetting::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CommissionSetting *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_connect_clicked(); break;
        case 1: _t->CheckConnection(); break;
        case 2: _t->updateTime(); break;
        case 3: _t->UpdateTimezoneUTC(); break;
        case 4: _t->on_comboBox_ConnectedIPs_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_m_PshBtn_UTC_Time_clicked(); break;
        case 6: _t->on_m_PshBtn_LocaleTime_clicked(); break;
        case 7: _t->on_toolButton_AWLFile_clicked(); break;
        case 8: _t->on_m_PshBtn_AWLFileUpload_clicked(); break;
        case 9: _t->on_m_PshBtn_PLCDataPortSave_clicked(); break;
        case 10: _t->on_m_PshBtn_PLCAlarmPortSave_clicked(); break;
        case 11: _t->on_m_PshBtn_API_Set_clicked(); break;
        case 12: _t->on_m_PshBtn_API_Check_clicked(); break;
        case 13: _t->on_m_PshBtn_API_Reset_clicked(); break;
        case 14: _t->on_timeEdit_Time_timeChanged((*reinterpret_cast< const QTime(*)>(_a[1]))); break;
        case 15: _t->on_m_PshBtn_Alarm_clicked(); break;
        case 16: _t->on_m_PshBtn_PLCDataPortArrival_clicked(); break;
        case 17: _t->on_m_PshBtn_PLCAlarmPortArrival_clicked(); break;
        case 18: _t->on_comboBox_ConnectedIPs_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->on_m_PshBtn_DataPort_Reset_clicked(); break;
        case 20: _t->on_m_PshBtn_AlarmPort_Reset_clicked(); break;
        case 21: _t->on_toolButton_Version_clicked(); break;
        case 22: _t->onComboTextChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CommissionSetting::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CommissionSetting.data,
    qt_meta_data_CommissionSetting,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CommissionSetting::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CommissionSetting::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CommissionSetting.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int CommissionSetting::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
